<?php 

class Konsumen extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('master/modelkonsumen');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nama_toko = isset($_POST['nama_toko'])?$_POST['nama_toko']:"";
		$owner = isset($_POST['owner'])?$_POST['owner']:"";
		
		$data["nama_toko"] = $nama_toko;
		$data["owner"] = $owner;
		
		$config = array();
        $config["base_url"] = base_url() . "master/konsumen/home";
        $config["total_rows"] = $this->modelkonsumen->countkonsumen($nama_toko, $owner);
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
		
		//css pagination
		$config['full_tag_open'] = "<ul class='pagination pull-right'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
		
		
		$this->pagination->initialize($config);

		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data["listuser"] = $this->modelkonsumen->getAllkonsumen($config["per_page"], $page, $nama_toko, $owner);
		
		$data["page"] = $page;
		$data["links"] = $this->pagination->create_links();
		
		$this->load->view('master/konsumen/home', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		
		$data['id_konsumen'] = null;
		$data['id_user'] = null;
		$data['nama_toko'] = null;
		$data['owner'] = null;
		$data['alamat'] = null;
		
		$this->load->view('master/konsumen/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('master/konsumen');
		}
		
		$row=$this->modelkonsumen->getkonsumen($id);
		
		$data['jenis'] = 'edit';
		
		
		$data['id_konsumen'] = $row->id_konsumen;
		$data['id_user'] = $row->id_user;
		$data['nama_toko'] = $row->nama_toko;
		$data['owner'] = $row->nama_lengkap;
		$data['alamat'] = $row->alamat;
		
		$this->load->view('master/konsumen/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('master/konsumen');
		}
		
		$this->modelkonsumen->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('master/konsumen');
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama_toko', 'nama toko', 'required');
		$this->form_validation->set_rules('owner', 'owner', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_konsumen = $this->input->post('id_konsumen');
			$id_user = $this->input->post('id_user');
			$nama_toko = $this->input->post('nama_toko');
			$owner = $this->input->post('owner');
			$alamat = $this->input->post('alamat');

			$jenis = $this->input->post('jenis');

			$data['nama_toko'] = $nama_toko;
			$data['alamat'] = $alamat;
			
			if($jenis=='tambah'){
				//add user
				$user['nama_lengkap'] = $owner;
				$user['id_usergroup'] = 2;
				$id_user = $this->modelkonsumen->tambah_user($user);

				$data['id_user'] = $id_user;

				$this->modelkonsumen->tambah($data);

				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
			}else{
				//edit user
				$user['nama_lengkap'] = $owner;
				$user['id_user'] = $id_user;
				$this->modelkonsumen->ubah_user($user);
				
				$data['id_konsumen'] = $id_konsumen;

				$this->modelkonsumen->ubah($data);

				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
			}

			redirect('master/konsumen/');
			
		}else{
			$id = $this->input->post('id_konsumen');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenama_toko=='tambah'){
				redirect('master/konsumen/tambah');
			}else{
				redirect('master/konsumen/ubah/'. $id);
			}
		}
	}

	public function download(){
		$file = base_url().'uploads/user.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	