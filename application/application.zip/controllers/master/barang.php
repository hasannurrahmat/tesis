<?php 

class Barang extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('master/modelbarang');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nama_barang = isset($_POST['nama_barang'])?$_POST['nama_barang']:"";
		$sumber_barang = isset($_POST['sumber_barang'])?$_POST['sumber_barang']:"";
		$tujuan_barang = isset($_POST['tujuan_barang'])?$_POST['tujuan_barang']:"";
		
		$data["nama_barang"] = $nama_barang;
		$data["sumber_barang"] = $sumber_barang;
		$data["tujuan_barang"] = $tujuan_barang;
	
		
		$data["listuser"] = $this->modelbarang->getAllbarang($nama_barang, $sumber_barang, $tujuan_barang);
		
		$pembelian = $this->modelbarang->getAllpembelian();
		$penjualan = $this->modelbarang->getAllpenjualan();

		$stock = array();
		$barang = $this->modelbarang->getAllitem();
		foreach($barang as $b){
			$beli = 0;
			$jual = 0;
			$stock[$b->id_barang] = array();
			$stock[$b->id_barang]["nama_barang"] = $b->nama_barang;
			$stock[$b->id_barang]["stock"] = $b->stock;
			$stock[$b->id_barang]["harga_satuan"] = $b->harga_satuan;

			foreach ($pembelian as $p) {
				if($p->id_barang == $b->id_barang){
					$beli += $p->total_jumlah;
				}
			}
			
			foreach ($penjualan as $p) {
				if($p->id_barang == $b->id_barang){
					$jual += $p->total_jumlah;
				}
			}

			$stock[$b->id_barang]["stock"] = $b->stock + $beli - $jual;
		}
		
		$data["liststock"] = $stock;
		$this->load->view('master/barang/home', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		
		$data['id_barang'] = null;
		$data['nama_barang'] = null;
		$data['sumber_barang'] = null;
		$data['tujuan_barang'] = null;
		$data['stock'] = null;
		$data['harga_satuan'] = null;
		
		$this->load->view('master/barang/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('master/barang');
		}
		
		$row=$this->modelbarang->getbarang($id);
		
		$data['jenis'] = 'edit';
		
		
		$data['id_barang'] = $row->id_barang;
		$data['nama_barang'] = $row->nama_barang;
		$data['sumber_barang'] = $row->sumber_barang;
		$data['tujuan_barang'] = $row->nama_lengkap;
		$data['stock'] = $row->stock;
		$data['harga_satuan'] = $row->harga_satuan;
		
		$this->load->view('master/barang/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('master/barang');
		}
		
		$this->modelbarang->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('master/barang');
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama_barang', 'nama barang', 'required');
		$this->form_validation->set_rules('stock', 'stock', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_barang = $this->input->post('id_barang');
			$nama_barang = $this->input->post('nama_barang');
			$sumber_barang = $this->input->post('sumber_barang');
			$tujuan_barang = $this->input->post('tujuan_barang');
			$stock = $this->input->post('stock');
			$harga_satuan = $this->input->post('harga_satuan');

			$jenis = $this->input->post('jenis');

			$data['nama_barang'] = $nama_barang;
			$data['sumber_barang'] = $sumber_barang;
			$data['tujuan_barang'] = $tujuan_barang;
			$data['stock'] = $stock;
			$data['harga_satuan'] = $harga_satuan;
			
			if($jenis=='tambah'){
				$this->modelbarang->tambah($data);

				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
			}else{
				$data['id_barang'] = $id_barang;

				$this->modelbarang->ubah($data);

				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
			}

			redirect('master/barang/');
			
		}else{
			$id = $this->input->post('id_barang');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jesumber_barang=='tambah'){
				redirect('master/barang/tambah');
			}else{
				redirect('master/barang/ubah/'. $id);
			}
		}
	}

	public function download(){
		$file = base_url().'uploads/user.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	