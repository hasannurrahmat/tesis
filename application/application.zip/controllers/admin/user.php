<?php 

class User extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('admin/modeluser');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nama_lengkap = isset($_POST['nama_lengkap'])?$_POST['nama_lengkap']:"";
		$id_usergroup = isset($_POST['id_usergroup'])?$_POST['id_usergroup']:"";
		
		$data["nama_lengkap"] = $nama_lengkap;
		$data["id_usergroup"] = $id_usergroup;
		
		$config = array();
        $config["base_url"] = base_url() . "admin/user/home";
        $config["total_rows"] = $this->modeluser->countuser($nama_lengkap, $id_usergroup);
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
		
		//css pagination
		$config['full_tag_open'] = "<ul class='pagination pull-right'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
		
		
		$this->pagination->initialize($config);

		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data["listuser"] = $this->modeluser->getAlluser($config["per_page"], $page, $nama_lengkap, $id_usergroup);
		
		$data["page"] = $page;
		$data["links"] = $this->pagination->create_links();
		
		$data["jabatan"] = $this->modeluser->getAlljabatan();
		$data["id_usergroup"] = $id_usergroup;
		$data["nama_lengkap"] = $nama_lengkap;

		$this->load->view('admin/user/home', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		
		$data['id_user'] = null;
		$data['username'] = null;
		$data['password'] = null;
		$data['file_photo'] = null;
		$data['nama_lengkap'] = null;
		$data['id_usergroup'] = null;
		
		$data["jabatan"] = $this->modeluser->getAlljabatan();
		$this->load->view('admin/user/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('admin/user');
		}
		
		$row=$this->modeluser->getuser($id);
		
		$data['jenis'] = 'edit';
		
		$data["jabatan"] = $this->modeluser->getAlljabatan();
		
		$data['id_user'] = $row->id_user;
		$data['id_usergroup'] = $row->id_usergroup;
		$data['username'] = $row->username;
		$data['password'] = $row->password;
		$data['nama_lengkap'] = $row->nama_lengkap;
		$data['file_photo'] = $row->file_photo;
		
		$this->load->view('admin/user/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('admin/user');
		}
		
		$this->modeluser->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('admin/user');
	}
	
	public function submit(){
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('id_usergroup', 'id_usergroup', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_user = $this->input->post('id_user');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$nama_lengkap = $this->input->post('nama_lengkap');
			$file_photo = "";
			$id_usergroup = $this->input->post('id_usergroup');
			$jenis = $this->input->post('jenis');

			$data['nama_lengkap'] = $nama_lengkap;
			$data['username'] = $username;
			$data['password'] = $password;
			$data['file_photo'] = $file_photo;
			$data['id_usergroup'] = $id_usergroup;
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modeluser->tambah($data);
			}else{
				$data['id_user'] = $id_user;
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modeluser->ubah($data);
			}

			//upload photo
			$config['upload_path'] = './uploads/profile_picture';
		    $config['allowed_types'] = 'gif|jpg|png';
		    $config['max_size'] = '10000';
		    $config['overwrite'] = TRUE;
		    $config['encrypt_name'] = FALSE;
		    $config['remove_spaces'] = TRUE;
		    $config['file_name'] = $this->session->userdata('username').''.time();
		    if ( ! is_dir($config['upload_path']) ) die("THE UPLOAD DIRECTORY DOES NOT EXIST");
		    
		    $this->load->library('upload', $config);
		    $this->upload->initialize($config);

		    if ( ! $this->upload->do_upload('upload_photo')) {
		        
		    } else {
		        $upload_data = $this->upload->data();

		        $data['file_photo'] = $upload_data['file_name'];
		        $this->db->where('username', $username);
				$this->db->update('user', $data);
		    }
			// ============== //

			redirect('admin/user/');
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenama_lengkap=='tambah'){
				redirect('admin/user/tambah');
			}else{
				redirect('admin/user/ubah/'. $id);
			}
		}
	}

	public function download(){
		$file = base_url().'uploads/user.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	