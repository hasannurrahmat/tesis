<?php 

class ganti extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('admin/modelganti');
		$this->load->helper("url");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->ubah();
	}
	
	public function ubah($id=0){
		$id = $this->session->userdata('is_logged_in');
		$row=$this->modelganti->getaplikasi($id);
		
		$data['id_aplikasi'] = $row->id_aplikasi;
		$data['nama_aplikasi'] = $row->nama_aplikasi;
		$data['alamat'] = $row->alamat;
		
		$this->load->view('admin/ganti/tambah', $data);
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama_aplikasi', 'nama aplikasi', 'required');
		$this->form_validation->set_rules('alamat', 'alamat', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_aplikasi = $this->input->post('id_aplikasi');
			$nama_aplikasi = $this->input->post('nama_aplikasi');
			$alamat = $this->input->post('alamat');
			
			$data['nama_aplikasi'] = $nama_aplikasi;
			$data['alamat'] = $alamat;			
			
			$data['id_aplikasi'] = $id_aplikasi;
			$this->session->set_flashdata('message', 'Data berhasil diupdate!');
			$this->session->set_flashdata('statusmessage', '1');
			
			$this->modelganti->ubah($data);
			
			redirect('admin/ganti/');
			
		}else{
			$id = $this->input->post('id');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			redirect('admin/ganti/ubah/'. $id);
		}
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	