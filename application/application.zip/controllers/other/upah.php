<?php 

class upah extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('other/modelupah');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($tgl="", $id=0){
		$data['user'] = $this->model_auth->getuser($this->session->userdata('username'));

		$tanggal = isset($_POST['tanggal'])?$_POST['tanggal']:$tgl;
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:$tgl;
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:$tgl;
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:$id;
		
		$row = $this->modelupah->getkonsumen($id_konsumen);
		if($row){
			$data['nama_toko'] = $row->nama_toko;
			$data['owner'] = $row->nama_lengkap;
			$data['alamat'] = $row->alamat;
		}else{
			$data['nama_toko'] = "";
			$data['owner'] = "";
			$data['alamat'] = "";
		}

		$data["tanggal"] = $tanggal;
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
		
		$data["listupah"] = $this->modelupah->getAllupah($tanggal, $id_konsumen);
				
		$data["konsumen"] = $this->modelupah->getAllkonsumen();
		$data["karyawan"] = $this->modelupah->getAllkaryawan();
		
		$this->load->view('other/upah/home', $data);
	}

	public function submit(){
		$this->form_validation->set_rules('id_karyawan', 'karyawan', 'required');
		$this->form_validation->set_rules('upah', 'upah', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_user = $this->input->post('id_user');
			$id_konsumen = $this->input->post('id_konsumen');
			$id_karyawan = $this->input->post('id_karyawan');
			$upah = $this->input->post('upah');
			$tanggal = $this->input->post('tanggal');
			$keterangan = $this->input->post('keterangan');

			$data['id_user'] = $id_user;
			$data['id_konsumen'] = $id_konsumen;
			$data['id_karyawan'] = $id_karyawan;
			$data['upah'] = $upah;
			$data['tanggal'] = $tanggal;
			$data['keterangan'] = $keterangan;
			
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
				
			$this->modelupah->tambah($data);
			
			redirect('other/upah/home/'.$tanggal.'/'.$id_konsumen);
			
		}else{
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			redirect('other/upah/');
		}
	}

	public function print_pdf($tanggal="", $id_konsumen=0){
	
		//variable yang dibutuhkan
		$row = $this->modelupah->getkonsumen($id_konsumen);
		if($row){
			$nama_toko = $row->nama_toko;
			$owner = $row->nama_lengkap;
			$alamat = $row->alamat;
		}
		
		$list = $this->modelupah->getAllupah($tanggal, $id_konsumen);
		$aplikasi = $this->modelupah->getaplikasi($this->session->userdata('id_aplikasi'));

		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 16);
		$pdf->MultiCell(300, 2, $aplikasi->nama_aplikasi, 0, 'L', 0, 1, 85, 15, true);
		
		$pdf->SetFont('helvetica', '', 12);
		$pdf->MultiCell(300, 2, $aplikasi->alamat, 0, 'L', 0, 1, 25, 25, true);
		
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'Kasir', 0, 'L', 0, 1, 20, 40, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 20, 45, true);
		$pdf->MultiCell(55, 5, 'Owner', 0, 'L', 0, 1, 100, 40, true);
		$pdf->MultiCell(55, 5, 'Toko', 0, 'L', 0, 1, 100, 45, true);
		$pdf->MultiCell(55, 5, 'Alamat', 0, 'L', 0, 1, 100, 50, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 50, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $this->session->userdata('nama_lengkap'), 0, 'L', 0, 1, 45, 40, true);
		$pdf->MultiCell(100, 5, $tanggal, 0, 'L', 0, 1, 45, 45, true);
		$pdf->MultiCell(100, 5, $owner, 0, 'L', 0, 1, 135, 40, true);
		$pdf->MultiCell(100, 5, $nama_toko, 0, 'L', 0, 1, 135, 45, true);
		$pdf->MultiCell(100, 5, $alamat, 0, 'L', 0, 1, 135, 50, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 60, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 12);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 50px;">No</td>
				<td style="border: 1px solid #000000; width: 125px;">Karyawan</td>
				<td style="border: 1px solid #000000; width: 100px;">Jabatan</td>
				<td style="border: 1px solid #000000; width: 125px;">Keterangan</td>
				<td style="border: 1px solid #000000; width: 100px;">Upah</td>
			</tr>
		';

		// foreach item in your array...
		$no=1; $total = 0;
		if($list){
			foreach($list as $l){
				$ket="";
				if($l->keterangan==""){$ket = "-";}else{$ket = $l->keterangan;}
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 50px;">'.$no.'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$l->nama_lengkap.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.$l->usergroup.'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$ket.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.number_format($l->upah, 2, ",", ".").'</td>
					</tr>
				';
				$total += $l->upah;
				$no++;
			}
			$tbl .= '
			<tr>
				<td style="border: 1px solid #000000; width: 400px;" colspan=4>Total Upah</td>
				<td style="border: 1px solid #000000; width: 100px;">'.number_format($total, 2, ",", ".").'</td>
			</tr>
		';
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		// $pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output('upah-'.$tanggal.'.pdf', 'D');
		
		redirect('other/upah/home/'.$tanggal.'/'.$id_konsumen);
		// ----------------------------------------------------------------------- //
	}
	
	public function print_pdf_rekap($tanggal_awal="", $tanggal_akhir="", $id_konsumen=0){
		$id_konsumen = $this->input->post('id_konsumen');
		$tanggal_awal = $this->input->post('tanggal_awal');
		$tanggal_akhir = $this->input->post('tanggal_akhir');

		//variable yang dibutuhkan
		$row = $this->modelupah->getkonsumen($id_konsumen);
		if($row){
			$nama_toko = $row->nama_toko;
			$owner = $row->nama_lengkap;
			$alamat = $row->alamat;
		}
		
		$list = $this->modelupah->getAllupahrekap($tanggal_awal, $tanggal_akhir, $id_konsumen);
		$aplikasi = $this->modelupah->getaplikasi($this->session->userdata('id_aplikasi'));

		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 16);
		$pdf->MultiCell(300, 2, $aplikasi->nama_aplikasi, 0, 'L', 0, 1, 85, 15, true);
		
		$pdf->SetFont('helvetica', '', 12);
		$pdf->MultiCell(300, 2, $aplikasi->alamat, 0, 'L', 0, 1, 25, 25, true);
		
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'Kasir', 0, 'L', 0, 1, 20, 40, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 20, 45, true);
		$pdf->MultiCell(55, 5, 'Owner', 0, 'L', 0, 1, 100, 40, true);
		$pdf->MultiCell(55, 5, 'Toko', 0, 'L', 0, 1, 100, 45, true);
		$pdf->MultiCell(55, 5, 'Alamat', 0, 'L', 0, 1, 100, 50, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 50, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $this->session->userdata('nama_lengkap'), 0, 'L', 0, 1, 45, 40, true);
		$pdf->MultiCell(150, 5, $tanggal_awal.' - '.$tanggal_akhir, 0, 'L', 0, 1, 45, 45, true);
		$pdf->MultiCell(100, 5, $owner, 0, 'L', 0, 1, 135, 40, true);
		$pdf->MultiCell(100, 5, $nama_toko, 0, 'L', 0, 1, 135, 45, true);
		$pdf->MultiCell(100, 5, $alamat, 0, 'L', 0, 1, 135, 50, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 60, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 12);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 50px;">No</td>
				<td style="border: 1px solid #000000; width: 75px;">Tanggal</td>
				<td style="border: 1px solid #000000; width: 125px;">Karyawan</td>
				<td style="border: 1px solid #000000; width: 75px;">Jabatan</td>
				<td style="border: 1px solid #000000; width: 75px;">Keterangan</td>
				<td style="border: 1px solid #000000; width: 100px;">Nominal</td>
			</tr>
		';

		// foreach item in your array...
		$no=1; $total = 0;
		if($list){
			foreach($list as $l){
				$ket="";
				if($l->keterangan==""){$ket = "-";}else{$ket = $l->keterangan;}
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 50px;">'.$no.'</td>
						<td style="border: 1px solid #000000; width: 75px;">'.$l->tanggal.'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$l->nama_lengkap.'</td>
						<td style="border: 1px solid #000000; width: 75px;">'.$l->usergroup.'</td>
						<td style="border: 1px solid #000000; width: 75px;">'.$ket.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.number_format($l->upah, 2, ",", ".").'</td>
					</tr>
				';
				$total += $l->upah;
				$no++;
			}
			$tbl .= '
			<tr>
				<td style="border: 1px solid #000000; width: 400px;" colspan=5>Total Upah</td>
				<td style="border: 1px solid #000000; width: 100px;">'.number_format($total, 2, ",", ".").'</td>
			</tr>
		';
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		// $pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output('rekap-upah-'.$nama_toko.'-'.$tanggal_awal.'-'.$tanggal_akhir.'.pdf', 'D');
		
		redirect('other/upah/home/'.$tanggal_akhir.'/'.$id_konsumen);
		// ----------------------------------------------------------------------- //
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	