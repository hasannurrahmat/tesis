<?php 

class Penjualan extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('other/modelpenjualan');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($tgl="", $id=0){
		$data['user'] = $this->model_auth->getuser($this->session->userdata('username'));

		$tanggal = isset($_POST['tanggal'])?$_POST['tanggal']:$tgl;
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:$tgl;
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:$tgl;
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:$id;
		
		$row = $this->modelpenjualan->getkonsumen($id_konsumen);
		if($row){
			$data['nama_toko'] = $row->nama_toko;
			$data['owner'] = $row->nama_lengkap;
			$data['alamat'] = $row->alamat;
		}else{
			$data['nama_toko'] = "";
			$data['owner'] = "";
			$data['alamat'] = "";
		}

		$data["tanggal"] = $tanggal;
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
		
		$data["listpenjualan"] = $this->modelpenjualan->getAllpenjualan($tanggal, $id_konsumen);
				
		$data["konsumen"] = $this->modelpenjualan->getAllkonsumen();
		$data["penjualan"] = $this->modelpenjualan->getAllpenjualan("");
		
		$this->load->view('other/penjualan/home', $data);
	}

	public function edit($id=0){
		if($id==0){
			redirect('other/penjualan');
		}
		
		$row=$this->modelpenjualan->getpenjualan($id);
		
		$data['id_penjualan'] = $row->id_penjualan;
		$data['id_konsumen'] = $row->id_konsumen;
		$data['kasir'] = $row->nama_lengkap;
		$data['nama_toko'] = $row->nama_toko;
		$data['id_barang'] = $row->id_barang;
		$data['jumlah'] = $row->jumlah;
		$data['harga_satuan'] = $row->harga_satuan;
		$data['harga'] = $row->harga;
		$data['tanggal'] = $row->tanggal;
		$data['keterangan'] = $row->keterangan;

		$data["konsumen"] = $this->modelpenjualan->getAllkonsumen();
		$data["barang"] = $this->modelpenjualan->getAllbarang();
		
		$this->load->view('other/penjualan/edit', $data);
	}

	public function hapus($id=0){
		if($id==0){
			redirect('other/penjualan');
		}
		
		$this->modelpenjualan->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('other/penjualan');
	}

	public function get_penjualan(){
		$id_penjualan=$this->input->post('id');
		$modul=$this->input->post('modul');
		if($modul=="penjualan"){
			echo number_format($this->modelpenjualan->getpenjualanselect($id_penjualan), 0, ',', '');
		}
	}

	public function submit(){
		$this->form_validation->set_rules('id_penjualan', 'penjualan', 'required');
		$this->form_validation->set_rules('jumlah', 'jumlah', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_barang = $this->input->post('id_barang');
			$id_konsumen = $this->input->post('id_konsumen');
			$id_penjualan = $this->input->post('id_penjualan');
			$jumlah = $this->input->post('jumlah');
			$harga = $this->input->post('harga');
			$tanggal = $this->input->post('tanggal');
			$keterangan = $this->input->post('keterangan');

			$data['id_barang'] = $id_barang;
			$data['id_penjualan'] = $id_penjualan;
			$data['jumlah'] = $jumlah;
			$data['harga'] = $harga;
			$data['keterangan'] = $keterangan;
			
			$this->session->set_flashdata('message', 'Data berhasil diupdate!');
			$this->session->set_flashdata('statusmessage', '1');
				
			$this->modelpenjualan->edit($data);
			
			redirect('other/penjualan/home/'.$tanggal.'/'.$id_konsumen);
			
		}else{
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			redirect('other/penjualan/home');
		}
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	