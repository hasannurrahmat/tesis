<?php 

class keuntungan extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('other/modelkeuntungan');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($id=0){
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:"";
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:"";
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:0;
	
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
			
		$data["konsumen"] = $this->modelkeuntungan->getAllkonsumen($id_konsumen);
		$data["barang"] = $this->modelkeuntungan->getAllbarang();

		$barang = array();
		foreach ($data["konsumen"] as $k) {
				$barang[$k->id_konsumen] = array();
			foreach ($data["barang"] as $b) {
				$barang[$k->id_konsumen][$b->id_barang] = array();
				$barang[$k->id_konsumen][$b->id_barang]["nama_barang"] = $b->nama_barang;
				$barang[$k->id_konsumen][$b->id_barang]["harga_satuan"] = $b->harga_satuan;
				$barang[$k->id_konsumen][$b->id_barang]["pembelian"] = 0;
				$barang[$k->id_konsumen][$b->id_barang]["penjualan"] = 0;
				$barang[$k->id_konsumen][$b->id_barang]["netto"] = 0;
				$barang[$k->id_konsumen][$b->id_barang]["bruto"] = 0;

				$netto = 0;
				$bruto = 0;
				$total_pembelian = 0;
				$total_penjualan = 0;
				$pembelian = $this->modelkeuntungan->getAllpembelian($tanggal_awal, $tanggal_akhir, $k->id_konsumen);
				if($pembelian){
					foreach ($pembelian as $p) {
						if($p->id_konsumen==$k->id_konsumen && $p->id_barang==$b->id_barang){
							$barang[$k->id_konsumen][$b->id_barang]["pembelian"] = $p->total_jumlah;
							$total_pembelian += $p->total_jumlah * $b->harga_satuan;
						}
					}
				}

				$penjualan = $this->modelkeuntungan->getAllpenjualan($tanggal_awal, $tanggal_akhir, $k->id_konsumen);
				if($penjualan){
					foreach ($penjualan as $p) {
						if($p->id_konsumen==$k->id_konsumen && $p->id_barang==$b->id_barang){
							$barang[$k->id_konsumen][$b->id_barang]["penjualan"] = $p->total_jumlah;
							$total_penjualan += $p->total_jumlah * $b->harga_satuan;
						}
					}
				}

				$netto = $total_penjualan - $total_pembelian;
				$bruto = $total_penjualan;

				$barang[$k->id_konsumen][$b->id_barang]["netto"] = $netto;
				$barang[$k->id_konsumen][$b->id_barang]["bruto"] = $bruto;
			}
		}

		$data["listkeuntungan"] = $barang;

		$this->load->view('other/keuntungan/home', $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	