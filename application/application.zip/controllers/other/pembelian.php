<?php 

class Pembelian extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('other/modelpembelian');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($tgl="", $id=0){
		$data['user'] = $this->model_auth->getuser($this->session->userdata('username'));

		$tanggal = isset($_POST['tanggal'])?$_POST['tanggal']:$tgl;
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:$tgl;
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:$tgl;
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:$id;
		
		$row = $this->modelpembelian->getkonsumen($id_konsumen);
		if($row){
			$data['nama_toko'] = $row->nama_toko;
			$data['owner'] = $row->nama_lengkap;
			$data['alamat'] = $row->alamat;
		}else{
			$data['nama_toko'] = "";
			$data['owner'] = "";
			$data['alamat'] = "";
		}

		$data["tanggal"] = $tanggal;
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
		
		$data["listpembelian"] = $this->modelpembelian->getAllpembelian($tanggal, $id_konsumen);
				
		$data["konsumen"] = $this->modelpembelian->getAllkonsumen();
		$data["pembelian"] = $this->modelpembelian->getAllpembelian("");
		
		$this->load->view('other/pembelian/home', $data);
	}

	public function edit($id=0){
		if($id==0){
			redirect('other/pembelian');
		}
		
		$row=$this->modelpembelian->getpembelian($id);
		
		$data['id_pembelian'] = $row->id_pembelian;
		$data['id_konsumen'] = $row->id_konsumen;
		$data['kasir'] = $row->nama_lengkap;
		$data['nama_toko'] = $row->nama_toko;
		$data['id_barang'] = $row->id_barang;
		$data['jumlah'] = $row->jumlah;
		$data['harga_satuan'] = $row->harga_satuan;
		$data['harga'] = $row->harga;
		$data['tanggal'] = $row->tanggal;
		$data['keterangan'] = $row->keterangan;

		$data["konsumen"] = $this->modelpembelian->getAllkonsumen();
		$data["barang"] = $this->modelpembelian->getAllbarang();
		
		$this->load->view('other/pembelian/edit', $data);
	}

	public function hapus($id=0){
		if($id==0){
			redirect('other/pembelian');
		}
		
		$this->modelpembelian->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('other/pembelian');
	}

	public function get_pembelian(){
		$id_pembelian=$this->input->post('id');
		$modul=$this->input->post('modul');
		if($modul=="pembelian"){
			echo number_format($this->modelpembelian->getpembelianselect($id_pembelian), 0, ',', '');
		}
	}

	public function submit(){
		$this->form_validation->set_rules('id_pembelian', 'pembelian', 'required');
		$this->form_validation->set_rules('jumlah', 'jumlah', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_barang = $this->input->post('id_barang');
			$id_konsumen = $this->input->post('id_konsumen');
			$id_pembelian = $this->input->post('id_pembelian');
			$jumlah = $this->input->post('jumlah');
			$harga = $this->input->post('harga');
			$tanggal = $this->input->post('tanggal');
			$keterangan = $this->input->post('keterangan');

			$data['id_barang'] = $id_barang;
			$data['id_pembelian'] = $id_pembelian;
			$data['jumlah'] = $jumlah;
			$data['harga'] = $harga;
			$data['keterangan'] = $keterangan;
			
			$this->session->set_flashdata('message', 'Data berhasil diupdate!');
			$this->session->set_flashdata('statusmessage', '1');
				
			$this->modelpembelian->edit($data);
			
			redirect('other/pembelian/home/'.$tanggal.'/'.$id_konsumen);
			
		}else{
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			redirect('other/pembelian/home');
		}
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	