<?php 

class Karyawan extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('other/modelkaryawan');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nama_lengkap = isset($_POST['nama_lengkap'])?$_POST['nama_lengkap']:"";
		
		$data["nama_lengkap"] = $nama_lengkap;
		
		$config = array();
        $config["base_url"] = base_url() . "other/karyawan/home";
        $config["total_rows"] = $this->modelkaryawan->countuser($nama_lengkap);
        $config["per_page"] = 10;
        $config["uri_segment"] = 4;
		
		//css pagination
		$config['full_tag_open'] = "<ul class='pagination pull-right'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
		
		
		$this->pagination->initialize($config);

		$page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
		$data["listuser"] = $this->modelkaryawan->getAlluser($config["per_page"], $page, $nama_lengkap);
		
		$data["page"] = $page;
		$data["links"] = $this->pagination->create_links();
		
		$this->load->view('other/karyawan/home', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		
		$data['id_user'] = null;
		$data['nama_lengkap'] = null;
		$data['id_usergroup'] = 5;

		$this->load->view('other/karyawan/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('other/karyawan');
		}
		
		$row=$this->modelkaryawan->getuser($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_user'] = $row->id_user;
		$data['id_usergroup'] = $row->id_usergroup;
		$data['nama_lengkap'] = $row->nama_lengkap;
		
		$this->load->view('other/karyawan/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('other/karyawan');
		}
		
		$this->modelkaryawan->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('other/karyawan');
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama_lengkap', 'nama lengkap', 'required');
		$this->form_validation->set_rules('id_usergroup', 'id_usergroup', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_user = $this->input->post('id_user');
			$nama_lengkap = $this->input->post('nama_lengkap');
			$id_usergroup = $this->input->post('id_usergroup');
			$jenis = $this->input->post('jenis');

			$data['nama_lengkap'] = $nama_lengkap;
			$data['id_usergroup'] = $id_usergroup;
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelkaryawan->tambah($data);
			}else{
				$data['id_user'] = $id_user;
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelkaryawan->ubah($data);
			}

			redirect('other/karyawan/');
			
		}else{
			$id = $this->input->post('id_user');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenama_lengkap=='tambah'){
				redirect('other/karyawan/tambah');
			}else{
				redirect('other/karyawan/ubah/'. $id);
			}
		}
	}

	public function download(){
		$file = base_url().'uploads/user.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	