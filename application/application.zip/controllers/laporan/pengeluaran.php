<?php 

class Pengeluaran extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('laporan/modelpengeluaran');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($id=0){
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:"";
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:"";
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:0;
	
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
		
		$data["listpengeluaran"] = $this->modelpengeluaran->getAllpengeluaran($tanggal_awal, $tanggal_akhir, $id_konsumen);
				
		$data["konsumen"] = $this->modelpengeluaran->getAllkonsumen();
		
		$this->load->view('laporan/pengeluaran/home', $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	