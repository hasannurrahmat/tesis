<?php 

class Auth extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->model('model_auth');
	}
	
	public function index(){
		$this->login();
	}
	
	public function login(){
		if(!$this->session->userdata('is_logged_in')){
			$this->load->view('auth/form_login');
		}else{
			redirect('auth/home');
		}
	}
	
	public function home(){
		if(!$this->session->userdata('is_logged_in')){
			$this->load->view('auth/form_login');
		}else{
			$pembelian = $this->model_auth->getAllpembelian();
			$penjualan = $this->model_auth->getAllpenjualan();
			$pengeluaran = $this->model_auth->getAllpengeluaran();

			$totalpembelian = 0;
			$totalpenjualan = 0;
			$totalpengeluaran = 0;

			if($pembelian){
				foreach ($pembelian as $p) {
					$totalpembelian += $p->total_harga;
				}
			}
			
			if($penjualan){
				foreach ($penjualan as $p) {
					$totalpenjualan += $p->total_harga;
				}
			}

			if($pengeluaran){
				foreach ($pengeluaran as $p) {
					$totalpengeluaran += $p->total_harga;
				}
			}
			
			$data['totalpembelian'] = $totalpembelian;
			$data['totalpenjualan'] = $totalpenjualan;
			$data['totalpengeluaran'] = $totalpengeluaran;

			$data['user'] = $this->model_auth->getuser($this->session->userdata('username'));
			$this->load->view('auth/home', $data);
		}
	}
	
	public function validasi(){
	
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		
		$query  = $this->model_auth->validasi_login($username, $password);
		$app  = $this->model_auth->getaplikasi(1);
		
		//jika berhasil
		if($query){
			$data['nama_aplikasi'] = $app->nama_aplikasi;
			$data['id_aplikasi'] = $app->id_aplikasi;
			$data['username'] = $query->username;
			$data['id_usergroup'] = $query->id_usergroup;
			$data['usergroup'] = $query->usergroup;
			$data['id_user'] = $query->id_user;
			$data['nama_lengkap'] = $query->nama_lengkap;
		
			$data['is_logged_in'] = TRUE;
			//ses session utk login
			$this->session->set_userdata($data);
			
			redirect('auth/home');
			
		}else{ //gagal
			$this->session->set_flashdata('message', 'Username atau Password Salah!');
			$this->session->set_flashdata('statusmessage', '2');
			
			redirect('auth/login');
		}
	}
		
	function logout(){
		$this->session->sess_destroy();
		redirect('auth/login');
	}	

	function ganti(){
	    $config['upload_path'] = './uploads/profile_picture';
	    $config['allowed_types'] = 'gif|jpg|png';
	    $config['max_size'] = '10000';
	    $config['overwrite'] = TRUE;
	    $config['encrypt_name'] = FALSE;
	    $config['remove_spaces'] = TRUE;
	    $config['file_name'] = $this->session->userdata('username').''.time();
	    if ( ! is_dir($config['upload_path']) ) die("THE UPLOAD DIRECTORY DOES NOT EXIST");
	    $this->load->library('upload', $config);
	    if ( ! $this->upload->do_upload('userfile')) {
	        echo 'error';
	    } else {
	        $upload_data = $this->upload->data();


	        $data['file_photo'] = $upload_data['file_name'];
	        $this->db->where('username', $this->session->userdata('username'));
			$this->db->update('user', $data); 
	    }
	    redirect('auth/home');

	}
}