<?php 

class Pembelian extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('aplikasi/modelpembelian');
		$this->load->model('model_auth');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library('Pdf');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($tgl="", $id=0){
		$data['user'] = $this->model_auth->getuser($this->session->userdata('username'));

		$tanggal = isset($_POST['tanggal'])?$_POST['tanggal']:$tgl;
		$tanggal_awal = isset($_POST['tanggal_awal'])?$_POST['tanggal_awal']:$tgl;
		$tanggal_akhir = isset($_POST['tanggal_akhir'])?$_POST['tanggal_akhir']:$tgl;
		$id_konsumen = isset($_POST['id_konsumen'])?$_POST['id_konsumen']:$id;
		
		$row = $this->modelpembelian->getkonsumen($id_konsumen);
		if($row){
			$data['nama_toko'] = $row->nama_toko;
			$data['owner'] = $row->nama_lengkap;
			$data['alamat'] = $row->alamat;
		}else{
			$data['nama_toko'] = "";
			$data['owner'] = "";
			$data['alamat'] = "";
		}

		$data["tanggal"] = $tanggal;
		$data["tanggal_awal"] = $tanggal_awal;
		$data["tanggal_akhir"] = $tanggal_akhir;
		$data["id_konsumen"] = $id_konsumen;
		
		$data["listpembelian"] = $this->modelpembelian->getAllpembelian($tanggal, $id_konsumen);
				
		$data["konsumen"] = $this->modelpembelian->getAllkonsumen();
		$data["barang"] = $this->modelpembelian->getAllbarang("");
		
		$this->load->view('aplikasi/pembelian/home', $data);
	}

	public function get_barang(){
		$id_barang=$this->input->post('id');
		$modul=$this->input->post('modul');
		if($modul=="pembelian"){
			echo number_format($this->modelpembelian->getbarang($id_barang), 0, ',', '');
		}
	}

	public function submit(){
		$this->form_validation->set_rules('id_barang', 'barang', 'required');
		$this->form_validation->set_rules('jumlah', 'jumlah', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id_user = $this->input->post('id_user');
			$id_konsumen = $this->input->post('id_konsumen');
			$id_barang = $this->input->post('id_barang');
			$jumlah = $this->input->post('jumlah');
			$harga = $this->input->post('harga');
			$tanggal = $this->input->post('tanggal');
			$keterangan = $this->input->post('keterangan');

			$data['id_user'] = $id_user;
			$data['id_konsumen'] = $id_konsumen;
			$data['id_barang'] = $id_barang;
			$data['jumlah'] = $jumlah;
			$data['harga'] = $harga;
			$data['tanggal'] = $tanggal;
			$data['keterangan'] = $keterangan;
			
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
				
			$this->modelpembelian->tambah($data);
			
			redirect('aplikasi/pembelian/home/'.$tanggal.'/'.$id_konsumen);
			
		}else{
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			redirect('aplikasi/pembelian/home');
		}
	}

	public function download(){
		$file = base_url().'uploads/pembelian.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function print_pdf($tanggal="", $id_konsumen=0){
	
		//variable yang dibutuhkan
		$row = $this->modelpembelian->getkonsumen($id_konsumen);
		if($row){
			$nama_toko = $row->nama_toko;
			$owner = $row->nama_lengkap;
			$alamat = $row->alamat;
		}
		
		$list = $this->modelpembelian->getAllpembelian($tanggal, $id_konsumen);
		$aplikasi = $this->modelpembelian->getaplikasi($this->session->userdata('id_aplikasi'));

		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 16);
		$pdf->MultiCell(300, 2, $aplikasi->nama_aplikasi, 0, 'L', 0, 1, 85, 15, true);
		
		$pdf->SetFont('helvetica', '', 12);
		$pdf->MultiCell(300, 2, $aplikasi->alamat, 0, 'L', 0, 1, 25, 25, true);
		
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'Kasir', 0, 'L', 0, 1, 20, 40, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 20, 45, true);
		$pdf->MultiCell(55, 5, 'Owner', 0, 'L', 0, 1, 100, 40, true);
		$pdf->MultiCell(55, 5, 'Toko', 0, 'L', 0, 1, 100, 45, true);
		$pdf->MultiCell(55, 5, 'Alamat', 0, 'L', 0, 1, 100, 50, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 50, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $this->session->userdata('nama_lengkap'), 0, 'L', 0, 1, 45, 40, true);
		$pdf->MultiCell(100, 5, $tanggal, 0, 'L', 0, 1, 45, 45, true);
		$pdf->MultiCell(100, 5, $owner, 0, 'L', 0, 1, 135, 40, true);
		$pdf->MultiCell(100, 5, $nama_toko, 0, 'L', 0, 1, 135, 45, true);
		$pdf->MultiCell(100, 5, $alamat, 0, 'L', 0, 1, 135, 50, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 60, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 12);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 50px;">No</td>
				<td style="border: 1px solid #000000; width: 125px;">Barang</td>
				<td style="border: 1px solid #000000; width: 100px;">Qty/Pcs</td>
				<td style="border: 1px solid #000000; width: 100px;">Harga Total</td>
				<td style="border: 1px solid #000000; width: 125px;">Keterangan</td>
			</tr>
		';

		// foreach item in your array...
		$no=1; $total = 0;
		if($list){
			foreach($list as $l){
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 50px;">'.$no.'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$l->nama_barang.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.$l->jumlah.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.number_format($l->harga, 2, ",", ".").'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$l->keterangan.'</td>
					</tr>
				';
				$total += $l->harga;
				$no++;
			}
			$tbl .= '
			<tr>
				<td style="border: 1px solid #000000; width: 275px;" colspan=3>Total Pembelian</td>
				<td style="border: 1px solid #000000; width: 225px;" colspan=2>'.number_format($total, 2, ",", ".").'</td>
			</tr>
		';
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		// $pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output('pembelian-'.$tanggal.'.pdf', 'D');
		
		redirect('aplikasi/pembelian/home/'.$tanggal.'/'.$id_konsumen);
		// ----------------------------------------------------------------------- //
	}
	
	public function print_pdf_rekap($tanggal_awal="", $tanggal_akhir="", $id_konsumen=0){
		$id_konsumen = $this->input->post('id_konsumen');
		$tanggal_awal = $this->input->post('tanggal_awal');
		$tanggal_akhir = $this->input->post('tanggal_akhir');

		//variable yang dibutuhkan
		$row = $this->modelpembelian->getkonsumen($id_konsumen);
		if($row){
			$nama_toko = $row->nama_toko;
			$owner = $row->nama_lengkap;
			$alamat = $row->alamat;
		}
		
		$list = $this->modelpembelian->getAllpembelianrekap($tanggal_awal, $tanggal_akhir, $id_konsumen);
		$aplikasi = $this->modelpembelian->getaplikasi($this->session->userdata('id_aplikasi'));

		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 16);
		$pdf->MultiCell(300, 2, $aplikasi->nama_aplikasi, 0, 'L', 0, 1, 85, 15, true);
		
		$pdf->SetFont('helvetica', '', 12);
		$pdf->MultiCell(300, 2, $aplikasi->alamat, 0, 'L', 0, 1, 25, 25, true);
		
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'Kasir', 0, 'L', 0, 1, 20, 40, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 20, 45, true);
		$pdf->MultiCell(55, 5, 'Owner', 0, 'L', 0, 1, 100, 40, true);
		$pdf->MultiCell(55, 5, 'Toko', 0, 'L', 0, 1, 100, 45, true);
		$pdf->MultiCell(55, 5, 'Alamat', 0, 'L', 0, 1, 100, 50, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 40, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 45, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 130, 50, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $this->session->userdata('nama_lengkap'), 0, 'L', 0, 1, 45, 40, true);
		$pdf->MultiCell(150, 5, $tanggal_awal.' - '.$tanggal_akhir, 0, 'L', 0, 1, 45, 45, true);
		$pdf->MultiCell(100, 5, $owner, 0, 'L', 0, 1, 135, 40, true);
		$pdf->MultiCell(100, 5, $nama_toko, 0, 'L', 0, 1, 135, 45, true);
		$pdf->MultiCell(100, 5, $alamat, 0, 'L', 0, 1, 135, 50, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 60, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 12);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 50px;">No</td>
				<td style="border: 1px solid #000000; width: 100px;">Tanggal</td>
				<td style="border: 1px solid #000000; width: 125px;">Barang</td>
				<td style="border: 1px solid #000000; width: 50px;">Qty/Pcs</td>
				<td style="border: 1px solid #000000; width: 100px;">Harga Total</td>
				<td style="border: 1px solid #000000; width: 75px;">Keterangan</td>
			</tr>
		';

		// foreach item in your array...
		$no=1; $total = 0;
		if($list){
			foreach($list as $l){
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 50px;">'.$no.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.$l->tanggal.'</td>
						<td style="border: 1px solid #000000; width: 125px;">'.$l->nama_barang.'</td>
						<td style="border: 1px solid #000000; width: 50px;">'.$l->jumlah.'</td>
						<td style="border: 1px solid #000000; width: 100px;">'.number_format($l->harga, 2, ",", ".").'</td>
						<td style="border: 1px solid #000000; width: 75px;">'.$l->keterangan.'</td>
					</tr>
				';
				$total += $l->harga;
				$no++;
			}
			$tbl .= '
			<tr>
				<td style="border: 1px solid #000000; width: 325px;" colspan=4>Total pembelian</td>
				<td style="border: 1px solid #000000; width: 175px;" colspan=2>'.number_format($total, 2, ",", ".").'</td>
			</tr>
		';
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		// $pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output('rekap-pembelian-'.$nama_toko.'-'.$tanggal_awal.'-'.$tanggal_akhir.'.pdf', 'D');
		
		redirect('aplikasi/pembelian/home/'.$tanggal_akhir.'/'.$id_konsumen);
		// ----------------------------------------------------------------------- //
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	