<?php 

class History extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelhistory');
		$this->load->model('modelkelas_siswa');
		$this->load->model('modelsiswa');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		$data['listsiswa'] = $this->modelkelas_siswa->getsiswakelas($nis, $nama);

		$this->load->view('history/home', $data);
	}

	public function detail_siswa1($id_siswa=0){
		$list = array();
		
		$siswa = $this->modelsiswa->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$kelas = $this->modelkelas_siswa->getkelassiswabyidsiswa($id_siswa);
		$data['kelas'] = $kelas;

		foreach ($kelas as $k) {
			$list[$k->kelas] = array();
			$list[$k->kelas]['id_tingkat'] = $k->id_tingkat;
			$list[$k->kelas]['tingkat'] = $k->nama_tingkat;
			$list[$k->kelas]['id_kelas'] = $k->id_kelas;
			$list[$k->kelas]['tahun_ajaran'] = $k->tahun_ajaran;
			
		}

		$data['list'] = $list;
		$this->load->view('kelas_siswa/detail_siswa', $data);
	}

	public function detail_siswa($id_siswa=0){
		if($_POST){
			$data['tanggal'] = $this->input->post('tanggal');			
		}else{
			$data['tanggal'] = "";
		}
		
		$siswa = $this->modelsiswa->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$data['listkasir'] = $this->modelsiswa->getAllkasir();
		$data['jumlahkasir'] = $this->modelsiswa->getCountkasir();
		$data['listrekap'] = $this->modelhistory->getrekap($data['tanggal'], $id_siswa);
		$data['listrekap_ppdb'] = $this->modelhistory->getrekap_ppdb($data['tanggal'], $data['nama']);
		$data['listrekap_tabungan'] = $this->modelhistory->getrekap_tabungan($data['tanggal'], $id_siswa);
		
		// echo "<pre>";
		// print_r($data['listrekap_tabungan']);
		// echo "</pre>";
		$this->load->view('history/detail_siswa', $data);	
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	