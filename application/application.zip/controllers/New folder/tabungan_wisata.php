<?php 

class Tabungan_wisata extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modeltabungan');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('Pdf');
		$this->load->library('form_validation');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->load->helper("download");
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modeltabungan->getAllkelas($id_tahun_ajaran);
		$data["kelasimport"] = $this->modeltabungan->getAllkelasimport();
		
		$dana_siswa = $this->modeltabungan->carijenisdana($id_kelas);
		$tingkat = $this->modeltabungan->getkelas($id_kelas);
		$siswa = $this->modeltabungan->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modeltabungan->getjenisdana();
		}else{
			$data["jenis_dana"] = "";
		}
		
		//variable jumlah
		$temp = array();
		
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();

				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_tabungan_wisata] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_tabungan_wisata] = $ds->nilai;
			}
		}
		
		$data["dana"] = $temp;

		$data['listsiswa'] = $this->modeltabungan->getAllsiswa($id_kelas);
		$data['listdana'] = $this->modeltabungan->getAlldana($id_kelas);
		$data["tahun_ajaran"] = $this->modeltabungan->getAlltahun();
		
		$this->load->view('tabungan_wisata/home', $data);
	}
	
	public function tambah_dana(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$dana_siswa = $this->modeltabungan->carijenisdana($id_kelas);
		$tingkat = $this->modeltabungan->getkelas($id_kelas);
		$siswa = $this->modeltabungan->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modeltabungan->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_tabungan_wisata] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_tabungan_wisata] = $ds->nilai;
			}
		}
		
		$data["dana"] = $temp;
		if($tingkat){ $data["tingkat"] = $tingkat->id_tingkat; }else{$data["tingkat"] = 0;}
		$data["kelas"] = $this->modeltabungan->getAllkelas($id_tahun_ajaran);
		$data['listsiswa'] = $this->modeltabungan->getAllsiswa($id_kelas);
		$data["tahun_ajaran"] = $this->modeltabungan->getAlltahun();
		
		$this->load->view('tabungan_wisata/tambah_dana', $data);
	}
	
	public function cetak_kwitansi(){
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modeltabungan->getAllsiswa($perubahan['id_kelas']);
		$saldo = 0;
		foreach($row as $r){
			if($r->id_siswa==$perubahan['id_siswa']){
				$data['nis'] = $r->nis;
				$data['nama'] = $r->nama;
				$data['kelas'] = $r->kelas;
				$data['tingkat'] = $r->id_tingkat;

				$saldo += $this->modeltabungan->getsaldo($perubahan['id_siswa'], $perubahan['id_kelas'])['saldo'];
			}
		}
		
		$data['list'] = $perubahan['list'];
		$data['saldo'] = $saldo;
		// print_r($data);
		$this->load->view('tabungan_wisata/cetak_kwitansi', $data);
	}
	
	public function print_pdf($id=0){
	
		//variable yang dibutuhkan
		$saldo = 0;
		$tanggal = date('Y-m-d');
		$petugas = $this->session->userdata('username');
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modeltabungan->getAllsiswa($perubahan['id_kelas']);
		foreach($row as $r){
			if($r->id_siswa==$perubahan['id_siswa']){
				$nis = $r->nis;
				$nama = $r->nama;
				$kelas = $r->kelas;
				$tingkat = $r->id_tingkat;
				$saldo += $this->modeltabungan->getsaldo($perubahan['id_siswa'], $perubahan['id_kelas'])['saldo'];
			}
		}
		
		$list = $perubahan['list'];
				
		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'B7', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 14);
		$pdf->MultiCell(300, 2, 'Bukti Pembayaran SMAN 1 Larangan Kabupaten Brebes', 0, 'L', 0, 1, 40, 20, true);
		//set image
		$pdf->Image(base_url().'uploads/sma'.'.png', 170, 40, 20, 20, 'PNG', '', 'Center', true, 150, '', false, false, 1, false, false, false);
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'NIS', 0, 'L', 0, 1, 10, 42, true);
		$pdf->MultiCell(55, 5, 'Nama', 0, 'L', 0, 1, 10, 49, true);
		$pdf->MultiCell(55, 5, 'Kelas', 0, 'L', 0, 1, 10, 56, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 10, 63, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 42, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 49, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 56, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 63, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $nis, 0, 'L', 0, 1, 45, 42, true);
		$pdf->MultiCell(100, 5, $nama, 0, 'L', 0, 1, 45, 49, true);
		$pdf->MultiCell(100, 5, $kelas, 0, 'L', 0, 1, 45, 56, true);
		$pdf->MultiCell(100, 5, $tanggal, 0, 'L', 0, 1, 45, 63, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 70, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 10);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 300px;">Jenis Pembayaran Tabungan Wisata</td>
				<td style="border: 1px solid #000000; width: 200px;">Uang Sebesar (Rp.)</td>
			</tr>
		';

		// foreach item in your array...
		$count=0; $jum=0;
		if($list){
			foreach($list as $l=>$val){
				$id=$this->modeltabungan->getjenisdanabyid($l);
				if($tingkat==2 && $id->id_jenis_tabungan_wisata==51){
					$id->nama_jenis = 'PEMBAYARAN STUDI WISATA';
				}
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 300px;">'.$id->nama_jenis.'</td>
						<td style="border: 1px solid #000000; width: 200px;">'.$val.'</td>
					</tr>
				';
				$jum += $val;
				$count++;
			}
			$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 300px;">Saldo Akhir</td>
						<td style="border: 1px solid #000000; width: 200px;">'.$saldo.'</td>
					</tr>
				';
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		$pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		$pdf->SetFont('helvetica', '', 10);


		$pdf->MultiCell(100, 5, 'Brebes, '.$tanggal, 0, 'C', 0, 1, 100, 90+($count*4), true);
		$pdf->MultiCell(100, 5, 'Petugas', 0, 'C', 0, 1, 100, 95+($count*4), true);
		$pdf->MultiCell(100, 5, $petugas, 0, 'C', 0, 1, 100, 120+($count*4), true);
		
		$style = array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => '8,10', 'color' => array(0, 0, 0));
		$pdf->Line(15, 130+($count*4), 195, 130+($count*4), $style);
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output($nis.'-'.$tanggal.'.pdf', 'I');
		
		redirect('home');
		// ----------------------------------------------------------------------- //
	}
	
	public function tambah_dana_tabungan(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		$data['listsiswa'] = $this->modeltabungan->getsiswa($nis, $nama);

		$this->load->view('tabungan_wisata/tambah_dana_tabungan', $data);

	}

	public function detail_dana_tabungan($id_siswa=0){
		$list = array();
		
		$siswa = $this->modeltabungan->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$kelas = $this->modeltabungan->getkelassiswabyidsiswa($id_siswa);
		$data['jenis_dana'] = $this->modeltabungan->getAlljenisdana();
		$data['kelas'] = $kelas;

		foreach ($kelas as $k) {
			$list[$k->kelas] = array();
			$list[$k->kelas]['id_tingkat'] = $k->id_tingkat;
			$list[$k->kelas]['id_kelas'] = $k->id_kelas;
			$list[$k->kelas]['dana'] = array();

			$dana = $this->modeltabungan->caridanasiswa($id_siswa, $k->id_kelas);
			if($dana){
				foreach ($dana as $d) {
					$list[$k->kelas]['dana'][$d->id_jenis_tabungan_wisata] = $d->nilai;
				}
			}
		}

		
		// echo '<pre>';
		// print_r($list);
		// echo '</pre>';

		$data['list'] = $list;
		$this->load->view('tabungan_wisata/detail_dana_tabungan', $data);
	}

	public function tambah($id_siswa=0, $class=0){
		// $nis = isset($_POST['nis'])?$_POST['nis']:"";
		// $nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		// $data["nis"] = $nis;
		// $data["nama"] = $nama;
		// $id_kelas = $this->modeltabungan->getsiswa($nis, $nama);
		$id_kelas = $this->modeltabungan->getsiswadana($id_siswa, $class);
		
		if($id_kelas){
			$dana_siswa = $this->modeltabungan->carijenisdana($id_kelas->id_kelas);
		}else{
			$dana_siswa = "";
		}
		if($id_kelas){
			$tingkat = $this->modeltabungan->getkelas($id_kelas->id_kelas);
		}else{
			$tingkat = "";
		}
		if($tingkat!=""){
			$data["jenis_dana"] = $this->modeltabungan->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		if($id_kelas){
			$siswa = $this->modeltabungan->getAllsiswa($id_kelas->id_kelas);
		}else{
			$siswa = "";
		}
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_tabungan_wisata] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_tabungan_wisata] = $ds->nilai;

			}
		}
		

		$data["dana"] = $temp;
		$data['listsiswa'] = $this->modeltabungan->getsiswadana($id_siswa, $class);
		$this->load->view('tabungan_wisata/tambah', $data);
	}
	
	public function submit_dana_kelas(){
			$id_kelas = $this->input->post('id_kelas');
			$jenis_dana = $this->input->post('jenis_dana');
			
			$status = $this->modeltabungan->carijenisdana($id_kelas);
			
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_tabungan_wisata'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					
					if($status){
						if($this->modeltabungan->getdana_siswa($siswa, $jenis, $id_kelas)){
							$this->modeltabungan->update_dana_kelas($data);
						}else{
							$this->modeltabungan->tambah_dana_kelas($data);
						}
					}else{
						$this->modeltabungan->tambah_dana_kelas($data);
					}
				}
			}
				
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
			
			redirect('tabungan_wisata/home');
			
	}
	
	public function submit_dana_tabungan(){
		$id_siswa = $this->input->post('id_siswa');
		$id_kelas = $this->input->post('id_kelas');
		$jenis_dana = $this->input->post('jenis_dana');
		
		
		$statusadd = 0;
		$temp1 = array();
		$temp1['list'] = array();

		//jika siswanya blum terdaftar
		if(!$this->modeltabungan->carijenisdanabysiswa($id_siswa, $id_kelas)){
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_tabungan_wisata'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					
					$this->modeltabungan->tambah_dana_kelas($data);

					if($val!=0){
						$temp1['list'][$jenis] = $val;

						$row = $this->modeltabungan->getdana_siswa($id_siswa, $jenis, $id_kelas);
						$data1['id_user'] = $this->session->userdata('id_user');
						$data1['id_dana_wisata'] = $row->id_dana_wisata;
						$data1['tanggal'] = date('Y-m-d');
						
						$this->modeltabungan->tambah_rekap($data1);
					}
				}
			}

			$temp1['id_siswa'] = $id_siswa;
			$temp1['id_kelas'] = $id_kelas;
			$statusadd = 1;
			// echo "harusnya ngga masuk sini";
			// print_r($this->modeltabungan->carijenisdana($id_siswa, $id_kelas));
		}

		$status = $this->modeltabungan->carijenisdana($id_kelas);
		$old = $status;
		
		$old = array();
		$old[$id_siswa] = array();
		
		foreach($jenis_dana[$id_siswa] as $a=>$val){
			$old[$id_siswa][$a] = 0;
		}

		foreach($status as $s){
			if($s->id_siswa==$id_siswa){
				$old[$id_siswa][$s->id_jenis_tabungan_wisata] = $s->nilai;
			}
		}

		foreach($jenis_dana as $siswa=>$a){
			foreach($a as $jenis=>$val){
				if($this->modeltabungan->getdana_siswa($siswa, $jenis, $id_kelas)){
					echo $siswa.'ada<br>';
				}else{
					echo 'kosong';
				}
			}
		}
		
		foreach($jenis_dana as $siswa=>$a){
			foreach($a as $jenis=>$val){
				$data['id_siswa'] = $siswa;
				$data['id_jenis_tabungan_wisata'] = $jenis;
				$data['id_kelas'] = $id_kelas;
				$data['nilai'] = $val;
				
				//perhitungan untuk jumlah dimasing-masing kelas



				if($this->modeltabungan->getdana_siswa($siswa, $jenis, $id_kelas)){
					if($status){
						$this->modeltabungan->update_dana_kelas($data);						
					}
				}else{
					$this->modeltabungan->tambah_dana_kelas($data);						
				}
			}
		}

		$new = $jenis_dana;
		
		$temp = array();
		$temp['list'] = array();
		foreach($new[$id_siswa] as $a=>$val){
			if($val != $old[$id_siswa][$a]){
				$temp['list'][$a] = $val;
				
				//rekap harian
				$row = $this->modeltabungan->getdana_siswa($id_siswa, $a, $id_kelas);
				$data1['id_user'] = $this->session->userdata('id_user');
				$data1['id_dana_wisata'] = $row->id_dana_wisata;
				$data1['tanggal'] = date('Y-m-d');
				
				$this->modeltabungan->tambah_rekap($data1);
			}
		}

		$temp['id_siswa'] = $id_siswa;
		$temp['id_kelas'] = $id_kelas;
		
		if($statusadd==0){
			$this->session->set_userdata("data",$temp);
		}else{
			$this->session->set_userdata("data",$temp1);
		}

		$this->session->set_flashdata('message', 'Data berhasil ditambah!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('tabungan_wisata/cetak_kwitansi');
			
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('tabungan_wisata');
		}
		
		$this->modeltabungan->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('tabungan_wisata/home');
	}
	
	public function download_x(){
		$file = base_url().'uploads/template_tabungan_wisata_x.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function download_xi(){
		$file = base_url().'uploads/template_tabungan_wisata_xi.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function import_dana(){
		
		$fileName = date('Y-m-d').'_tabunganwisata_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/tabungan_wisata/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/tabungan_wisata/'.$media['file_name'];

        $id_kelas = $this->input->post('kelas');
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
            
            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

            	$siswa =  $this->modeltabungan->getsiswabynis($rowData[0][1]);

            	if($siswa){
	                for($i=4;$i<count($rowData[0]);$i++){
	                	$data = array(
		                    "id_siswa"=> $siswa['id_siswa'],
		                    "id_kelas"=> $id_kelas,
		                    "id_jenis_tabungan_wisata"=> $i-3,
		                    "nilai"=> $rowData[0][$i]
	                	);

	                	// print_r($data);
            			$this->modeltabungan->update_dana_kelas($data);
	            	}
            	}
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('tabungan_wisata/');
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}