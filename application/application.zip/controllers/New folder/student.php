<?php 

class Student extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelstudent');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		
		$config = array();
        $config["base_url"] = base_url() . "student/home";
        $config["total_rows"] = $this->modelstudent->countsiswa($nis, $nama);
        $config["per_page"] = 25;
        $config["uri_segment"] = 3;
		
		//css pagination
		$config['full_tag_open'] = "<ul class='pagination pull-right'>";
		$config['full_tag_close'] ="</ul>";
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
		$config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
		$config['next_tag_open'] = "<li>";
		$config['next_tagl_close'] = "</li>";
		$config['prev_tag_open'] = "<li>";
		$config['prev_tagl_close'] = "</li>";
		$config['first_tag_open'] = "<li>";
		$config['first_tagl_close'] = "</li>";
		$config['last_tag_open'] = "<li>";
		$config['last_tagl_close'] = "</li>";
		
		
		$this->pagination->initialize($config);

		$page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data["listsiswa"] = $this->modelstudent->getAllsiswa($config["per_page"], $page, $nis, $nama);
		
		$data["page"] = $page;
		$data["links"] = $this->pagination->create_links();
		
		$this->load->view('student/home', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		
		$data['id_siswa'] = null;
		$data['nis'] = null;
		$data['nisn'] = null;
		$data['nama'] = null;
		$data['jenis_kelamin'] = null;
		
		$this->load->view('student/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('student');
		}
		
		$row=$this->modelstudent->getsiswa($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_siswa'] = $row->id_siswa;
		$data['nis'] = $row->nis;
		$data['nisn'] = $row->nisn;
		$data['nama'] = $row->nama;
		$data['jenis_kelamin'] = $row->jenis_kelamin;
		
		$this->load->view('student/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('student');
		}
		
		$this->modelstudent->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('student');
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama', 'nama', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id = $this->input->post('id');
			$nis = $this->input->post('nis');
			$nisn = $this->input->post('nisn');
			$nama = $this->input->post('nama');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$jenis = $this->input->post('jenis');
			
			$data['nis'] = $nis;
			$data['nisn'] = $nisn;
			$data['nama'] = $nama;
			$data['jenis_kelamin'] = $jenis_kelamin;
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelstudent->tambah($data);
				redirect('student/');
			}else{
				$data['id_siswa'] = $id;
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelstudent->ubah($data);
				redirect('student/');
			}
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenis=='tambah'){
				redirect('student/tambah');
			}else{
				redirect('student/ubah/'. $id);
			}
		}
	}

	public function download(){
		$file = base_url().'uploads/template_siswa.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function import_siswa(){
		
		$fileName = date('Y-m-d').'_siswa_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/siswa/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/siswa/'.$media['file_name'];
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
             
            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

                //Sesuaikan sama nama kolom tabel di database                                
                 $data = array(
                    "nis"=> $rowData[0][1],
                    "nisn"=> $rowData[0][2],
                    "nama"=> $rowData[0][3],
                    "jenis_kelamin"=> $rowData[0][4]
                );
                 
                //sesuaikan nama dengan nama tabel
                $insert = $this->db->insert("siswa",$data);
                // delete_files($media['file_path']);
                
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('student/');
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	