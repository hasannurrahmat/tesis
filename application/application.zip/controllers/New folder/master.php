<?php 

class Master extends CI_Controller{

	public function __construct(){
		parent::__construct();
		
	}
	
	public function index(){
		
	}
	
	public function user(){

		$this->load->view('user/home');
	}
	
	public function user_tambah(){

		$this->load->view('user/tambah');
	}
	public function barang(){

		$this->load->view('barang/home');
	}
	
	public function konsumen(){

		$this->load->view('konsumen/home');
	}

	public function konsumen_tambah(){

		$this->load->view('konsumen/tambah');
	}
}	