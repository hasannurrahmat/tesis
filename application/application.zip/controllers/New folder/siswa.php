<?php 

class Siswa extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelsiswa');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('Pdf');
		$this->load->library('form_validation');
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->load->helper("download");
		$this->is_logged_in();

		error_reporting(0);
        ini_set('display_errors', 0);
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		$data["kelasimport"] = $this->modelsiswa->getAllkelasimport();
		
		$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas);
		$tingkat = $this->modelsiswa->getkelas($id_kelas);
		$siswa = $this->modelsiswa->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		//variable jumlah
		$temp = array();
		
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();

				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;
			}
		}
		
		//menghitung jumlah
		if($tingkat){
			foreach($temp as $d=>$val){
				if($tingkat->id_tingkat==1){
					//komite per tahun
					$temp[$d][3] = $val[2] * 12;
					// $terbayar[$d]
					$temp[$d][105] = $val[7] + $val[9] + $val[10] + $val[11] + $val[12] + $val[13] + $val[14] + $val[15] + $val[16] + $val[17] + $val[18] + $val[19];
					// $pembangunan[$d] 
					$temp[$d][106] = $val[1] - ($val[4]+$val[5]+$val[6]);
					// $daftarulang[$d] 
					$temp[$d][107] = $val[99] + $val[100] - ($val[101] + $val[102] + $val[103] + $val[104]);
					// $tunggakankomite[$d] 
					$temp[$d][108] = $temp[$d][3] - $temp[$d][105];
					// $tunggakantotal[$d] 
					$temp[$d][109] = $temp[$d][106] + $temp[$d][107] + $temp[$d][108];

				}else if($tingkat->id_tingkat==2){
					//komite per tahun
					$temp[$d][23] = $val[22] * 12;
					// $terbayar[$d] 
					$temp[$d][94] = $val[30] + $val[32] + $val[33] + $val[34] + $val[35] + $val[36] + $val[37] + $val[38] + $val[39] + $val[40] + $val[41] + $val[42];
					// $pembangunan[$d] 
					$temp[$d][95] = $val[20] - ($val[24]+$val[25]+$val[26]);
					// $daftarulang[$d] 
					$temp[$d][96] = $val[86] + $val[87] + $val[88] - ($val[89] + $val[90] + $val[91] + $val[92] + $val[93]);
					// $tunggakankomite[$d] 
					$temp[$d][97] = $val[21] + $temp[$d][23] - ($temp[$d][94] + $val[27] + $val[28] + $val[29]);
					// $tunggakantotal[$d] 
					$temp[$d][98] = $temp[$d][95] + $temp[$d][96] + $temp[$d][97];

				}else{
					//komite per tahun
					$temp[$d][47] = $val[46] * 12;
					// $terbayar[$d] 
					$temp[$d][80] = $val[57] + $val[59] + $val[60] + $val[61] + $val[62] + $val[63] + $val[64] + $val[65] + $val[66] + $val[67] + $val[68] + $val[69];
					// $pembangunan[$d] 
					$temp[$d][81] = $val[43] - ($val[48]+$val[49]+$val[50]);
					// $daftarulang[$d] 
					$temp[$d][82] = $val[70] + $val[71] + $val[72] - ($val[74] + $val[75] + $val[76] + $val[77] + $val[78]);
					// $tunggakankomite[$d] 
					$temp[$d][83] = $val[44] + $temp[$d][47] - ($temp[$d][80] + $val[51] + $val[52] + $val[53]);
					// $kenangan[$d] 
					$temp[$d][84] = $val[73] - $val[79];
					// $tunggakantotal[$d] 
					$temp[$d][85] = $temp[$d][81] + $temp[$d][82] + $temp[$d][83] + $temp[$d][84];
					
				}
			}
		}

		$data["dana"] = $temp;

		$data['listsiswa'] = $this->modelsiswa->getAllsiswa($id_kelas);
		$data['listdana'] = $this->modelsiswa->getAlldana($id_kelas);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();
		
		$this->load->view('siswa/home', $data);
	}
	
	public function tunggakan(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		$data["kelasimport"] = $this->modelsiswa->getAllkelasimport();
		
		$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas);
		$tingkat = $this->modelsiswa->getkelas($id_kelas);
		$siswa = $this->modelsiswa->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		//variable jumlah
		$temp = array();
		
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();

				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;
			}
		}
		
		//menghitung jumlah
		if($tingkat){
			foreach($temp as $d=>$val){
				if($tingkat->id_tingkat==1){
					//komite per tahun
					$temp[$d][3] = $val[2] * 12;
					// $terbayar[$d]
					$temp[$d][105] = $val[7] + $val[9] + $val[10] + $val[11] + $val[12] + $val[13] + $val[14] + $val[15] + $val[16] + $val[17] + $val[18] + $val[19];
					// $pembangunan[$d] 
					$temp[$d][106] = $val[1] - ($val[4]+$val[5]+$val[6]);
					// $daftarulang[$d] 
					$temp[$d][107] = $val[99] + $val[100] - ($val[101] + $val[102] + $val[103] + $val[104]);
					// $tunggakankomite[$d] 
					$temp[$d][108] = $temp[$d][3] - $temp[$d][105];
					// $tunggakantotal[$d] 
					$temp[$d][109] = $temp[$d][106] + $temp[$d][107] + $temp[$d][108];

				}else if($tingkat->id_tingkat==2){
					//komite per tahun
					$temp[$d][23] = $val[22] * 12;
					// $terbayar[$d] 
					$temp[$d][94] = $val[30] + $val[32] + $val[33] + $val[34] + $val[35] + $val[36] + $val[37] + $val[38] + $val[39] + $val[40] + $val[41] + $val[42];
					// $pembangunan[$d] 
					$temp[$d][95] = $val[20] - ($val[24]+$val[25]+$val[26]);
					// $daftarulang[$d] 
					$temp[$d][96] = $val[86] + $val[87] + $val[88] - ($val[89] + $val[90] + $val[91] + $val[92] + $val[93]);
					// $tunggakankomite[$d] 
					$temp[$d][97] = $val[21] + $temp[$d][23] - ($temp[$d][94] + $val[27] + $val[28] + $val[29]);
					// $tunggakantotal[$d] 
					$temp[$d][98] = $temp[$d][95] + $temp[$d][96] + $temp[$d][97];

				}else{
					//komite per tahun
					$temp[$d][47] = $val[46] * 12;
					// $terbayar[$d] 
					$temp[$d][80] = $val[57] + $val[59] + $val[60] + $val[61] + $val[62] + $val[63] + $val[64] + $val[65] + $val[66] + $val[67] + $val[68] + $val[69];
					// $pembangunan[$d] 
					$temp[$d][81] = $val[43] - ($val[48]+$val[49]+$val[50]);
					// $daftarulang[$d] 
					$temp[$d][82] = $val[70] + $val[71] + $val[72] - ($val[74] + $val[75] + $val[76] + $val[77] + $val[78]);
					// $tunggakankomite[$d] 
					$temp[$d][83] = $val[44] + $temp[$d][47] - ($temp[$d][80] + $val[51] + $val[52] + $val[53]);
					// $kenangan[$d] 
					$temp[$d][84] = $val[73] - $val[79];
					// $tunggakantotal[$d] 
					$temp[$d][85] = $temp[$d][81] + $temp[$d][82] + $temp[$d][83] + $temp[$d][84];
					
				}
			}
		}

		$data["dana"] = $temp;

		$data['listsiswa'] = $this->modelsiswa->getAllsiswa($id_kelas);
		$data['listdana'] = $this->modelsiswa->getAlldana($id_kelas);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();
		
		$this->load->view('siswa/tunggakan', $data);
	}

	public function tambah_dana(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas);
		$tingkat = $this->modelsiswa->getkelas($id_kelas);
		$siswa = $this->modelsiswa->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;
			}
		}
		
		foreach($temp as $d=>$val){
			if($tingkat->id_tingkat==1){
				//komite per tahun
				$temp[$d][3] = $val[2] * 12;
				// $terbayar[$d]
				$temp[$d][105] = $val[7] + $val[9] + $val[10] + $val[11] + $val[12] + $val[13] + $val[14] + $val[15] + $val[16] + $val[17] + $val[18] + $val[19];
				// $pembangunan[$d] 
				$temp[$d][106] = $val[1] - ($val[4]+$val[5]+$val[6]);
				// $daftarulang[$d] 
				$temp[$d][107] = $val[99] + $val[100] - ($val[101] + $val[102] + $val[103] + $val[104]);
				// $tunggakankomite[$d] 
				$temp[$d][108] = $temp[$d][3] - $temp[$d][105];
				// $tunggakantotal[$d] 
				$temp[$d][109] = $temp[$d][106] + $temp[$d][107] + $temp[$d][108];

			}else if($tingkat->id_tingkat==2){
				//komite per tahun
				$temp[$d][23] = $val[22] * 12;
				// $terbayar[$d] 
				$temp[$d][94] = $val[30] + $val[32] + $val[33] + $val[34] + $val[35] + $val[36] + $val[37] + $val[38] + $val[39] + $val[40] + $val[41] + $val[42];
				// $pembangunan[$d] 
				$temp[$d][95] = $val[20] - ($val[24]+$val[25]+$val[26]);
				// $daftarulang[$d] 
				$temp[$d][96] = $val[86] + $val[87] + $val[88] - ($val[89] + $val[90] + $val[91] + $val[92] + $val[93]);
				// $tunggakankomite[$d] 
				$temp[$d][97] = $val[21] + $temp[$d][23] - ($temp[$d][94] + $val[27] + $val[28] + $val[29]);
				// $tunggakantotal[$d] 
				$temp[$d][98] = $temp[$d][95] + $temp[$d][96] + $temp[$d][97];

			}else{
				//komite per tahun
				$temp[$d][47] = $val[46] * 12;
				// $terbayar[$d] 
				$temp[$d][80] = $val[57] + $val[59] + $val[60] + $val[61] + $val[62] + $val[63] + $val[64] + $val[65] + $val[66] + $val[67] + $val[68] + $val[69];
				// $pembangunan[$d] 
				$temp[$d][81] = $val[43] - ($val[48]+$val[49]+$val[50]);
				// $daftarulang[$d] 
				$temp[$d][82] = $val[70] + $val[71] + $val[72] - ($val[74] + $val[75] + $val[76] + $val[77] + $val[78]);
				// $tunggakankomite[$d] 
				$temp[$d][83] = $val[44] + $temp[$d][47] - ($temp[$d][80] + $val[51] + $val[52] + $val[53]);
				// $kenangan[$d] 
				$temp[$d][84] = $val[73] - $val[79];
				// $tunggakantotal[$d] 
				$temp[$d][85] = $temp[$d][81] + $temp[$d][82] + $temp[$d][83] + $temp[$d][84];
				
			}
		}

		$data["dana"] = $temp;
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		$data['listsiswa'] = $this->modelsiswa->getAllsiswa($id_kelas);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();
		
		$this->load->view('siswa/tambah_dana', $data);
	}
		
	public function cetak_kwitansi(){
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modelsiswa->getAllsiswa($perubahan['id_kelas']);
		foreach($row as $r){
			if($r->id_siswa==$perubahan['id_siswa']){
				$data['nis'] = $r->nis;
				$data['nama'] = $r->nama;
				$data['kelas'] = $r->kelas;
			}
		}
		
		$data['list'] = $perubahan['list'];
		// print_r($data);
		$this->load->view('siswa/cetak_kwitansi', $data);
	}
	
	public function print_pdf($id=0){
	
		//variable yang dibutuhkan
		$tanggal = date('Y-m-d');
		$petugas = $this->session->userdata('username');
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modelsiswa->getAllsiswa($perubahan['id_kelas']);
		foreach($row as $r){
			if($r->id_siswa==$perubahan['id_siswa']){
				$nis = $r->nis;
				$nama = $r->nama;
				$kelas = $r->kelas;
			}
		}
		
		$list = $perubahan['list'];
				
		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'B7', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 14);
		$pdf->MultiCell(300, 2, 'Bukti Pembayaran SMAN 1 Larangan Kabupaten Brebes', 0, 'L', 0, 1, 40, 20, true);
		//set image
		$pdf->Image(base_url().'uploads/sma'.'.png', 170, 40, 20, 20, 'PNG', '', 'Center', true, 150, '', false, false, 1, false, false, false);
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'NIS', 0, 'L', 0, 1, 10, 42, true);
		$pdf->MultiCell(55, 5, 'Nama', 0, 'L', 0, 1, 10, 49, true);
		$pdf->MultiCell(55, 5, 'Kelas', 0, 'L', 0, 1, 10, 56, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 10, 63, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 42, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 49, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 56, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 40, 63, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $nis, 0, 'L', 0, 1, 45, 42, true);
		$pdf->MultiCell(100, 5, $nama, 0, 'L', 0, 1, 45, 49, true);
		$pdf->MultiCell(100, 5, $kelas, 0, 'L', 0, 1, 45, 56, true);
		$pdf->MultiCell(100, 5, $tanggal, 0, 'L', 0, 1, 45, 63, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 70, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 10);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 300px;">Jenis Pembayaran</td>
				<td style="border: 1px solid #000000; width: 200px;">Uang Sebesar (Rp.)</td>
			</tr>
		';

		// foreach item in your array...
		$count=0; $jum=0;
		if($list){
			foreach($list as $l=>$val){
				$id=$this->modelsiswa->getjenisdanabyid($l); echo $id->jenis_dana;
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 300px;">'.$id->jenis_dana.'</td>
						<td style="border: 1px solid #000000; width: 200px;">'.$val.'</td>
					</tr>
				';
				$jum += $val;
				$count++;
			}
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		$pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		$pdf->SetFont('helvetica', '', 10);


		$pdf->MultiCell(100, 5, 'Brebes, '.$tanggal, 0, 'C', 0, 1, 100, 90+($count*4), true);
		$pdf->MultiCell(100, 5, 'Petugas', 0, 'C', 0, 1, 100, 95+($count*4), true);
		$pdf->MultiCell(100, 5, $petugas, 0, 'C', 0, 1, 100, 120+($count*4), true);
		
		$style = array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => '8,10', 'color' => array(0, 0, 0));
		$pdf->Line(15, 130+($count*4), 195, 130+($count*4), $style);
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output($nis.'-'.$tanggal.'.pdf', 'I');
		
		redirect('home');
		// ----------------------------------------------------------------------- //
	}
	
	public function tambah_dana_siswa(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		$data['listsiswa'] = $this->modelsiswa->getsiswa($nis, $nama);

		$this->load->view('siswa/tambah_dana_siswa', $data);
	}

	public function detail_dana_siswa($id_siswa=0){
		$list = array();
		
		$siswa = $this->modelsiswa->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$kelas = $this->modelsiswa->getkelassiswabyidsiswa($id_siswa);
		$data['jenis_dana'] = $this->modelsiswa->getAlljenisdana();
		$data['kelas'] = $kelas;

		foreach ($kelas as $k) {
			$list[$k->kelas] = array();
			$list[$k->kelas]['id_tingkat'] = $k->id_tingkat;
			$list[$k->kelas]['id_kelas'] = $k->id_kelas;
			$list[$k->kelas]['dana'] = array();

			$dana = $this->modelsiswa->caridanasiswa($id_siswa, $k->id_kelas);
			if($dana){
				foreach ($dana as $d) {
					$list[$k->kelas]['dana'][$d->id_jenis_dana] = $d->nilai;
				}
			}
		}

		foreach($list as $k=>$j){
			// echo $j['dana'][1];
			// echo $list[$k]['dana'][1];
			if($j['id_tingkat']==1){
				if($j['dana']){
					//komite per tahun
					$list[$k]['dana'][3] = $j['dana'][2] * 12;
					// $terbayar[$d]
					$list[$k]['dana'][105] = $j['dana'][7] + $j['dana'][9] + $j['dana'][10] + $j['dana'][11] + $j['dana'][12] + $j['dana'][13] + $j['dana'][14] + $j['dana'][15] + $j['dana'][16] + $j['dana'][17] + $j['dana'][18] + $j['dana'][19];
					// $pembangunan[$d] 
					$list[$k]['dana'][106] = $j['dana'][1] - ($j['dana'][4]+$j['dana'][5]+$j['dana'][6]);
					// $daftarulang[$d] 
					$list[$k]['dana'][107] = $j['dana'][99] + $j['dana'][100] - ($j['dana'][101] + $j['dana'][102] + $j['dana'][103] + $j['dana'][104]);
					// $tunggakankomite[$d] 
					$list[$k]['dana'][108] = $list[$k]['dana'][3] - $list[$k]['dana'][105];
					// $tunggakantotal[$d] 
					$list[$k]['dana'][109] = $list[$k]['dana'][106] + $list[$k]['dana'][107] + $list[$k]['dana'][108];
				}
			}else if($j['id_tingkat']==2){
				if($j['dana']){
					//komite per tahun
					$list[$k]['dana'][23] = $j['dana'][22] * 12;
					// $terbayar[$d] 
					$list[$k]['dana'][94] = $j['dana'][30] + $j['dana'][32] + $j['dana'][33] + $j['dana'][34] + $j['dana'][35] + $j['dana'][36] + $j['dana'][37] + $j['dana'][38] + $j['dana'][39] + $j['dana'][40] + $j['dana'][41] + $j['dana'][42];
					// $pembangunan[$d] 
					$list[$k]['dana'][95] = $j['dana'][20] - ($j['dana'][24]+$j['dana'][25]+$j['dana'][26]);
					// $daftarulang[$d] 
					$list[$k]['dana'][96] = $j['dana'][86] + $j['dana'][87] + $j['dana'][88] - ($j['dana'][89] + $j['dana'][90] + $j['dana'][91] + $j['dana'][92] + $j['dana'][93]);
					// $tunggakankomite[$d] 
					$list[$k]['dana'][97] = $j['dana'][21] + $list[$k]['dana'][23] - ($list[$k]['dana'][94] + $j['dana'][27] + $j['dana'][28] + $j['dana'][29]);
					// $tunggakantotal[$d] 
					$list[$k]['dana'][98] = $list[$k]['dana'][95] + $list[$k]['dana'][96] + $list[$k]['dana'][97];
				}
			}else{
				if($j['dana']){
					//komite per tahun
					$list[$k]['dana'][47] = $j['dana'][46] * 12;
					// $terbayar[$d] 
					$list[$k]['dana'][80] = $j['dana'][57] + $j['dana'][59] + $j['dana'][60] + $j['dana'][61] + $j['dana'][62] + $j['dana'][63] + $j['dana'][64] + $j['dana'][65] + $j['dana'][66] + $j['dana'][67] + $j['dana'][68] + $j['dana'][69];
					// $pembangunan[$d] 
					$list[$k]['dana'][81] = $j['dana'][43] - ($j['dana'][48]+$j['dana'][49]+$j['dana'][50]);
					// $daftarulang[$d] 
					$list[$k]['dana'][82] = $j['dana'][70] + $j['dana'][71] + $j['dana'][72] - ($j['dana'][74] + $j['dana'][75] + $j['dana'][76] + $j['dana'][77] + $j['dana'][78]);
					// $tunggakankomite[$d] 
					$list[$k]['dana'][83] = $j['dana'][44] + $list[$k]['dana'][47] - ($list[$k]['dana'][80] + $j['dana'][51] + $j['dana'][52] + $j['dana'][53]);
					// $kenangan[$d] 
					$list[$k]['dana'][84] = $j['dana'][73] - $j['dana'][79];
					// $tunggakantotal[$d] 
					$list[$k]['dana'][85] = $list[$k]['dana'][81] + $list[$k]['dana'][82] + $list[$k]['dana'][83] + $list[$k]['dana'][84];
					
				}
			}
		}
		
		// echo '<pre>';
		// print_r($list);
		// echo '</pre>';

		$data['list'] = $list;
		$this->load->view('siswa/detail_dana_siswa', $data);
	}

	public function tambah($id_siswa=0, $class=0){
		// $nis = isset($_POST['nis'])?$_POST['nis']:"";
		// $nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		// $data["nis"] = $nis;
		// $data["nama"] = $nama;
		// $id_kelas = $this->modelsiswa->getsiswa($nis, $nama);
		$id_kelas = $this->modelsiswa->getsiswadana($id_siswa, $class);
		
		if($id_kelas){
			$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas->id_kelas);
		}else{
			$dana_siswa = "";
		}
		if($id_kelas){
			$tingkat = $this->modelsiswa->getkelas($id_kelas->id_kelas);
		}else{
			$tingkat = "";
		}
		if($tingkat!=""){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		if($id_kelas){
			$siswa = $this->modelsiswa->getAllsiswa($id_kelas->id_kelas);
		}else{
			$siswa = "";
		}
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;

			}
		}
		
		foreach($temp as $d=>$val){
			if($tingkat->id_tingkat==1){
				//komite per tahun
				$temp[$d][3] = $val[2] * 12;
				// $terbayar[$d]
				$temp[$d][105] = $val[7] + $val[9] + $val[10] + $val[11] + $val[12] + $val[13] + $val[14] + $val[15] + $val[16] + $val[17] + $val[18] + $val[19];
				// $pembangunan[$d] 
				$temp[$d][106] = $val[1] - ($val[4]+$val[5]+$val[6]);
				// $daftarulang[$d] 
				$temp[$d][107] = $val[99] + $val[100] - ($val[101] + $val[102] + $val[103] + $val[104]);
				// $tunggakankomite[$d] 
				$temp[$d][108] = $temp[$d][3] - $temp[$d][105];
				// $tunggakantotal[$d] 
				$temp[$d][109] = $temp[$d][106] + $temp[$d][107] + $temp[$d][108];

			}else if($tingkat->id_tingkat==2){
				//komite per tahun
				$temp[$d][23] = $val[22] * 12;
				// $terbayar[$d] 
				$temp[$d][94] = $val[30] + $val[32] + $val[33] + $val[34] + $val[35] + $val[36] + $val[37] + $val[38] + $val[39] + $val[40] + $val[41] + $val[42];
				// $pembangunan[$d] 
				$temp[$d][95] = $val[20] - ($val[24]+$val[25]+$val[26]);
				// $daftarulang[$d] 
				$temp[$d][96] = $val[86] + $val[87] + $val[88] - ($val[89] + $val[90] + $val[91] + $val[92] + $val[93]);
				// $tunggakankomite[$d] 
				$temp[$d][97] = $val[21] + $temp[$d][23] - ($temp[$d][94] + $val[27] + $val[28] + $val[29]);
				// $tunggakantotal[$d] 
				$temp[$d][98] = $temp[$d][95] + $temp[$d][96] + $temp[$d][97];

			}else{
				//komite per tahun
				$temp[$d][47] = $val[46] * 12;
				// $terbayar[$d] 
				$temp[$d][80] = $val[57] + $val[59] + $val[60] + $val[61] + $val[62] + $val[63] + $val[64] + $val[65] + $val[66] + $val[67] + $val[68] + $val[69];
				// $pembangunan[$d] 
				$temp[$d][81] = $val[43] - ($val[48]+$val[49]+$val[50]);
				// $daftarulang[$d] 
				$temp[$d][82] = $val[70] + $val[71] + $val[72] - ($val[74] + $val[75] + $val[76] + $val[77] + $val[78]);
				// $tunggakankomite[$d] 
				$temp[$d][83] = $val[44] + $temp[$d][47] - ($temp[$d][80] + $val[51] + $val[52] + $val[53]);
				// $kenangan[$d] 
				$temp[$d][84] = $val[73] - $val[79];
				// $tunggakantotal[$d] 
				$temp[$d][85] = $temp[$d][81] + $temp[$d][82] + $temp[$d][83] + $temp[$d][84];
				
			}
		}

		$data["dana"] = $temp;
		$data['listsiswa'] = $this->modelsiswa->getsiswadana($id_siswa, $class);
		$this->load->view('siswa/tambah', $data);
	}
	
	public function submit_dana_kelas(){
			$id_kelas = $this->input->post('id_kelas');
			$jenis_dana = $this->input->post('jenis_dana');
			
			$status = $this->modelsiswa->carijenisdana($id_kelas);
			
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_dana'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					
					if($status){
						if($this->modelsiswa->getdana_siswa($siswa, $jenis, $id_kelas)){
							$this->modelsiswa->update_dana_kelas($data);
						}else{
							$this->modelsiswa->tambah_dana_kelas($data);
						}
					}else{
						$this->modelsiswa->tambah_dana_kelas($data);
					}
				}
			}
				
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
			
			redirect('siswa/home');
	}
	
	public function submit_dana_siswa(){
		$id_siswa = $this->input->post('id_siswa');
		$id_kelas = $this->input->post('id_kelas');
		$jenis_dana = $this->input->post('jenis_dana');
		
		
		$statusadd = 0;
		$temp1 = array();
		$temp1['list'] = array();
		//jika siswanya blum terdaftar
		if(!$this->modelsiswa->carijenisdanabysiswa($id_siswa, $id_kelas)){
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_dana'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					

					$this->modelsiswa->tambah_dana_kelas($data);

					if($val!=0){
						$temp1['list'][$jenis] = $val;

						$row = $this->modelsiswa->getdana_siswa($id_siswa, $jenis, $id_kelas);
						$data1['id_user'] = $this->session->userdata('id_user');
						$data1['id_dana_siswa'] = $row->id_dana_siswa;
						$data1['tanggal'] = date('Y-m-d');
						
						$this->modelsiswa->tambah_rekap($data1);
					}
				}
			}

			$temp1['id_siswa'] = $id_siswa;
			$temp1['id_kelas'] = $id_kelas;
			$statusadd = 1;
			// echo "harusnya ngga masuk sini";
			// print_r($this->modelsiswa->carijenisdana($id_siswa, $id_kelas));
		}

		$status = $this->modelsiswa->carijenisdana($id_kelas);
		$old = $status;
		
		$old = array();
		$old[$id_siswa] = array();
		
		foreach($jenis_dana[$id_siswa] as $a=>$val){
			$old[$id_siswa][$a] = 0;
		}

		foreach($status as $s){
			if($s->id_siswa==$id_siswa){
				$old[$id_siswa][$s->id_jenis_dana] = $s->nilai;
			}
		}

		foreach($jenis_dana as $siswa=>$a){
			foreach($a as $jenis=>$val){
				if($this->modelsiswa->getdana_siswa($siswa, $jenis, $id_kelas)){
					echo $siswa.'ada<br>';
				}else{
					echo 'kosong';
				}
			}
		}
		
		foreach($jenis_dana as $siswa=>$a){
			foreach($a as $jenis=>$val){
				$data['id_siswa'] = $siswa;
				$data['id_jenis_dana'] = $jenis;
				$data['id_kelas'] = $id_kelas;
				$data['nilai'] = $val;
				
				//perhitungan untuk jumlah dimasing-masing kelas



				if($this->modelsiswa->getdana_siswa($siswa, $jenis, $id_kelas)){
					if($status){
						$this->modelsiswa->update_dana_kelas($data);						
					}
				}else{
					$this->modelsiswa->tambah_dana_kelas($data);						
				}
			}
		}

		$new = $jenis_dana;
		
		$temp = array();
		$temp['list'] = array();
		foreach($new[$id_siswa] as $a=>$val){
			if($val != $old[$id_siswa][$a]){
				$temp['list'][$a] = $val;
				
				//rekap harian
				$row = $this->modelsiswa->getdana_siswa($id_siswa, $a, $id_kelas);
				$data1['id_user'] = $this->session->userdata('id_user');
				$data1['id_dana_siswa'] = $row->id_dana_siswa;
				$data1['tanggal'] = date('Y-m-d');
				
				$this->modelsiswa->tambah_rekap($data1);
			}
		}

		$temp['id_siswa'] = $id_siswa;
		$temp['id_kelas'] = $id_kelas;
		
		if($statusadd==0){
			$this->session->set_userdata("data",$temp);
		}else{
			$this->session->set_userdata("data",$temp1);
		}
		
		$this->session->set_flashdata('message', 'Data berhasil ditambah!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('siswa/cetak_kwitansi');	
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		$this->modelsiswa->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('siswa/home');
	}
	
	public function hapus_rekap_pembayaran($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		$this->modelsiswa->hapus_rekap_pembayaran($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('siswa/rekap');
	}

	public function hapus_rekap_ppdb($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		$this->modelsiswa->hapus_rekap_ppdb($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('siswa/rekap');
	}

	public function hapus_rekap_wisata($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		$this->modelsiswa->hapus_rekap_wisata($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('siswa/rekap');
	}

	public function rekap(){
		if($_POST){
			$data['tanggal'] = $this->input->post('tanggal');			
		}else{
			$data['tanggal'] = date("Y-m-d");
		}
		
		$data['listkasir'] = $this->modelsiswa->getAllkasir();
		$data['jumlahkasir'] = $this->modelsiswa->getCountkasir();
		$data['listrekap'] = $this->modelsiswa->getrekap($data['tanggal']);
		$data['listrekap_ppdb'] = $this->modelsiswa->getrekap_ppdb($data['tanggal']);
		$data['listrekap_tabungan'] = $this->modelsiswa->getrekap_tabungan($data['tanggal']);
		$seluruh_tabungan = $this->modelsiswa->getrekap_seluruhtabungan();
		$count = 0; $jum=0;
		foreach ($seluruh_tabungan as $s){
			$count++;
			$jum+=$s->jumlah;
		}
		$data['jum_siswa'] = $count;
		$data['jum_total'] = $jum;
		
		$this->load->view('siswa/rekap', $data);	
	}

	public function download_x(){
		$file = base_url().'uploads/template_dana_x.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function download_xi(){
		$file = base_url().'uploads/template_dana_xi.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function download_xii(){
		$file = base_url().'uploads/template_dana_xii.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function import_dana(){
		
		$fileName = date('Y-m-d').'_danasiswa_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/dana_siswa/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/dana_siswa/'.$media['file_name'];

        $id_kelas = $this->input->post('kelas');
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
            
            $jenis_dana = array();

            for ($row = 4; $row <= 4; $row++){
            	$rowData1 = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);
            	for($i=4;$i<count($rowData1[0]);$i++){
            		$jenis_dana[$i] = $rowData1[0][$i];
            	}
            }

            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

            	$siswa =  $this->modelsiswa->getsiswabynis($rowData[0][1]);

            	if($siswa){
	                for($i=4;$i<count($rowData[0]);$i++){
	                	$data = array(
		                    "id_siswa"=> $siswa['id_siswa'],
		                    "id_kelas"=> $id_kelas,
		                    "id_jenis_dana"=> $jenis_dana[$i],
		                    "nilai"=> $rowData[0][$i]
	                	);

            			$this->modelsiswa->update_dana_kelas($data);
	            	}
            	}
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('siswa/');
	}

	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}