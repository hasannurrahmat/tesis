<?php 

class Kelas_siswa extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelkelas_siswa');
		$this->load->model('modelsiswa');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($id_tahun_ajaran=0, $id_kelas=0){
		
		$data["listkelas_siswa"] = $this->modelkelas_siswa->getAllkelas_siswa();
		
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modelkelas_siswa->getAllkelas($id_tahun_ajaran);
		$data["tahun_ajaran"] = $this->modelkelas_siswa->getAlltahun_ajaran();
		
		$this->load->view('kelas_siswa/home', $data);
	}
	
	public function tambah($tahun_ajaran=0, $kelas=0){
		$data['jenis'] = 'tambah';
		
		
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:$tahun_ajaran;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:$kelas;
		
		$kelas_siswa = $this->modelkelas_siswa->getskelas_siswa($id_kelas);
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modelkelas_siswa->getAllkelas($id_tahun_ajaran);
		$data["tahun_ajaran"] = $this->modelkelas_siswa->getAlltahun_ajaran();
		$siswa = $this->modelkelas_siswa->getAllsiswa();
		$temp = array();
		
		foreach($siswa as $s){
			$temp[$s->id_siswa] = array();
			$temp[$s->id_siswa]['selected'] = 0;
			$temp[$s->id_siswa]['value'] = $s->id_siswa;
			$temp[$s->id_siswa]['nama'] = $s->nis.'-'.$s->nama;
		}
		
		if($kelas_siswa){
			foreach($kelas_siswa as $k){
				$temp[$k->id_siswa]['selected'] = 1;
			}
		}
		$data['list'] = $temp;
		// echo '<pre>';
		// print_r($temp);
		// echo '</pre>';
		$this->load->view('kelas_siswa/tambah', $data);
	}
	
	
	public function submit(){
					
			$id_kelas = $this->input->post('id_kelas');
			$siswa = $this->input->post('siswa');
			
			$data['siswa'] = $siswa;
			$data['id_kelas'] = $id_kelas;
		
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
			
			// echo '<pre>';
			// print_r($data);
			// echo '</pre>';
			$this->modelkelas_siswa->tambah($data);
			redirect('kelas_siswa/home/');
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
	public function download(){
		$file = base_url().'uploads/template_kelas_siswa.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function import_kelas_siswa(){
		
		$fileName = date('Y-m-d').'_kelassiswa_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/kelas_siswa/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/kelas_siswa/'.$media['file_name'];
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
             
            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

                //Sesuaikan sama nama kolom tabel di database
                if($this->modelkelas_siswa->getsiswa($rowData[0][1], $rowData[0][2]) && $this->modelkelas_siswa->getkelas($rowData[0][3], $rowData[0][4], $rowData[0][5])){
	                $data = array(
	                    "id_siswa"=> $this->modelkelas_siswa->getsiswa($rowData[0][1], $rowData[0][2])->id_siswa,
	                    "id_kelas"=> $this->modelkelas_siswa->getkelas($rowData[0][3], $rowData[0][4], $rowData[0][5])->id_kelas
	                );
	                 
	                //sesuaikan nama dengan nama tabel
	                $insert = $this->db->insert("kelas_siswa",$data);
	                // delete_files($media['file_path']);
                }
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('kelas_siswa/');
	}

	public function siswa(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		$data['listsiswa'] = $this->modelkelas_siswa->getsiswakelas($nis, $nama);

		$this->load->view('kelas_siswa/siswa', $data);
	}

	public function detail_siswa($id_siswa=0){
		$list = array();
		
		$siswa = $this->modelsiswa->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$kelas = $this->modelkelas_siswa->getkelassiswabyidsiswa($id_siswa);
		$data['kelas'] = $kelas;

		foreach ($kelas as $k) {
			$list[$k->kelas] = array();
			$list[$k->kelas]['id_tingkat'] = $k->id_tingkat;
			$list[$k->kelas]['tingkat'] = $k->nama_tingkat;
			$list[$k->kelas]['id_kelas'] = $k->id_kelas;
			$list[$k->kelas]['tahun_ajaran'] = $k->tahun_ajaran;
			
		}

		$data['list'] = $list;
		$this->load->view('kelas_siswa/detail_siswa', $data);
	}

	public function hapus_kelas_siswa($id_siswa=0, $id_kelas=0){
		$this->modelkelas_siswa->hapus_dana_siswa($id_siswa, $id_kelas);

		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');

		redirect('kelas_siswa/detail_siswa/'.$id_siswa);
	}

	public function tambah_kelas($id_siswa=0){
		$siswa = $this->modelsiswa->getsiswabyid($id_siswa);
		$data['id_siswa'] = $id_siswa;
		$data['nama'] = $siswa['nama'];
		$data['nis'] = $siswa['nis'];
		$data['nisn'] = $siswa['nisn'];
		$data['jenis_kelamin'] = $siswa['jenis_kelamin'];

		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();

		$this->load->view('kelas_siswa/tambah_kelas', $data);
	}

	public function submit_tambah_kelas(){
		$data['id_siswa'] = $this->input->post('siswa');
		$data['id_kelas'] = $this->input->post('kelas');

		$this->modelkelas_siswa->tambah_kelas($data);

		$this->session->set_flashdata('message', 'Data berhasil ditambah!');
		$this->session->set_flashdata('statusmessage', '1');

		redirect('kelas_siswa/detail_siswa/'.$data['id_siswa']);
	}
}	