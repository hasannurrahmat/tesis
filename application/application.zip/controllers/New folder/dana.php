<?php 

class Dana extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modeldana');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($id_tingkat=0){
		
		$data["listdana"] = $this->modeldana->getAlldana();
		
		if($id_tingkat==0){
		$id_tingkat = isset($_POST['tingkat'])?$_POST['tingkat']:0;
		}else{
		$id_tingkat = $id_tingkat;
		}
		
		$data["id_tingkat"] = $id_tingkat;
		
		$data["tingkat"] = $this->modeldana->getAlltingkat();
		
		$this->load->view('dana/home', $data);
	}
	
	public function tambah($id=0){
		$data['jenis'] = 'tambah';
		
		$data["tingkat"] = $this->modeldana->getAlltingkat();
		$data["listjenis"] = $this->modeldana->getAlljenis();
				
		$data['id_jenis_dana'] = null;
		$data['jenis_dana'] = null;
		$data['id_jenis'] = null;
		$data['id_tingkat'] = $id;
		
		$this->load->view('dana/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('dana');
		}
		
		$data["tingkat"] = $this->modeldana->getAlltingkat();
		$data["listjenis"] = $this->modeldana->getAlljenis();
		$row=$this->modeldana->getdana($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_jenis_dana'] = $row->id_jenis_dana;
		$data['jenis_dana'] = $row->jenis_dana;
		$data['id_jenis'] = $row->id_jenis;
		$data['id_tingkat'] = $row->id_tingkat;
		
		$this->load->view('dana/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('dana');
		}
		
		$this->modeldana->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('dana');
	}
	
	public function submit(){
		$this->form_validation->set_rules('jenis_dana', 'jenis_dana', 'required');
		$this->form_validation->set_rules('tingkat', 'tingkat', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id = $this->input->post('id');
			$jenis_dana = $this->input->post('jenis_dana');
			$id_jenis = $this->input->post('listjenis');
			$tingkat = $this->input->post('tingkat');
			$jenis = $this->input->post('jenis');
			
			$data['jenis_dana'] = $jenis_dana;
			$data['id_jenis'] = $id_jenis;
			$data['id_tingkat'] = $tingkat;
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modeldana->tambah($data);
				redirect('dana/home/'.$tingkat);
			}else{
				$data['id_jenis_dana'] = $id;
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modeldana->ubah($data);
				redirect('dana/home/'.$tingkat);
			}
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenis=='tambah'){
				redirect('dana/tambah');
			}else{
				redirect('dana/ubah/'. $id);
			}
		}
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
}