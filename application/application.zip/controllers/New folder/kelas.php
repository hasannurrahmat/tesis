<?php 

class Kelas extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelkelas');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home($id_tahun_ajaran=0, $id_tingkat=0){
		
		$data["listkelas"] = $this->modelkelas->getAllkelas();
		
		if($id_tingkat==0){
		$id_tingkat = isset($_POST['tingkat'])?$_POST['tingkat']:0;
		}else{
		$id_tingkat = $id_tingkat;
		}
		if($id_tahun_ajaran==0){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		}else{
		$id_tahun_ajaran = $id_tahun_ajaran;
		}
		
		$data["id_tingkat"] = $id_tingkat;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$data["tingkat"] = $this->modelkelas->getAlltingkat();
		$data["tahun_ajaran"] = $this->modelkelas->getAlltahun_ajaran();
		
		$this->load->view('kelas/home', $data);
	}
	
	public function tambah($tahun_ajaran=0, $id=0){
		$data['jenis'] = 'tambah';
		
		$data["tingkat"] = $this->modelkelas->getAlltingkat();
		$data["tahun_ajaran"] = $this->modelkelas->getAlltahun_ajaran();
				
		$data['id_kelas'] = null;
		$data['kelas'] = null;
		$data['id_tahun_ajaran'] = $tahun_ajaran;
		$data['id_tingkat'] = $id;
		
		$this->load->view('kelas/tambah', $data);
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('kelas');
		}
		
		$data["tingkat"] = $this->modelkelas->getAlltingkat();
		$data["tahun_ajaran"] = $this->modelkelas->getAlltahun_ajaran();
		$row=$this->modelkelas->getkelas($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_kelas'] = $row->id_kelas;
		$data['kelas'] = $row->kelas;
		$data['id_tahun_ajaran'] = $row->id_tahun_ajaran;
		$data['id_tingkat'] = $row->id_tingkat;
		
		$this->load->view('kelas/tambah', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('kelas');
		}
		
		$this->modelkelas->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('kelas');
	}
	
	public function submit(){
		$this->form_validation->set_rules('kelas', 'kelas', 'required');
		$this->form_validation->set_rules('tingkat', 'tingkat', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id = $this->input->post('id');
			$kelas = $this->input->post('kelas');
			$tahun_ajaran = $this->input->post('tahun_ajaran');
			$tingkat = $this->input->post('tingkat');
			$jenis = $this->input->post('jenis');
			
			$data['kelas'] = $kelas;
			$data['id_tahun_ajaran'] = $tahun_ajaran;
			$data['id_tingkat'] = $tingkat;
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelkelas->tambah($data);
				redirect('kelas/home/'.$tahun_ajaran.'/'.$tingkat);
			}else{
				$data['id_kelas'] = $id;
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelkelas->ubah($data);
				redirect('kelas/home/'.$tahun_ajaran.'/'.$tingkat);
			}
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenis=='tambah'){
				redirect('kelas/tambah');
			}else{
				redirect('kelas/ubah/'. $id);
			}
		}
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}

	public function download(){
		$file = base_url().'uploads/template_kelas.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}

	public function import_kelas(){
		
		$fileName = date('Y-m-d').'_kelas_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/kelas/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/kelas/'.$media['file_name'];
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
             
            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

                //Sesuaikan sama nama kolom tabel di database
                if($this->modelkelas->gettingkat($rowData[0][2]) && $this->modelkelas->gettahun($rowData[0][3])){
	                $data = array(
	                    "kelas"=> $rowData[0][1],
	                    "id_tingkat"=> $this->modelkelas->gettingkat($rowData[0][2])->id_tingkat,
	                    "id_tahun_ajaran"=> $this->modelkelas->gettahun($rowData[0][3])->id_tahun_ajaran
	                );
	                 
	                //sesuaikan nama dengan nama tabel
	                $insert = $this->db->insert("kelas",$data);
	                // delete_files($media['file_path']);
                }
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('kelas/');
	}
	
}	