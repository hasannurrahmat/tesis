<?php 

class Daftar_ulang extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelsiswa');
		$this->load->helper("url");
        $this->load->library("pagination");
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$tingkat = $this->modelsiswa->getkelas($id_kelas);
		
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		$data['listsiswa'] = $this->modelsiswa->getAllsiswa($id_kelas);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();
		
		$this->load->view('daftar_ulang/home', $data);
	}
	
	public function tambah_dana(){
		$id_tahun_ajaran = isset($_POST['tahun_ajaran'])?$_POST['tahun_ajaran']:0;
		$id_kelas = isset($_POST['kelas'])?$_POST['kelas']:0;
		
		$data["id_kelas"] = $id_kelas;
		$data["id_tahun_ajaran"] = $id_tahun_ajaran;
		
		$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas);
		$tingkat = $this->modelsiswa->getkelas($id_kelas);
		$siswa = $this->modelsiswa->getAllsiswa($id_kelas);
		
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;
			}
		}
		
		$data["dana"] = $temp;
		$data["kelas"] = $this->modelsiswa->getAllkelas($id_tahun_ajaran);
		$data['listsiswa'] = $this->modelsiswa->getAllsiswa($id_kelas);
		$data["tahun_ajaran"] = $this->modelsiswa->getAlltahun();
		
		// echo "<pre>";
		// print_r($temp);
		// echo "</pre>";
		$this->load->view('daftar_ulang/tambah_dana', $data);
	}
	
	public function report(){
		$this->load->view('daftar_ulang/report');
	}
	
	public function cetak_kwitansi(){
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modelsiswa->getAllsiswa($perubahan['id_kelas']);
		foreach($row as $r){
			if($r->id_siswa==$perubahan['id_siswa']){
				$data['nis'] = $r->nis;
				$data['nama'] = $r->nama;
				$data['kelas'] = $r->kelas;
			}
		}
		
		$data['list'] = $perubahan['list'];
		// print_r($data);
		$this->load->view('daftar_ulang/cetak_kwitansi', $data);
	}
	
	public function tambah(){
		$nis = isset($_POST['nis'])?$_POST['nis']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		
		$data["nis"] = $nis;
		$data["nama"] = $nama;
		$id_kelas = $this->modelsiswa->getsiswa($nis, $nama);
		
		if($id_kelas){
			$tingkat = $this->modelsiswa->getkelas($id_kelas->id_kelas);
		}else{
			$tingkat = $this->modelsiswa->getkelas(0);
		}
		if($tingkat){
			$data["jenis_dana"] = $this->modelsiswa->getjenisdana($tingkat->id_tingkat);
		}else{
			$data["jenis_dana"] = "";
		}
		
		$dana_siswa = $this->modelsiswa->carijenisdana($id_kelas->id_kelas);
		$tingkat = $this->modelsiswa->getkelas($id_kelas->id_kelas);
		$siswa = $this->modelsiswa->getAllsiswa($id_kelas->id_kelas);
		
		$temp = array();
		if($siswa){
			foreach($siswa as $s){
				$temp[$s->id_siswa] = array();
				foreach($data["jenis_dana"] as $j){
					$temp[$s->id_siswa][$j->id_jenis_dana] = 0;
				}
			}
		}
		if($dana_siswa){
			foreach($dana_siswa as $ds){
				$temp[$ds->id_siswa][$ds->id_jenis_dana] = $ds->nilai;
			}
		}
		
		$data["dana"] = $temp;
		$data['listsiswa'] = $this->modelsiswa->getsiswa($nis, $nama);
		// print_r($data['listsiswa']);
		$this->load->view('daftar_ulang/tambah', $data);
	}
	
	public function submit_dana_kelas(){
			$id_kelas = $this->input->post('id_kelas');
			$jenis_dana = $this->input->post('jenis_dana');
			
			$status = $this->modelsiswa->carijenisdana($id_kelas);
			
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_dana'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					
					if($status){
						$this->modelsiswa->update_dana_kelas($data);						
					}else{
						$this->modelsiswa->tambah_dana_kelas($data);						
					}
				}
			}
				
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
			
			redirect('daftar_ulang/home');
			
	}
	
	public function submit_dana_siswa(){
			$id_siswa = $this->input->post('id_siswa');
			$id_kelas = $this->input->post('id_kelas');
			$jenis_dana = $this->input->post('jenis_dana');
			
			$status = $this->modelsiswa->carijenisdana($id_kelas);
			$old = $status;
			
			$old = array();
			$old[$id_siswa] = array();
			
			foreach($status as $s){
				if($s->id_siswa==$id_siswa){
					$old[$id_siswa][$s->id_jenis_dana] = $s->nilai;					
				}
			}
			
			$new = $jenis_dana;
			
			$temp = array();
			$temp['list'] = array();
			foreach($new[$id_siswa] as $a=>$val){
				if($val != $old[$id_siswa][$a]){
					$temp['list'][$a] = $val;
				}
			}
			$temp['id_siswa'] = $id_siswa;
			$temp['id_kelas'] = $id_kelas;
			
			$this->session->set_userdata("data",$temp);
			
			foreach($jenis_dana as $siswa=>$a){
				foreach($a as $jenis=>$val){
					$data['id_siswa'] = $siswa;
					$data['id_jenis_dana'] = $jenis;
					$data['id_kelas'] = $id_kelas;
					$data['nilai'] = $val;
					
					if($status){
						$this->modelsiswa->update_dana_kelas($data);						
					}else{
						$this->modelsiswa->tambah_dana_kelas($data);						
					}
				}
			}
				
			$this->session->set_flashdata('message', 'Data berhasil ditambah!');
			$this->session->set_flashdata('statusmessage', '1');
			
			redirect('daftar_ulang/cetak_kwitansi');
			
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		// $data["siswa"] = $this->modelsiswa->getAllsiswa();
		$row=$this->modelsiswa->getsiswa($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_siswa'] = $row->id_siswa;
		//A
		$data['unit_kerja'] = $row->unit_kerja;
		$data['sub_unit_kerja'] = $row->sub_unit_kerja;
		//B
		$data['nip'] = $row->nip;
		$data['nama'] = $row->nama;
		$data['tempat_lahir'] = $row->tempat_lahir;
		$data['tanggal_lahir'] = $row->tanggal_lahir;
		$data['jenis_kelamin'] = $row->jenis_kelamin;
		$data['agama'] = $row->agama;
		$data['status_siswa'] = $row->status_siswa;
		$data['status_perkawinan'] = $row->status_perkawinan;
		$data['alamat'] = $row->alamat;
		$data['no_telpon'] = $row->no_telpon;
		$data['no_karpeg'] = $row->no_karpeg;
		$data['no_askes'] = $row->no_askes;
		$data['taspen'] = $row->taspen;
		$data['no_npwp'] = $row->no_npwp;
		$data['gol_darah'] = $row->gol_darah;
		$data['no_karis'] = $row->no_karis;
		//C
		$data['ditetapkan_oleh_cpns'] = $row->ditetapkan_oleh_cpns;
		$data['tanggal_sk_cpns'] = $row->tanggal_sk_cpns;
		$data['no_sk_cpns'] = $row->no_sk_cpns;
		$data['golongan_ruang_cpns'] = $row->golongan_ruang_cpns;
		$data['tmt_sk_cpns'] = $row->tmt_sk_cpns;
		//D
		$data['ditetapkan_oleh_pns'] = $row->ditetapkan_oleh_pns;
		$data['no_sk_pns'] = $row->no_sk_pns;
		$data['tanggal_sk_pns'] = $row->tanggal_sk_pns;
		$data['golongan_ruang_pns'] = $row->golongan_ruang_pns;
		$data['tmt_sk_pns'] = $row->tmt_sk_pns;
		$data['sumpah_pns'] = $row->sumpah_pns;
		//E
		$data['ditetapkan_oleh_pangkat'] = $row->ditetapkan_oleh_pangkat;
		$data['no_sk_pangkat'] = $row->no_sk_pangkat;
		$data['tanggal_sk_pangkat'] = $row->tanggal_sk_pangkat;
		$data['golongan_ruang_pangkat'] = $row->golongan_ruang_pangkat;
		$data['tmt_gol'] = $row->tmt_gol;
		$data['masa_kerja_pangkat'] = $row->masa_kerja_pangkat;
		//G
		$data['ditetapkan_oleh_jabatan'] = $row->ditetapkan_oleh_jabatan;
		$data['no_sk_jabatan'] = $row->no_sk_jabatan;
		$data['tanggal_sk_jabatan'] = $row->tanggal_sk_jabatan;
		$data['jabatan'] = $row->jabatan;
		$data['tmt_jabatan'] = $row->tmt_jabatan;
		$data['eselon_jabatan'] = $row->eselon_jabatan;
		//H
		$data['tingkat_umum'] = $row->tingkat_umum;
		$data['jurusan_umum'] = $row->jurusan_umum;
		$data['tahun_lulus_umum'] = $row->tahun_lulus_umum;
		//I
		$data['tingkat_struktural'] = $row->tingkat_struktural;
		$data['tanggal_selesai_struktural'] = $row->tanggal_selesai_struktural;
		$data['jumlah_jam_struktural'] = $row->jumlah_jam_struktural;
		//J
		$data['nama_ayah'] = $row->nama_ayah;
		$data['tempat_lahir_ayah'] = $row->tempat_lahir_ayah;
		$data['tanggal_lahir_ayah'] = $row->tanggal_lahir_ayah;
		$data['alamat_ayah'] = $row->alamat_ayah;
		$data['nama_ibu'] = $row->nama_ibu;
		$data['tempat_lahir_ibu'] = $row->tempat_lahir_ibu;
		$data['tanggal_lahir_ibu'] = $row->tanggal_lahir_ibu;
		$data['alamat_ibu'] = $row->alamat_ibu;
		//K
		$data['nama_istri'] = $row->nama_istri;
		$data['tempat_lahir_istri'] = $row->tempat_lahir_istri;
		$data['tanggal_lahir_istri'] = $row->tanggal_lahir_istri;
		$data['tanggal_menikah_istri'] = $row->tanggal_menikah_istri;
		$data['pekerjaan_istri'] = $row->pekerjaan_istri;
		$data['tunjangan_istri'] = $row->tunjangan_istri;
		$data['nip_istri'] = $row->nip_istri;
		//L
		$data['nama_anak'] = null;
		$data['tempat_lahir_anak'] = null;
		$data['tanggal_lahir_anak'] = null;
		$data['jenis_kelamin_anak'] = null;
		$data['tunjangan_anak'] = null;
		$data['status_anak'] = null;
		//M
		$data['pangkat_riwayat'] = null;
		$data['no_sk_riwayat'] = null;
		$data['tanggal_sk_riwayat'] = null;
		$data['tmt_pangkat_riwayat'] = null;
		//N
		$data['nama_riwayat_jabatan'] = null;
		$data['unit_kerja_riwayat_jabatan'] = null;
		$data['eselon_riwayat_jabatan'] = null;
		$data['no_sk_riwayat_jabatan'] = null;
		$data['tanggal_sk_riwayat_jabatan'] = null;
		$data['tmt_jabatan_riwayat_jabatan'] = null;
		//O
		$data['tingkat_pendidikan'] = null;
		$data['jurusan_pendidikan'] = null;
		$data['nama_sekolah_pendidikan'] = null;
		$data['tempat_pendidikan'] = null;
		$data['kepsek_pendidikan'] = null;
		$data['no_sttb_pendidikan'] = null;
		$data['tanggal_sttb_pendidikan'] = null;
		
		$this->load->view('daftar_ulang/tambah', $data);
	}
	
	public function detail($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		// $data["siswa"] = $this->modelsiswa->getAllsiswa();
		$row=$this->modelsiswa->getsiswa($id);
		
		$data['jenis'] = 'edit';
		
		$data['id_siswa'] = $row->id_siswa;
		//A
		$data['unit_kerja'] = $row->unit_kerja;
		$data['sub_unit_kerja'] = $row->sub_unit_kerja;
		//B
		$data['nip'] = $row->nip;
		$data['nama'] = $row->nama;
		$data['tempat_lahir'] = $row->tempat_lahir;
		$data['tanggal_lahir'] = $row->tanggal_lahir;
		$data['jenis_kelamin'] = $row->jenis_kelamin;
		$data['agama'] = $row->agama;
		$data['status_siswa'] = $row->status_siswa;
		$data['status_perkawinan'] = $row->status_perkawinan;
		$data['alamat'] = $row->alamat;
		$data['no_telpon'] = $row->no_telpon;
		$data['no_karpeg'] = $row->no_karpeg;
		$data['no_askes'] = $row->no_askes;
		$data['taspen'] = $row->taspen;
		$data['no_npwp'] = $row->no_npwp;
		$data['gol_darah'] = $row->gol_darah;
		$data['no_karis'] = $row->no_karis;
		//C
		$data['ditetapkan_oleh_cpns'] = $row->ditetapkan_oleh_cpns;
		$data['tanggal_sk_cpns'] = $row->tanggal_sk_cpns;
		$data['no_sk_cpns'] = $row->no_sk_cpns;
		$data['golongan_ruang_cpns'] = $row->golongan_ruang_cpns;
		$data['tmt_sk_cpns'] = $row->tmt_sk_cpns;
		//D
		$data['ditetapkan_oleh_pns'] = $row->ditetapkan_oleh_pns;
		$data['no_sk_pns'] = $row->no_sk_pns;
		$data['tanggal_sk_pns'] = $row->tanggal_sk_pns;
		$data['golongan_ruang_pns'] = $row->golongan_ruang_pns;
		$data['tmt_sk_pns'] = $row->tmt_sk_pns;
		$data['sumpah_pns'] = $row->sumpah_pns;
		//E
		$data['ditetapkan_oleh_pangkat'] = $row->ditetapkan_oleh_pangkat;
		$data['no_sk_pangkat'] = $row->no_sk_pangkat;
		$data['tanggal_sk_pangkat'] = $row->tanggal_sk_pangkat;
		$data['golongan_ruang_pangkat'] = $row->golongan_ruang_pangkat;
		$data['tmt_gol'] = $row->tmt_gol;
		$data['masa_kerja_pangkat'] = $row->masa_kerja_pangkat;
		//G
		$data['ditetapkan_oleh_jabatan'] = $row->ditetapkan_oleh_jabatan;
		$data['no_sk_jabatan'] = $row->no_sk_jabatan;
		$data['tanggal_sk_jabatan'] = $row->tanggal_sk_jabatan;
		$data['jabatan'] = $row->jabatan;
		$data['tmt_jabatan'] = $row->tmt_jabatan;
		$data['eselon_jabatan'] = $row->eselon_jabatan;
		//H
		$data['tingkat_umum'] = $row->tingkat_umum;
		$data['jurusan_umum'] = $row->jurusan_umum;
		$data['tahun_lulus_umum'] = $row->tahun_lulus_umum;
		//I
		$data['tingkat_struktural'] = $row->tingkat_struktural;
		$data['tanggal_selesai_struktural'] = $row->tanggal_selesai_struktural;
		$data['jumlah_jam_struktural'] = $row->jumlah_jam_struktural;
		//J
		$data['nama_ayah'] = $row->nama_ayah;
		$data['tempat_lahir_ayah'] = $row->tempat_lahir_ayah;
		$data['tanggal_lahir_ayah'] = $row->tanggal_lahir_ayah;
		$data['alamat_ayah'] = $row->alamat_ayah;
		$data['nama_ibu'] = $row->nama_ibu;
		$data['tempat_lahir_ibu'] = $row->tempat_lahir_ibu;
		$data['tanggal_lahir_ibu'] = $row->tanggal_lahir_ibu;
		$data['alamat_ibu'] = $row->alamat_ibu;
		//K
		$data['nama_istri'] = $row->nama_istri;
		$data['tempat_lahir_istri'] = $row->tempat_lahir_istri;
		$data['tanggal_lahir_istri'] = $row->tanggal_lahir_istri;
		$data['tanggal_menikah_istri'] = $row->tanggal_menikah_istri;
		$data['pekerjaan_istri'] = $row->pekerjaan_istri;
		$data['tunjangan_istri'] = $row->tunjangan_istri;
		$data['nip_istri'] = $row->nip_istri;
		
		$data['anak'] = null;
		$data['riwayat_pangkat'] = null;
		$data['riwayat_jabatan'] = null;
		$data['riwayat_pendidikan'] = null;
		// //L
		// $data['nama_anak'] = null;
		// $data['tempat_lahir_anak'] = null;
		// $data['tanggal_lahir_anak'] = null;
		// $data['jenis_kelamin_anak'] = null;
		// $data['tunjangan_anak'] = null;
		// $data['status_anak'] = null;
		// //M
		// $data['pangkat_riwayat'] = null;
		// $data['no_sk_riwayat'] = null;
		// $data['tanggal_sk_riwayat'] = null;
		// $data['tmt_pangkat_riwayat'] = null;
		// //N
		// $data['nama_riwayat_jabatan'] = null;
		// $data['unit_kerja_riwayat_jabatan'] = null;
		// $data['eselon_riwayat_jabatan'] = null;
		// $data['no_sk_riwayat_jabatan'] = null;
		// $data['tanggal_sk_riwayat_jabatan'] = null;
		// $data['tmt_jabatan_riwayat_jabatan'] = null;
		// //O
		// $data['tingkat_pendidikan'] = null;
		// $data['jurusan_pendidikan'] = null;
		// $data['nama_sekolah_pendidikan'] = null;
		// $data['tempat_pendidikan'] = null;
		// $data['kepsek_pendidikan'] = null;
		// $data['no_sttb_pendidikan'] = null;
		// $data['tanggal_sttb_pendidikan'] = null;
		
		$this->load->view('daftar_ulang/detail', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		$this->modelsiswa->hapus($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('daftar_ulang/home');
	}
	
	public function submit(){
		
		$this->form_validation->set_rules('jenis', 'jenis', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$siswa['nip'] = $this->input->post('nip');
			$siswa['nama'] = $this->input->post('nama');
			$siswa['tempat_lahir'] = $this->input->post('tempat_lahir');
			$siswa['tanggal_lahir'] = $this->input->post('tanggal_lahir');
			$siswa['agama'] = $this->input->post('agama');
			$siswa['jenis_kelamin'] = $this->input->post('jenis_kelamin');
			$siswa['status_siswa'] = $this->input->post('status_siswa');
			$siswa['status_perkawinan'] = $this->input->post('status_perkawinan');
			$siswa['alamat'] = $this->input->post('alamat');
			$siswa['no_telpon'] = $this->input->post('no_telpon');
			$siswa['no_karpeg'] = $this->input->post('no_karpeg');
			$siswa['no_askes'] = $this->input->post('no_askes');
			$siswa['taspen'] = $this->input->post('taspen');
			$siswa['no_npwp'] = $this->input->post('no_npwp');
			$siswa['gol_darah'] = $this->input->post('gol_darah');
			$siswa['no_karis'] = $this->input->post('no_karis');
			//lokasi kerja
			$lokasi_kerja['unit_kerja'] = $this->input->post('unit_kerja');
			$lokasi_kerja['sub_unit_kerja'] = $this->input->post('sub_unit_kerja');
			//pengangkatan_cpns
			$pengangkatan_cpns['ditetapkan_oleh_cpns'] = $this->input->post('ditetapkan_oleh_cpns');
			$pengangkatan_cpns['tanggal_sk_cpns'] = $this->input->post('tanggal_sk_cpns');
			$pengangkatan_cpns['no_sk_cpns'] = $this->input->post('no_sk_cpns');
			$pengangkatan_cpns['golongan_ruang_cpns'] = $this->input->post('golongan_ruang_cpns');
			$pengangkatan_cpns['tmt_sk_cpns'] = $this->input->post('tmt_sk_cpns');
			//pengangkatan_pns
			$pengangkatan_pns['ditetapkan_oleh_pns'] = $this->input->post('ditetapkan_oleh_pns');
			$pengangkatan_pns['no_sk_pns'] = $this->input->post('no_sk_pns');
			$pengangkatan_pns['tanggal_sk_pns'] = $this->input->post('tanggal_sk_pns');
			$pengangkatan_pns['golongan_ruang_pns'] = $this->input->post('golongan_ruang_pns');
			$pengangkatan_pns['tmt_sk_pns'] = $this->input->post('tmt_sk_pns');
			$pengangkatan_pns['sumpah_pns'] = $this->input->post('sumpah_pns');
			//golongan_terakhir
			$golongan_terakhir['ditetapkan_oleh_pangkat'] = $this->input->post('ditetapkan_oleh_pangkat');
			$golongan_terakhir['no_sk_pangkat'] = $this->input->post('no_sk_pangkat');
			$golongan_terakhir['tanggal_sk_pangkat'] = $this->input->post('tanggal_sk_pangkat');
			$golongan_terakhir['golongan_ruang_pangkat'] = $this->input->post('golongan_ruang_pangkat');
			$golongan_terakhir['tmt_gol'] = $this->input->post('tmt_gol');
			$golongan_terakhir['masa_kerja_pangkat'] = $this->input->post('masa_kerja_pangkat');
			//jabatan_terakhir
			$jabatan_terakhir['ditetapkan_oleh_jabatan'] = $this->input->post('ditetapkan_oleh_jabatan');
			$jabatan_terakhir['no_sk_jabatan'] = $this->input->post('no_sk_jabatan');
			$jabatan_terakhir['tanggal_sk_jabatan'] = $this->input->post('tanggal_sk_jabatan');
			$jabatan_terakhir['jabatan'] = $this->input->post('jabatan');
			$jabatan_terakhir['tmt_jabatan'] = $this->input->post('tmt_jabatan');
			$jabatan_terakhir['eselon_jabatan'] = $this->input->post('eselon_jabatan');
			//pendidikan_umum_terakhir
			$pendidikan_umum_terakhir['tingkat_umum'] = $this->input->post('tingkat_umum');
			$pendidikan_umum_terakhir['jurusan_umum'] = $this->input->post('jurusan_umum');
			$pendidikan_umum_terakhir['tahun_lulus_umum'] = $this->input->post('tahun_lulus_umum');
			//pendidikan_struktural_terakhir
			$pendidikan_struktural_terakhir['tingkat_struktural'] = $this->input->post('tingkat_struktural');
			$pendidikan_struktural_terakhir['tanggal_selesai_struktural'] = $this->input->post('tanggal_selesai_struktural');
			$pendidikan_struktural_terakhir['jumlah_jam_struktural'] = $this->input->post('jumlah_jam_struktural');
			//orang_tua
			$orang_tua['nama_ayah'] = $this->input->post('nama_ayah');
			$orang_tua['tempat_lahir_ayah'] = $this->input->post('tempat_lahir_ayah');
			$orang_tua['tanggal_lahir_ayah'] = $this->input->post('tanggal_lahir_ayah');
			$orang_tua['alamat_ayah'] = $this->input->post('alamat_ayah');
			$orang_tua['nama_ibu'] = $this->input->post('nama_ibu');
			$orang_tua['tempat_lahir_ibu'] = $this->input->post('tempat_lahir_ibu');
			$orang_tua['tanggal_lahir_ibu'] = $this->input->post('tanggal_lahir_ibu');
			$orang_tua['alamat_ibu'] = $this->input->post('alamat_ibu');
			//istri
			$istri['nama_istri'] = $this->input->post('nama_istri');
			$istri['tempat_lahir_istri'] = $this->input->post('tempat_lahir_istri');
			$istri['tanggal_lahir_istri'] = $this->input->post('tanggal_lahir_istri');
			$istri['tanggal_menikah_istri'] = $this->input->post('tanggal_menikah_istri');
			$istri['pekerjaan_istri'] = $this->input->post('pekerjaan_istri');
			$istri['tunjangan_istri'] = $this->input->post('tunjangan_istri');
			$istri['nip_istri'] = $this->input->post('nip_istri');
			//anak
			$nama_anak = $this->input->post('nama_anak');
			$tempat_lahir_anak = $this->input->post('tempat_lahir_anak');
			$tanggal_lahir_anak = $this->input->post('tanggal_lahir_anak');
			$jenis_kelamin_anak = $this->input->post('jenis_kelamin_anak');
			$tunjangan_anak = $this->input->post('tunjangan_anak');
			$status_anak = $this->input->post('status_anak');
			//riwayat_pangkat
			//riwayat_jabatan
			//riwayat_pendidikan
			
			
			if($jenis=='tambah'){
				$id_siswa = $this->modelsiswa->tambah_siswa($siswa);

				$lokasi_kerja['id_siswa'] = $id_siswa;
				$pengangkatan_cpns['id_siswa'] = $id_siswa;
				$pengangkatan_pns['id_siswa'] = $id_siswa;
				$golongan_terakhir['id_siswa'] = $id_siswa;
				$jabatan_terakhir['id_siswa'] = $id_siswa;
				$pendidikan_umum_terakhir['id_siswa'] = $id_siswa;
				$pendidikan_struktural_terakhir['id_siswa'] = $id_siswa;
				$orang_tua['id_siswa'] = $id_siswa;
				$istri['id_siswa'] = $id_siswa;
				$anak['id_siswa'] = $id_siswa;

				// $this->modelsiswa->tambah_lokasi_kerja($lokasi_kerja);
				// $this->modelsiswa->tambah_pengangkatan_cpns($pengangkatan_cpns);
				// $this->modelsiswa->tambah_pengangkatan_pns($pengangkatan_pns);
				// $this->modelsiswa->tambah_golongan_terakhir($golongan_terakhir);
				// $this->modelsiswa->tambah_jabatan_terakhir($jabatan_terakhir);
				// $this->modelsiswa->tambah_pendidikan_umum_terakhir($pendidikan_umum_terakhir);
				// $this->modelsiswa->tambah_pendidikan_struktural_terakhir($pendidikan_struktural_terakhir);
				// $this->modelsiswa->tambah_orang_tua($orang_tua);
				// $this->modelsiswa->tambah_istri($istri);
				
				foreach($nama_anak as $a=>$val){
					$anak['nama_anak'] = $val;
					$anak['tempat_lahir_anak'] = $tempat_lahir_anak[$a];
					$anak['tanggal_lahir_anak'] = $tanggal_lahir_anak[$a];
					$anak['jenis_kelamin_anak'] = $jenis_kelamin_anak[$a];
					$anak['tunjangan_anak'] = $tunjangan_anak[$a];
					$anak['status_anak'] = $status_anak[$a];
					
					$this->modelsiswa->tambah_anak($anak);
				}
				// echo $id_siswa;
				// echo '<pre>';
				// print_r($orang_tua);
				// echo '</pre>';
				// $this->session->set_flashdata('message', 'Data berhasil ditambah!');
				// $this->session->set_flashdata('statusmessage', '1');
				
				// redirect('daftar_ulang/home');
			}else{
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelsiswa->ubah($data);
				redirect('daftar_ulang/home/'.$siswa);
			}
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenis=='tambah'){
				redirect('daftar_ulang/tambah');
			}else{
				redirect('daftar_ulang/ubah/'. $id);
			}
		}
	}
	
	public function cari_home(){
		$nama = $this->input->post('nama');
		$jabatan = $this->input->post('jabatan');
		
		$data["links"] = '';
		$data["page"] = '';
		$data["jabatan"] = $jabatan;
		$data["nama"] = $nama;
		
		$data["jabatan"] = $this->modelsiswa->getAlljabatan();
		$data["listsiswa"] = $this->modelsiswa->getcarisiswa($nama, $jabatan);
		
		$this->load->view('daftar_ulang/home', $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
}	