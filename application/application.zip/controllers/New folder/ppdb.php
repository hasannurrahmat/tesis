<?php 

class Ppdb extends CI_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('modelppdb');
		$this->load->helper("url");
		$this->load->helper("download");
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
        $this->load->library("pagination");
        $this->load->library('Pdf');
		$this->load->library('form_validation');
		$this->is_logged_in();
	}
	
	public function index(){
		$this->home();
	}
	
	public function home(){
		$no_pendaftaran = isset($_POST['no_pendaftaran'])?$_POST['no_pendaftaran']:"";
		$nama = isset($_POST['nama'])?$_POST['nama']:"";
		$tahun = isset($_POST['tahun'])?$_POST['tahun']:"";
		
		$data["no_pendaftaran"] = $no_pendaftaran;
		$data["nama"] = $nama;
		$data["tahun"] = $tahun;
		
		$data['listsiswa'] = $this->modelppdb->getAllsiswa($tahun, $no_pendaftaran, $nama);
		$data['tahun_ajaran'] = $this->modelppdb->getAlltahunajaran();
		
		$this->load->view('ppdb/home', $data);
	}
		
	public function cetak_kwitansi(){
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modelppdb->getppdbbyid($perubahan['id_ppdb']);
		
		$data['no_pendaftaran'] = $row['no_pendaftaran'];
		$data['nama'] = $row['nama'];
			
		$data['list'] = $perubahan['list'];
		// print_r($data);
		$this->load->view('ppdb/cetak_kwitansi', $data);
	}
	
	public function tambah(){
		$data['jenis'] = 'tambah';
		$data['tahun_ajaran'] = $this->modelppdb->getAlltahunajaran();

		$data['id_ppdb'] = null;
		$data['tahun'] = null;
		$data['no_pendaftaran'] = null;
		$data['nama'] = null;
		$data['jenis_kelamin'] = null;
		$data['jumlah_dibayar'] = null;
		$data['administrasi'] = null;
		$data['pakaian'] = null;
		$data['kaos'] = null;
		$data['jilbab'] = null;
		$data['atribut'] = null;
		$data['dp'] = null;
		$data['kartu'] = null;
		$data['bantuan'] = null;
		$data['titipan'] = null;
		$data['hut'] = null;
		$data['komite'] = null;
		$data['qurban'] = null;
		$data['dansos'] = null;
		$data['ppta'] = null;
		$data['osis'] = null;
		$data['kta'] = null;
		$data['jumlah_terbayar'] = null;
		$data['jumlah_tunggakan_ppdb'] = null;
		$data['tahun'] = null;
		
		$this->load->view('ppdb/tambah', $data);
	}
	
	public function submit(){
		$this->form_validation->set_rules('nama', 'nama', 'required');
		$this->form_validation->set_rules('no_pendaftaran', 'no_pendaftaran', 'required');
		
		if($this->form_validation->run() == TRUE){
			
			$jenis = $this->input->post('jenis');
			
			$data['no_pendaftaran'] = $this->input->post('no_pendaftaran');
			$data['nama'] = $this->input->post('nama');
			$data['jenis_kelamin'] = $this->input->post('jenis_kelamin');
			$data['jumlah_dibayar'] = $this->input->post('jumlah_dibayar');
			$data['administrasi'] = $this->input->post('administrasi');
			$data['pakaian'] = $this->input->post('pakaian');
			$data['kaos'] = $this->input->post('kaos');
			$data['jilbab'] = $this->input->post('jilbab');
			$data['atribut'] = $this->input->post('atribut');
			$data['dp'] = $this->input->post('dp');
			$data['kartu'] = $this->input->post('kartu');
			$data['bantuan'] = $this->input->post('bantuan');
			$data['titipan'] = $this->input->post('titipan');
			$data['hut'] = $this->input->post('hut');
			$data['komite'] = $this->input->post('komite');
			$data['qurban'] = $this->input->post('qurban');
			$data['dansos'] = $this->input->post('dansos');
			$data['ppta'] = $this->input->post('ppta');
			$data['osis'] = $this->input->post('osis');
			$data['kta'] = $this->input->post('kta');
			$data['jumlah_terbayar'] = $data['administrasi'] + $data['pakaian'] + $data['kaos'] + $data['jilbab'] + $data['atribut'] + $data['dp'] + $data['kartu'] + $data['bantuan'] + $data['titipan'] + $data['hut'] + $data['komite'] + $data['qurban'] + $data['dansos'] + $data['ppta'] + $data['osis'] + $data['kta'];
			$data['jumlah_tunggakan_ppdb'] = $data['jumlah_dibayar'] - $data['jumlah_terbayar'];
			$data['tahun'] = $this->input->post('tahun');
			
			if($jenis=='tambah'){
				$this->session->set_flashdata('message', 'Data berhasil ditambah!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelppdb->tambah($data);
				redirect('ppdb/');
			}else{
				$data['id_ppdb'] = $this->input->post('id_ppdb');
				
				$old = $this->modelppdb->getppdbbyid($data['id_ppdb']);
				$jenis = $this->modelppdb->getjenisppdb();

				$temp = array();
				$temp['list'] = array();
				$temp['id_ppdb'] = $data['id_ppdb'];
				foreach ($jenis as $j) {
					if($data[$j->nama_jenis] != $old[$j->nama_jenis] && $j->nama_display != ''){
						$temp['list'][$j->nama_display] = $data[$j->nama_jenis];

						//add to rekap
						$data_rekap['nilai'] = $data[$j->nama_jenis];
						$data_rekap['id_jenis_ppdb'] = $j->id_jenis_ppdb;
						$data_rekap['id_ppdb'] = $data['id_ppdb'];
						$data_rekap['id_user'] = $this->session->userdata('id_user');
						$data_rekap['tanggal'] = date('Y-m-d');

						$this->modelppdb->tambah_rekap($data_rekap);
					}
				}
				
				$this->session->set_userdata("data",$temp);

				// echo '<pre>';
				// print_r($temp);
				// echo '</pre>';
				$this->session->set_flashdata('message', 'Data berhasil diupdate!');
				$this->session->set_flashdata('statusmessage', '1');
				
				$this->modelppdb->ubah($data);
				redirect('ppdb/cetak_kwitansi');
			}
			
		}else{
			$id = $this->input->post('id');
			$jenis = $this->input->post('jenis');
			
			$this->session->set_flashdata('message', 'Terjadi kesalahan pengisian!');
			$this->session->set_flashdata('statusmessage', '2');

			if($jenis=='tambah'){
				redirect('ppdb/tambah');
			}else{
				redirect('ppdb/ubah/'. $id);
			}
		}
			
	}
	
	public function ubah($id=0){
		if($id==0){
			redirect('ppdb');
		}
		
		$row=$this->modelppdb->getsiswabyid($id);
		
		$data['jenis'] = 'edit';
		$data['tahun_ajaran'] = $this->modelppdb->getAlltahunajaran();
		
		$data['id_ppdb'] = $row->id_ppdb;
		$data['tahun'] = $row->tahun;
		$data['no_pendaftaran'] = $row->no_pendaftaran;
		$data['nama'] = $row->nama;
		$data['jenis_kelamin'] = $row->jenis_kelamin;
		$data['jumlah_dibayar'] = $row->jumlah_dibayar;
		$data['administrasi'] = $row->administrasi;
		$data['pakaian'] = $row->pakaian;
		$data['kaos'] = $row->kaos;
		$data['jilbab'] = $row->jilbab;
		$data['atribut'] = $row->atribut;
		$data['dp'] = $row->dp;
		$data['kartu'] = $row->kartu;
		$data['bantuan'] = $row->bantuan;
		$data['titipan'] = $row->titipan;
		$data['hut'] = $row->hut;
		$data['komite'] = $row->komite;
		$data['qurban'] = $row->qurban;
		$data['dansos'] = $row->dansos;
		$data['ppta'] = $row->ppta;
		$data['osis'] = $row->osis;
		$data['kta'] = $row->kta;
		$data['jumlah_terbayar'] = $row->administrasi+$row->pakaian+$row->kaos+$row->jilbab+$row->atribut+$row->dp+$row->kartu+$row->bantuan+$row->titipan+$row->hut+$row->komite+$row->qurban+$row->dansos+$row->ppta+$row->osis+$row->kta;
		$data['jumlah_tunggakan_ppdb'] = $data['jumlah_dibayar'] - $data['jumlah_terbayar'];
		$data['tahun'] = $row->tahun;
		
		$this->load->view('ppdb/tambah', $data);
	}
	
	public function detail($id=0){
		if($id==0){
			redirect('siswa');
		}
		
		// $data["siswa"] = $this->modelppdb->getAllsiswa();
		$row=$this->modelppdb->getsiswa($id);
		
		$data['jenis'] = 'edit';
		
		
		$this->load->view('ppdb/detail', $data);
	}
	
	public function hapus($id=0){
		if($id==0){
			redirect('ppdb');
		}
		
		$this->modelppdb->hapusbyid($id);
		
		$this->session->set_flashdata('message', 'Data berhasil dihapus!');
		$this->session->set_flashdata('statusmessage', '1');
		
		redirect('ppdb');
	}
	
	public function download(){
		$file = base_url().'uploads/template_ppdb.xlsx';
		$data = file_get_contents($file);
		$filename = basename($file);
		
		force_download($filename, $data);
	}
	
	public function is_logged_in(){
		if(!$this->session->userdata('is_logged_in')){
			redirect('auth/login');
		}
	}
	
	public function import_ppdb(){
		$tahun = $this->input->post('tahun');

		$this->modelppdb->hapusbytahun($tahun);

		$fileName = date('Y-m-d').'_PPDB_'.$this->session->userdata('username');
         
        $config['upload_path'] = './uploads/ppdb/'; //buat folder dengan nama upload/ppdb di root folder
        $config['file_name'] = $fileName;
        $config['allowed_types'] = 'xls|xlsx|csv';
        $config['max_size'] = 10000;
         
        $this->load->library('upload');
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('file') )
        $this->upload->display_errors();
             
        $media = $this->upload->data('file');
        $inputFileName = './uploads/ppdb/'.$media['file_name'];
         
        try {
                $inputFileType = IOFactory::identify($inputFileName);
                $objReader = IOFactory::createReader($inputFileType);
                $objPHPExcel = $objReader->load($inputFileName);
            } catch(Exception $e) {
                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
            }
 
            $sheet = $objPHPExcel->getSheet(0);
            $highestRow = $sheet->getHighestRow();
            $highestColumn = $sheet->getHighestColumn();
             
            for ($row = 5; $row <= $highestRow; $row++){                  //  Read a row of data into an array                 
                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
                                                NULL,
                                                TRUE,
                                                FALSE);

                $jumlah_terbayar = $rowData[0][5] + $rowData[0][6] + $rowData[0][7] + $rowData[0][8] + $rowData[0][9] + $rowData[0][10] + $rowData[0][11] + $rowData[0][12] + $rowData[0][13] + $rowData[0][14] + $rowData[0][15] + $rowData[0][16] + $rowData[0][17] + $rowData[0][18] + $rowData[0][19] + $rowData[0][20];
                $jumlah_tunggakan_ppdb = $rowData[0][4] - $jumlah_terbayar;
                //Sesuaikan sama nama kolom tabel di database                                
                 $data = array(
                    "no_pendaftaran"=> $rowData[0][1],
                    "nama"=> $rowData[0][2],
                    "jenis_kelamin"=> $rowData[0][3],
                    "jumlah_dibayar"=> $rowData[0][4],
                    "administrasi"=> $rowData[0][5],
                    "pakaian"=> $rowData[0][6],
                    "kaos"=> $rowData[0][7],
                    "jilbab"=> $rowData[0][8],
                    "atribut"=> $rowData[0][9],
                    "dp"=> $rowData[0][10],
                    "kartu"=> $rowData[0][11],
                    "bantuan"=> $rowData[0][12],
                    "titipan"=> $rowData[0][13],
                    "hut"=> $rowData[0][14],
                    "komite"=> $rowData[0][15],
                    "qurban"=> $rowData[0][16],
                    "dansos"=> $rowData[0][17],
                    "ppta"=> $rowData[0][18],
                    "osis"=> $rowData[0][19],
                    "kta"=> $rowData[0][20],
                    "jumlah_terbayar"=> $jumlah_terbayar,
                    "jumlah_tunggakan_ppdb"=> $jumlah_tunggakan_ppdb,
                    "tahun"=> $tahun
                );
                 
                //sesuaikan nama dengan nama tabel
                $insert = $this->db->insert("ppdb",$data);
                // delete_files($media['file_path']);
                
            }
        
        $this->session->set_flashdata('message', 'Data berhasil di import!');
		$this->session->set_flashdata('statusmessage', '1');

        redirect('ppdb/');

	}

	public function print_pdf(){
	
		//variable yang dibutuhkan
		$tanggal = date('Y-m-d');
		$petugas = $this->session->userdata('username');
		$perubahan = $this->session->userdata("data");
		
		$row = $this->modelppdb->getppdbbyid($perubahan['id_ppdb']);
		
		$no_pendaftaran = $row['no_pendaftaran'];
		$nama = $row['nama'];
			
		$list = $perubahan['list'];
				
		// -------------------- Controller untuk print ke pdf -------------------- //
	
		$pdf = new Pdf('P', 'mm', 'B7', true, 'UTF-8', false);
		$pdf->setCreator(PDF_CREATOR);
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

		
		$pdf->setMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP-15, PDF_MARGIN_RIGHT);
		$pdf->setAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM-15);
		
		$pdf->AddPage();

		//----------------------// mencetak untuk lembar siswa //----------------------//
		// set font
		$pdf->SetFont('helvetica', '', 14);
		$pdf->MultiCell(300, 2, 'Bukti Pembayaran PPDB SMAN 1 Larangan Kabupaten Brebes', 0, 'L', 0, 1, 30, 20, true);
		//set image
		$pdf->Image(base_url().'uploads/sma'.'.png', 170, 40, 20, 20, 'PNG', '', 'Center', true, 150, '', false, false, 1, false, false, false);
		//set line
		$style = array('width' => 0.5, 'color' => array(0, 0, 0));
		$pdf->Line(15, 35, 195, 35, $style);

		// set font
		$pdf->SetFont('helvetica', '', 12);
		//text kolom 1
		$pdf->MultiCell(55, 5, 'Nomor Pendaftaran', 0, 'L', 0, 1, 10, 42, true);
		$pdf->MultiCell(55, 5, 'Nama', 0, 'L', 0, 1, 10, 49, true);
		$pdf->MultiCell(55, 5, 'Tanggal', 0, 'L', 0, 1, 10, 56, true);

		//text kolom 2
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 50, 42, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 50, 49, true);
		$pdf->MultiCell(10, 5, ':', 0, 'L', 0, 1, 50, 56, true);
		
		//text kolom 3
		$pdf->MultiCell(100, 5, $no_pendaftaran, 0, 'L', 0, 1, 55, 42, true);
		$pdf->MultiCell(100, 5, $nama, 0, 'L', 0, 1, 55, 49, true);
		$pdf->MultiCell(100, 5, $tanggal, 0, 'L', 0, 1, 55, 56, true);
		
		$pdf->MultiCell(100, 5, "", 0, 'L', 0, 1, 45, 70, true);
		
		// set font
		$pdf->SetFont('helvetica', '', 10);
		
		//table
		$tbl_header = '<table style="width: 600px;" cellspacing="0">';
		$tbl_footer = '</table>';
		$tbl = '
			<tr>
				<td style="border: 1px solid #000000; width: 300px;">Jenis Pembayaran</td>
				<td style="border: 1px solid #000000; width: 200px;">Uang Sebesar (Rp.)</td>
			</tr>
		';

		// foreach item in your array...
		$count=0; $jum=0;
		if($list){
			foreach($list as $l=>$val){
				$tbl .= '
					<tr>
						<td style="border: 1px solid #000000; width: 300px;">'.$l.'</td>
						<td style="border: 1px solid #000000; width: 200px;">'.$val.'</td>
					</tr>
				';
				$jum += $val;
				$count++;
			}
		}

		$pdf->writeHTML($tbl_header . $tbl . $tbl_footer, true, false, false, false, '');

		// set font
		$pdf->MultiCell(100, 5, 'Total Pembayaran : '.$jum, 0, 'L', 0, 1, 10, 90+($count*4), true);
		
		$pdf->SetFont('helvetica', '', 10);


		$pdf->MultiCell(100, 5, 'Brebes, '.$tanggal, 0, 'C', 0, 1, 100, 90+($count*4), true);
		$pdf->MultiCell(100, 5, 'Petugas', 0, 'C', 0, 1, 100, 95+($count*4), true);
		$pdf->MultiCell(100, 5, $petugas, 0, 'C', 0, 1, 100, 120+($count*4), true);
		
		$style = array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => '8,10', 'color' => array(0, 0, 0));
		$pdf->Line(15, 130+($count*4), 195, 130+($count*4), $style);
		//----------------------// ----------------------------- //----------------------//
		
		ob_clean();
		$pdf->Output($no_pendaftaran.'-'.$tanggal.'.pdf', 'I');
		
		redirect('home');
		// ----------------------------------------------------------------------- //
	}
}	