
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>List Barang<a href="<?php echo base_url();?>master/barang/tambah/"><button class="btn btn-success pull-right">Tambah Barang</button></a></h3>
							</div>
							
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#barang" aria-controls="barang" role="tab" data-toggle="tab">Data Seluruh Barang</a></li>
								<li role="presentation"><a href="#aman" aria-controls="aman" role="tab" data-toggle="tab">Stock Aman</a></li>
								<li role="presentation"><a href="#out" aria-controls="out" role="tab" data-toggle="tab">Stock Out</a></li>
								<li role="presentation"><a href="#stock" aria-controls="stock" role="tab" data-toggle="tab">Data Seluruh Stock</a></li>
							</ul>
							<br>
							<!-- Tab panes -->
							<div class="tab-content">

								<!-- view seluruh barang -->
								<div role="tabpanel" class="tab-pane active" id="barang">
									<form class="form-horizontal" role="form" action ="<?php echo base_url();?>master/barang/home" method="POST">
										<div class="form-group">
											<label for="jenis" class="col-md-1 control-label pull-left">Nama</label>
											<div class="col-md-2">
												<input type="text" class="form-control" name="nama_barang" value="<?php echo $nama_barang; ?>">
											</div>
											<label for="jenis" class="col-md-1 control-label pull-left">Sumber</label>
											<div class="col-md-2">
												<input type="text" class="form-control" name="sumber_barang" value="<?php echo $sumber_barang; ?>">
											</div>
											<label for="jenis" class="col-md-1 control-label pull-left">Tujuan</label>
											<div class="col-md-2">
												<input type="text" class="form-control" name="tujuan_barang" value="<?php echo $tujuan_barang; ?>">
											</div>
											<button type="submit" class="btn btn-primary">Cari</button>
										</div>
									</form>
						
									<table class="table table-condensed table-responsive table-bordered">
										<tr class="active">
											<th class="text-center">No</th>
											<th class="text-center">Nama Barang</th>
											<th class="text-center">Sumber</th>
											<th class="text-center">Tujuan</th>
											<th class="text-center">Stock Awal</th>
											<th class="text-center">Harga Satuan</th>
											<th class="text-center">Aksi</th>
										</tr>
										<?php $no=1; if($listuser){ foreach($listuser as $l): ?>
										<tr>
											<td width="10%" class="text-center"><?php echo $no; ?></td>
											<td width="15%"><?php echo $l->nama_barang; ?></td>
											<td width="15%"><?php echo $l->sumber_barang; ?></td>
											<td width="15%"><?php echo $l->tujuan_barang; ?></td>
											<td width="10%"><?php echo $l->stock; ?></td>
											<td width="20%"><?php echo "Rp. ".number_format($l->harga_satuan); ?></td>
											<td width="15%" class="text-center">
											<a href="<?php echo base_url();?>master/barang/ubah/<?php echo $l->id_barang; ?>">Ubah</a> | 
											<a href="<?php echo base_url();?>master/barang/hapus/<?php echo $l->id_barang; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
										</tr>
										<?php $no++; endforeach; }else{ ?>
											<tr><td colspan=7>Tidak ada data, silahkan tambah data</td></tr>
										<?php } ?>
									</table>

									<div style="display:none;" id="barangs" summary="Data barang">
										<table class="table table-condensed table-responsive table-bordered">
										<tr class="active">
											<th class="text-center">No</th>
											<th class="text-center">Nama Barang</th>
											<th class="text-center">Sumber</th>
											<th class="text-center">Tujuan</th>
											<th class="text-center">Stock Awal</th>
											<th class="text-center">Harga Satuan</th>
										</tr>
										<?php $no=1; if($listuser){ foreach($listuser as $l): ?>
										<tr>
											<td width="10%" class="text-center"><?php echo $no; ?></td>
											<td width="15%"><?php echo $l->nama_barang; ?></td>
											<td width="15%"><?php echo $l->sumber_barang; ?></td>
											<td width="15%"><?php echo $l->tujuan_barang; ?></td>
											<td width="10%"><?php echo $l->stock; ?></td>
											<td width="20%"><?php echo "Rp. ".number_format($l->harga_satuan); ?></td>
										</tr>
										<?php $no++; endforeach; }else{ ?>
											<tr><td colspan=7>Tidak ada data, silahkan tambah data</td></tr>
										<?php } ?>
											
										</table>
									</div>
									<input type="button" onclick="tableToExcel('barangs', 'Tabel Data barang' , 'barang.xls', 'Excel')" value="Cetak" class="btn btn-success">
								</div>

								<!-- view stock aman -->
								<div role="tabpanel" class="tab-pane" id="aman">
									<table class="table table-condensed table-responsive table-bordered">
										<tr class="active">
											<th class="text-center">No</th>
											<th class="text-center">Nama Barang</th>
											<th class="text-center">Sisa Stock</th>
											<th class="text-center">Harga Satuan</th>
										</tr>
										<?php $no=1; if($liststock){ foreach($liststock as $l): ?>
										<?php if($l["stock"] > 0){ ?>
										<tr>
											<td width="10%" class="text-center"><?php echo $no; ?></td>
											<td width="15%"><?php echo $l["nama_barang"]; ?></td>
											<td width="10%"><?php echo $l["stock"]; ?></td>
											<td width="20%"><?php echo "Rp. ".number_format($l["harga_satuan"]); ?></td>
										</tr>
										<?php $no++; } endforeach; }else{ ?>
											<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
										<?php } ?>
										<?php if($no==1){ ?>
											<tr><td colspan=4>Tidak ada Stock Aman</td></tr>
										<?php } ?>
									</table>
								</div>

								<!-- view stock out -->
								<div role="tabpanel" class="tab-pane" id="out">
									<table class="table table-condensed table-responsive table-bordered">
										<tr class="active">
											<th class="text-center">No</th>
											<th class="text-center">Nama Barang</th>
											<th class="text-center">Sisa Stock</th>
											<th class="text-center">Harga Satuan</th>
										</tr>
										<?php $no=1; if($liststock){ foreach($liststock as $l): ?>
										<?php if($l["stock"] <= 0){ ?>
										<tr>
											<td width="10%" class="text-center"><?php echo $no; ?></td>
											<td width="15%"><?php echo $l["nama_barang"]; ?></td>
											<td width="10%"><?php echo $l["stock"]; ?></td>
											<td width="20%"><?php echo "Rp. ".number_format($l["harga_satuan"]); ?></td>
										</tr>
										<?php $no++; } endforeach; }else{ ?>
											<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
										<?php } ?>
										<?php if($no==1){ ?>
											<tr><td colspan=4>Tidak ada Stock Out</td></tr>
										<?php } ?>

									</table>
								</div>

								<!-- view seluruh stock -->
								<div role="tabpanel" class="tab-pane" id="stock">
									<table class="table table-condensed table-responsive table-bordered">
										<tr class="active">
											<th class="text-center">No</th>
											<th class="text-center">Nama Barang</th>
											<th class="text-center">Sisa Stock</th>
											<th class="text-center">Harga Satuan</th>
										</tr>
										<?php $no=1; if($liststock){ foreach($liststock as $l): ?>
										<tr>
											<td width="10%" class="text-center"><?php echo $no; ?></td>
											<td width="15%"><?php echo $l["nama_barang"]; ?></td>
											<td width="10%"><?php echo $l["stock"]; ?></td>
											<td width="20%"><?php echo "Rp. ".number_format($l["harga_satuan"]); ?></td>
										</tr>
										<?php $no++; endforeach; }else{ ?>
											<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
										<?php } ?>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>