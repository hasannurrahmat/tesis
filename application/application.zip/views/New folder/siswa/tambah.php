<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 50% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tambah Dana Siswa</h3>
							</div>
							
							<h4><?php echo $listsiswa->nis; ?>/<?php echo $listsiswa->kelas; ?>/<?php echo $listsiswa->nama; ?></h4><hr>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>siswa/submit_dana_siswa" method="POST">
							  	<input type="hidden" name="id_kelas" value="<?php echo $listsiswa->id_kelas?>">
								<input type="hidden" name="id_siswa" value="<?php echo $listsiswa->id_siswa?>">
									
								 <?php foreach($jenis_dana as $j){ ?>
								 	<div class="form-group">
									    <label for="form" class="col-sm-4"><?php echo $j->jenis_dana; ?></label>
									    <div class="col-sm-4">
									    	<input type="text" class="form-control" placeholder="<?php echo $j->jenis_dana; ?>" name="jenis_dana[<?php echo $listsiswa->id_siswa; ?>][<?php echo $j->id_jenis_dana; ?>]" value="<?php echo $dana[$listsiswa->id_siswa][$j->id_jenis_dana]; ?>" <?php if(strpos("x".$j->jenis_dana, 'JUMLAH') !== false){echo "disabled";} ?>>
										</div>
									</div>
								<?php } ?>
							  <button type="submit" class="btn btn-primary pull-left">Simpan</button>
							</form>

						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		
	<script>
	
	
	function submitform()
	{
	  document.myform.submit();
	}
	
</script>

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>