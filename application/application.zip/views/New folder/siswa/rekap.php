<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>

		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Rekap Harian</h3>
								
							</div>
							<form class="form-horizontal" role="form" action ="" method="POST">
									<label for="kelas" class="col-md-1 control-label">Tanggal</label>
									<div class="col-md-2">
										<input class="form-control" type="date" name="tanggal" value="<?php echo $tanggal;?>">
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
							</form>
							<?PHP if($listrekap || $listrekap_ppdb){ ?>
							
							<?php 
								//menghitung pembayaran tiap kasir
								$jumlah = array();
								foreach($listkasir as $lk){
									$jumlah[$lk->id_user] = 0;
								}
							?>
							
							<!-- tab panel -->
							<div>

							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							    <li role="presentation" class="active"><a href="#pembayaran" aria-controls="pembayaran" role="tab" data-toggle="tab">Pembayaran</a></li>
							    <li role="presentation"><a href="#ppdb" aria-controls="ppdb" role="tab" data-toggle="tab">PPDB</a></li>
							    <li role="presentation"><a href="#tabungan" aria-controls="tabungan" role="tab" data-toggle="tab">Tabungan Wisata</a></li>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							    
							  	<!-- Pembayaran -->
							  	<?php 
									//menghitung pembayaran tiap kasir
									$jumlah = array();
									foreach($listkasir as $lk){
										$jumlah[$lk->username] = 0;
									}
								?>
							    <div role="tabpanel" class="tab-pane active" id="pembayaran">
							    	<br>
						    		<div class="table-responsive">
									  <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">SISWA</th>
											<th width="150px">KELAS</th>
											<th width="300px">JENIS DANA</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
											<?php if($this->session->userdata('jenis_admin')!=1){ ?>
											<th width="150px" class="text-center">AKSI</th>
											<?php } ?>
										</thead>
										<tbody>
											<?php $j=0; if($listrekap){ $no=1; foreach($listrekap as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->kelas; ?></td>
												<td><?php echo $l->jenis_dana; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
												<?php if($this->session->userdata('jenis_admin')!=1){ ?>
												<td><a href="<?php echo base_url(); ?>siswa/hapus_rekap_pembayaran/<?php echo $l->id_rekap_harian; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
												<?php } ?>
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									  <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah as $u=>$val){
									    		echo '<p>'.$u.' : '.number_format($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo "Rp. ".number_format($j); ?></h4>

									</div>
									
									<!-- print excel -->
									<?php 
										//menghitung pembayaran tiap kasir
										$jumlah = array();
										foreach($listkasir as $lk){
											$jumlah[$lk->username] = 0;
										}
									?>
									<div style="display:none;" id="rekap_pembayaran" summary="Data PPDB">
									  <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">SISWA</th>
											<th width="150px">KELAS</th>
											<th width="300px">JENIS DANA</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
											
										</thead>
										<tbody>
											<?php $j=0; if($listrekap){ $no=1; foreach($listrekap as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->kelas; ?></td>
												<td><?php echo $l->jenis_dana; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
												
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									  <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah as $u=>$val){
									    		echo '<p>'.$u.' : '.($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo ($j); ?></h4>
									</div>
									<input type="button" onclick="tableToExcel('rekap_pembayaran', 'Tabel Rekap Pembayaran' , 'rekap_pembayaran.xls', 'Excel')" value="print to excel" class="btn btn-success">

							    </div>

							  	<!-- PPDB -->
							  	<?php 
									//menghitung pembayaran tiap kasir
									$jumlah_ppdb = array();
									foreach($listkasir as $lk){
										$jumlah_ppdb[$lk->username] = 0;
									}
								?>
							    <div role="tabpanel" class="tab-pane" id="ppdb">
							    	<br>
						    		<div class="table-responsive">
									  <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">NOMOR PENDAFTARAN</th>
											<th width="150px">SISWA</th>
											<th width="300px">JENIS PEMBAYARAN PPDB</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
											<?php if($this->session->userdata('jenis_admin')!=1){ ?>
											<th width="150px" class="text-center">AKSI</th>
											<?php } ?>
										</thead>
										<tbody>
											<?php $j = 0; if($listrekap_ppdb){ $no=1; foreach($listrekap_ppdb as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->no_pendaftaran; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->nama_display; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
												<?php if($this->session->userdata('jenis_admin')!=1){ ?>
												<td><a href="<?php echo base_url(); ?>siswa/hapus_rekap_ppdb/<?php echo $l->id_rekap_harian_ppdb; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
												<?php } ?>
												
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah_ppdb[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									   <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah_ppdb as $u=>$val){
									    		echo '<p>'.$u.' : '.number_format($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo "Rp. ".number_format($j); ?></h4>
									</div>

									<!-- print excel -->
									<?php 
										//menghitung pembayaran tiap kasir
										$jumlah_ppdb = array();
										foreach($listkasir as $lk){
											$jumlah_ppdb[$lk->username] = 0;
										}
									?>
									<div style="display:none;" id="rekap_ppdb" summary="Data PPDB">
									  <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">NOMOR PENDAFTARAN</th>
											<th width="150px">SISWA</th>
											<th width="300px">JENIS PEMBAYARAN PPDB</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
										
										</thead>
										<tbody>
											<?php $j = 0; if($listrekap_ppdb){ $no=1; foreach($listrekap_ppdb as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->no_pendaftaran; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->nama_display; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
																							
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah_ppdb[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									  <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah_ppdb as $u=>$val){
									    		echo '<p>'.$u.' : '.($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo ($j); ?></h4>
									</div>
									<input type="button" onclick="tableToExcel('rekap_ppdb', 'Tabel Rekap PPDB' , 'rekap_ppdb.xls', 'Excel')" value="print to excel" class="btn btn-success">

							    </div>

							  	<!-- Tabungan -->
							  	<?php 
									//menghitung pembayaran tiap kasir
									$jumlah_tabungan = array();
									foreach($listkasir as $lk){
										$jumlah_tabungan[$lk->username] = 0;
									}
								?>
							    <div role="tabpanel" class="tab-pane" id="tabungan">
							    	<br>
						    		<div class="table-responsive">
									  <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">SISWA</th>
											<th width="150px">KELAS</th>
											<th width="300px">JENIS DANA</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
											<?php if($this->session->userdata('jenis_admin')!=1){ ?>
											<th width="150px" class="text-center">AKSI</th>
											<?php } ?>
										</thead>
										<tbody>
											<?php $j=0; if($listrekap_tabungan){ $no=1; foreach($listrekap_tabungan as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->kelas; ?></td>
												<td><?php echo $l->nama_jenis; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
												<?php if($this->session->userdata('jenis_admin')!=1){ ?>
												<td><a href="<?php echo base_url(); ?>siswa/hapus_rekap_wisata/<?php echo $l->id_rekap_harian_wisata; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
												<?php } ?>
												
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah_tabungan[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									  <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah_tabungan as $u=>$val){
									    		echo '<p>'.$u.' : '.number_format($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo "Rp. ".number_format($j); ?></h4>
									    <h4>Total Pembayaran dari <?php echo $jum_siswa; ?> Siswa yang sudah bayar adalah <?php echo "Rp. ".number_format($jum_total); ?></h4>
									</div>
									<!-- print excel -->
									<?php 
										//menghitung pembayaran tiap kasir
										$jumlah_tabungan = array();
										foreach($listkasir as $lk){
											$jumlah_tabungan[$lk->username] = 0;
										}
									?>
									<div style="display:none;" id="rekap_wisata" summary="Data PPDB">
									   <table class="table table-bordered table-striped">
										<thead class="info" style="background-color:#66b3ff;">
											<th width="100px" class="text-center">NO</th>
											<th width="300px">SISWA</th>
											<th width="150px">KELAS</th>
											<th width="300px">JENIS DANA</th>
											<th width="150px" class="text-center">NILAI</th>
											<th width="150px" class="text-center">USER</th>
											
										</thead>
										<tbody>
											<?php $j=0; if($listrekap_tabungan){ $no=1; foreach($listrekap_tabungan as $l){ ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->nama; ?></td>
												<td><?php echo $l->kelas; ?></td>
												<td><?php echo $l->nama_jenis; ?></td>
												<td><?php echo $l->nilai; ?></td>
												<td><?php echo $l->username; ?></td>
												
												<?php 
													foreach($listkasir as $lk){
														if($lk->id_user==$l->id_user){
															$jumlah_tabungan[$lk->username] += $l->nilai;
														}
													}
													$j+=$l->nilai;
												?>
											</tr>
											<?php $no++;} }else{ ?>
											<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
											<?php } ?>
										</tbody>
									  </table>
									  <?php
									    	echo '<h4>Total Pembayaran Tiap Kasir</h4>';
									    	foreach($jumlah_tabungan as $u=>$val){
									    		echo '<p>'.$u.' : '.($val).'</p>';
									    	}
									    ?>
									    <h4>Total Keseluruhan : <?php echo ($j); ?></h4>
									    <h4>Total Pembayaran dari <?php echo $jum_siswa; ?> Siswa yang sudah bayar adalah <?php echo "Rp. ".number_format($jum_total); ?></h4>
									</div>
									<input type="button" onclick="tableToExcel('rekap_wisata', 'Tabel Rekap Tabungan Wisata' , 'rekap_wisata.xls', 'Excel')" value="print to excel" class="btn btn-success">

							    </div>
							  </div>

							</div>

							
							<br>
							
								<?php }else{ ?>
								<div class="alert alert-warning alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Tidak Ada Pembayaran Untuk Hari Ini.
								</div>
								<?php } ?>
						
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		
	<script>
	
	
	function submitform()
	{
	  document.myform.submit();
	}
	
</script>

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>