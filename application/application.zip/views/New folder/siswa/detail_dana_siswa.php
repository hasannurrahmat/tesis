<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
		<style>
			.tablescroll {  
				height: 50% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Dana Pembayaran</h3>
							</div>
							<h4>Nama : <?php echo $nama;?>&nbsp;/&nbsp;NIS : <?php echo $nis;?></h4>
							
							<div>
							
							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							  	<?php foreach ($kelas as $i=>$k) { ?>
							    	<li role="presentation" <?php if($i==0){ echo "class='active'";} ?>><a href="#<?php echo $k->id_kelas; ?>" aria-controls="<?php echo $k->id_kelas; ?>" role="tab" data-toggle="tab"><?php echo $k->kelas; ?></a></li>
							  	<?php } ?>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							  	<?php foreach ($kelas as $i=>$k) { ?>
							    	<div role="tabpanel" class="tab-pane <?php if($i==0){ echo "active";} ?>" id="<?php echo $k->id_kelas; ?>">
							    		<br>
							    		<table class="table table-bordered">
							    		<?php foreach ($list as $l => $v) {
							    			if($l==$k->kelas){
							    				foreach ($v['dana'] as $key => $value) {
							    					foreach ($jenis_dana as $j) {
														if($j->id_jenis_dana==$key){
															echo '<tr>';
															echo "<td class='active'>".$j->jenis_dana.'</td><td>'.number_format($value).'</td>';
															echo '</tr>';
														}
													}
												}
							    			}
							    		} ?>
							    		</table>
							    		<a href="<?php echo base_url();?>siswa/tambah/<?php echo $id_siswa?>/<?php echo $k->id_kelas ?>"><button type="button" class="btn btn-primary">Update Dana</button></a>
							    		<input type="button" onclick="tableToExcel('sma1larangan', 'Tabel Data Pembayaran' , 'data_pembayaran.xls', 'Excel')" value="Print to Excel" class="btn btn-success">
							    	</div>
							    <?php } ?>

							  </div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div style="display:none;" id="sma1larangan" summary="Data Pembayaran">
			<?php foreach ($kelas as $i=>$k) { ?>
		    		<?php foreach ($list as $l => $v) {
		    			if($l==$k->kelas){
		    		?>
				    	<p>Nama : <?php echo $nama; ?><br>
				    	NIS : <?php echo $nis; ?><br>
				    	Kelas : <?php echo $k->kelas?><br>
				    	<b>Catatan Pembayaran Siswa</b></p>

			    		<table border="1">
			    		<?php
		    				foreach ($v['dana'] as $key => $value) {
		    					foreach ($jenis_dana as $j) {
									if($j->id_jenis_dana==$key){
										echo '<tr>';
										echo "<td class='active'>".$j->jenis_dana.'</td><td>'.number_format($value).'</td>';
										echo '</tr>';
									}
								}
							}
		    			?></table>
		    			<?php
		    			}
		    		} ?>
		    <?php } ?>
		</div>
		<?php $this->load->view('template/footer'); ?>
	

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>