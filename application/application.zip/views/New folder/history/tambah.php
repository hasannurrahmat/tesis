<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<?php if($jenis=='tambah'){ ?>
								<h3>Tambah Siswa</h3>
							<?php }else{ ?>
								<h3>Edit Siswa</h3>
							<?php } ?>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url(); ?>student/submit" method="POST">
								<input type="hidden" name="id" value="<?php echo $id_siswa; ?>">
								<input type="hidden" name="jenis" value="<?php echo $jenis; ?>">
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">NIS</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id="nis" placeholder="NIS" name="nis" value="<?php echo $nis; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">NISN</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id="nisn" placeholder="NISN" name="nisn" value="<?php echo $nisn; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Nama</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id="nama" placeholder="Nama Lengkap" name="nama" value="<?php echo $nama; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Jenis Kelamin</label>
									<div class="col-sm-10">
										<select class="form-control" id="sel1" name="jenis_kelamin">
										<option>-- Pilih Jenis Kelamin --</option>
										<option <?php if($jenis_kelamin=="L"){echo "selected";}; ?> value="L">Laki-Laki</option>
										<option <?php if($jenis_kelamin=="P"){echo "selected";}; ?> value="P">Perempuan</option>
										
									</select>
									</div>
								</div>
								<hr>
								<div class="pull-right">
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>
