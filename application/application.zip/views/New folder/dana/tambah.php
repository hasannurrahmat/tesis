<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<?php if($jenis=='tambah'){ ?>
								<h3>Tambah Jenis Dana</h3>
							<?php }else{ ?>
								<h3>Edit Jenis Dana</h3>
							<?php } ?>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url(); ?>dana/submit" method="POST">
								<input type="hidden" name="id" value="<?php echo $id_jenis_dana; ?>">
								<input type="hidden" name="jenis" value="<?php echo $jenis; ?>">
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Jenis Dana</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id="dana" placeholder="Nama Jenis Dana" name="jenis_dana" value="<?php echo $jenis_dana; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Tingkat</label>
									<div class="col-sm-10">
									<select class="form-control" id="sel1" name="tingkat">
										<option value=0>-- Pilih Tingkat --</option>
										<?php foreach($tingkat as $in): ?>
										<?php if($in->id_tingkat == $id_tingkat){ ?>
											<option selected value="<?php echo $in->id_tingkat; ?>"><?php echo $in->nama_tingkat; ?></option>
										<?php }else{ ?>
											<option value="<?php echo $in->id_tingkat; ?>"><?php echo $in->nama_tingkat; ?></option>
										<?php } endforeach; ?>
									</select>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Jenis</label>
									<div class="col-sm-10">
									<select class="form-control" id="sel1" name="listjenis">
										<option value=0>-- Pilih Jenis --</option>
										<?php foreach($listjenis as $in): ?>
										<?php if($in->id_jenis == $id_jenis){ ?>
											<option selected value="<?php echo $in->id_jenis; ?>"><?php echo $in->jenis; ?></option>
										<?php }else{ ?>
											<option value="<?php echo $in->id_jenis; ?>"><?php echo $in->jenis; ?></option>
										<?php } endforeach; ?>
									</select>
									</div>
								</div>
								<hr>
								<div class="pull-right">
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>
