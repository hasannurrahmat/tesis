<?php 
	if(isset($_POST['tingkat'])){
	$a = $_POST['tingkat'];
	$id_tingkat = $a; }
	?>
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>Menu Pencarian <a href="<?php echo base_url();?>dana/tambah/<?php echo $id_tingkat; ?>"><button class="btn btn-success pull-right">Tambah</button></a></h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>dana/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-sm-2 control-label">Tingkat</label>
									<div class="col-md-5">
									<select class="form-control" id="sel1" name="tingkat">
										<option value=0>-- Pilih Tingkat --</option>
										<?php foreach($tingkat as $in): ?>
										<?php if($in->id_tingkat == $id_tingkat){ ?>
											<option selected value="<?php echo $in->id_tingkat; ?>"><?php echo $in->nama_tingkat; ?></option>
										<?php }else{ ?>
											<option value="<?php echo $in->id_tingkat; ?>"><?php echo $in->nama_tingkat; ?></option>
										<?php } endforeach; ?>
									</select>
									</div>
									<button type="submit" class="btn btn-primary">Cari</button>
								</div>
							</form>
							
							
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>List Jenis Dana</h3>
							</div>

							<table class="table table-condensed table-responsive table-bordered">
							<tr class="active">
								<th class="text-center">No</th>
								<th class="text-center">Jenis Dana</th>
								<th class="text-center">Jenis</th>
								<th class="text-center">Aksi</th>
							</tr>
							<?php if($id_tingkat){ ?>
							<?php $no=1; if($listdana){ foreach($listdana as $l): ?>
							<?php if($l->id_tingkat == $id_tingkat){ ?>
							<tr>
								<td width="10%" class="text-center"><?php echo $no; ?></td>
								<td width="50%"><?php echo $l->jenis_dana; ?></td>
								<td width="20%" class="text-center"><?php echo $l->jenis; ?></td>
								<td width="20%" class="text-center"><a href="<?php echo base_url();?>dana/ubah/<?php echo $l->id_jenis_dana; ?>">Ubah</a> | <a href="<?php echo base_url();?>dana/hapus/<?php echo $l->id_jenis_dana; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
							</tr>
							<?php $no++; } endforeach; }else{ ?>
							<tr><td colspan=4>Tidak ada data, silahkan tambah data</td></tr>
							<?php } ?>
								
							<?php }else{ ?>
								<tr><td colspan=5>Pilih Tingkat Lebih Dulu</td></tr>
							<?php } ?>
							</table>
							
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>