<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>Menu Pencarian</h3>
							</div>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform">
								<div class="form-group">
									<label for="tahun" class="col-md-2 control-label">Tahun Ajaran</label>
									<div class="col-md-2">
									<select class="form-control" name="tahun_ajaran" id="tahun_ajaran" onchange="submitform();">
										<option value="">-- Pilih Tahun Ajaran --</option>
										<?php foreach($tahun_ajaran as $j){ ?>
										<?php if($j->id_tahun_ajaran == $id_tahun_ajaran){ ?>
										  <option selected value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php }else{ ?>
										  <option value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php } } ?>
									</select>
									</div>									
							</form>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform1">
									<input type="hidden" name="tahun_ajaran" value="<?php echo $id_tahun_ajaran; ?>">
									<label for="kelas" class="col-md-1 control-label">Kelas</label>
									<div class="col-md-2">
										<select class="form-control" name="kelas" id="kelas">
											<option value="">-- Pilih Kelas --</option>
											<?php foreach($kelas as $j){ ?>
											<?php if($j->id_kelas == $id_kelas){ ?>
											  <option selected value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php }else{ ?>
											  <option value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php } } ?>
										</select>
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
							
							
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>List Kelas Siswa</h3>
							</div>
							<a href="<?php echo base_url();?>kelas_siswa/tambah/<?php echo $id_tahun_ajaran; ?>/<?php echo $id_kelas; ?>"><button class="btn btn-success">Tambah</button></a>
							<a href="#import" data-toggle="modal"><button type="button" class="btn btn-success">Import Kelas Siswa</button></a>
							<a href="<?php echo base_url();?>kelas_siswa/siswa"><button class="btn btn-success">Mutasi</button></a>
							<br>
							<br>
							<table class="table table-condensed table-responsive table-bordered">
							<tr class="active">
								<th class="text-center">No</th>
								<th class="text-center">NIS</th>
								<th class="text-center">NISN</th>
								<th class="text-center">Nama</th>
								<th class="text-center">Jenis Kelamin</th>
							</tr>
							<?php if($id_kelas && $id_tahun_ajaran){ ?>
							<?php $no=1; if($listkelas_siswa){ foreach($listkelas_siswa as $l): ?>
							<?php if($l->id_kelas == $id_kelas && $l->id_tahun_ajaran == $id_tahun_ajaran){ ?>
							<tr>
								<td width="10%" class="text-center"><?php echo $no; ?></td>
								<td width="15%"><?php echo $l->nis; ?></td>
								<td width="15%"><?php echo $l->nisn; ?></td>
								<td width="45%"><?php echo $l->nama; ?></td>
								<td width="15%"><?php if($l->jenis_kelamin=="L"){echo "Laki-laki";}else{echo "Perempuan";} ?></td>
								
							</tr>
							<?php $no++; } endforeach; }else{ ?>
							<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
							<?php } ?>
								
							<?php }else{ ?>
								<tr><td colspan=5>Pilih Tahun Ajaran dan Kelas Lebih Dulu</td></tr>
							<?php } ?>
							</table>
							
							
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<form class="form-horizontal" role="form" action="<?php echo base_url('kelas_siswa/import_kelas_siswa'); ?>" method="post" enctype="multipart/form-data">
						<div class="modal-header">
							<h4>Import Kelas Siswa</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="file" class="col-sm-2 control-label">Pilih File</label>
								<div class="col-sm-10">
									<input type="file" name="file" size="20" />
								</div>
							</div>
							<div class="form-group">
							</div>
						</div>
						<div class="modal-footer">
								<a href="<?php echo base_url(); ?>kelas_siswa/download" class="pull-left">Download Template File</a>
							<a class="btn btn-default" data-dismiss="modal">Cancel</a>
							<button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin akan mengimport data dari file tersebut?')">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script>
			function submitform()
			{
			  document.myform.submit();
			}
			
		</script>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>