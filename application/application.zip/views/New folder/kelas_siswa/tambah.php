<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/bootstrap-duallistbox.css" rel="stylesheet">
	
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
		<script src="<?php echo base_url();?>js/jquery.bootstrap-duallistbox.js"></script>
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
						<br>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform">
									<div class="form-group">
										<label for="tahun" class="col-md-2 control-label">Tahun Ajaran</label>
										<div class="col-md-2">
										<select class="form-control" name="tahun_ajaran" id="tahun_ajaran" onchange="submitform();">
											<option value="">-- Pilih Tahun Ajaran --</option>
											<?php foreach($tahun_ajaran as $j){ ?>
											<?php if($j->id_tahun_ajaran == $id_tahun_ajaran){ ?>
											  <option selected value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
											<?php }else{ ?>
											  <option value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
											<?php } } ?>
										</select>
										</div>									
								</form>
								<form class="form-horizontal" role="form" action ="" method="POST" name="myform1">
										<input type="hidden" name="tahun_ajaran" value="<?php echo $id_tahun_ajaran; ?>">
										<label for="kelas" class="col-md-1 control-label">Kelas</label>
										<div class="col-md-2">
											<select class="form-control" name="kelas" id="kelas">
												<option value="">-- Pilih Kelas --</option>
												<?php foreach($kelas as $j){ ?>
												<?php if($j->id_kelas == $id_kelas){ ?>
												  <option selected value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
												<?php }else{ ?>
												  <option value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
												<?php } } ?>
											</select>
										</div>
										<button type="submit" class="btn btn-default">Cari</button>
									</div>
								</form>
								
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Isi Kelas</h3>
							</div>
								
								<form id="demoform" action="<?php echo base_url();?>kelas_siswa/submit" method="post">
									<input type="hidden" name="id_kelas" value="<?php echo $id_kelas; ?>">
									<select multiple="multiple" size="10" name="siswa[]">
								
									<?php foreach($list as $l){ ?>
									
									  <option <?php if($l['selected']==1){echo 'selected';}?> value="<?php echo $l['value']; ?>"><?php echo $l['nama']; ?></option>
									<?php } ?>
									  
									</select>
									<br>
									<button type="submit" class="btn btn-default btn-block">Submit data</button>
								  </form>
								 

							
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		
		 <script>
			var demo1 = $('select[name="siswa[]"]').bootstrapDualListbox();
			$("#demoform").submit(function() {
			  // alert($('[name="siswa[]"]').val());
			  // return false;
			  document.location = "<?php echo base_url();?>kelas_siswa/submit";
			}
			);
		  </script>
		<script>
			function submitform()
			{
			  document.myform.submit();
			}
			
		</script>
	</body>
</html>
