<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 50% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Mutasi Siswa</h3>
							</div>
							<h4>Nama : <?php echo $nama;?>&nbsp;/&nbsp;NIS : <?php echo $nis;?></h4>
							
							<div>
						
							    		<br>
							    		<table class="table table-bordered">
							    			<thead>
							    				<th class="text-center">Kelas</th>
							    				<th class="text-center">Tingkat</th>
							    				<th class="text-center">Tahun Ajaran</th>
							    				<th class="text-center">Aksi</th>
							    			</thead>
							    			<tbody>
								  				<?php foreach ($list as $i=>$k) { ?>
								  				<tr>
								  					<td class="text-center"><?php echo $i;?></td>
								  					<td class="text-center"><?php echo $k['tingkat'];?></td>
								  					<td class="text-center"><?php echo $k['tahun_ajaran'];?></td>
								  					<td class="text-center"><a href="<?php echo base_url();?>kelas_siswa/hapus_kelas_siswa/<?php echo $id_siswa; ?>/<?php echo $k['id_kelas']; ?>" onclick="return confirm('Apakah Anda yakin akan menghapus data siswa di kelas ini? data pembayaran yang ada dikelas ini juga akan ikut terhapus, harap di backup terlebih dahulu jika data pembayaran tersebut penting.')">Hapus</a></td>
								  				</tr>
								    			<?php } ?>
							    			</tbody>
							    		
							    		</table>
							    		<a href="<?php echo base_url();?>kelas_siswa/tambah_kelas/<?php echo $id_siswa?>/" class="btn btn-primary">Tambah Kelas</a>
							    

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
	

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>