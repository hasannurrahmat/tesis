<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<?php if($jenis=='tambah'){ ?>
								<h3>Tambah Peserta PPDB</h3>
							<?php }else{ ?>
								<h3>Edit Peserta PPDB</h3>
							<?php } ?>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url(); ?>ppdb/submit" method="POST">
								<input type="hidden" name="id_ppdb" value="<?php echo $id_ppdb; ?>">
								<input type="hidden" name="tahun" value="<?php echo date('Y'); ?>">
								<input type="hidden" name="jenis" value="<?php echo $jenis; ?>">
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Tahun Peserta PPDB</label>
									<div class="col-sm-10">
										<select class="form-control" id="tahun" name="tahun">
											<?php foreach($tahun_ajaran as $p): ?>
												<option value="<?php echo $p->tahun_ajaran; ?>" <?php if($tahun==$p->tahun_ajaran){echo 'selected';} ?>><?php echo $p->tahun_ajaran; ?></option>
											<?php endforeach; ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Nomor Pendaftaran</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Nomor Pendaftaran" name="no_pendaftaran" value="<?php echo $no_pendaftaran; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Nama Peserta</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Nama Peserta" name="nama" value="<?php echo $nama; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label">Jenis Kelamin</label>
									<div class="col-sm-10">
										<select class="form-control" name="jenis_kelamin">
											<option value="L" <?php if($jenis_kelamin=='L'){echo 'selected';} ?>>Laki-Laki</option>
											<option value="P" <?php if($jenis_kelamin=='P'){echo 'selected';} ?>>Perempuan</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="dibayar" class="col-sm-2 control-label">Jumlah Dibayar</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Jumlah Yang Harus Dibayar" name="jumlah_dibayar" value="<?php echo $jumlah_dibayar; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="administrasi" class="col-sm-2 control-label">Administrasi</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Administrasi" name="administrasi" value="<?php echo $administrasi; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="pakaian" class="col-sm-2 control-label">Pakaian Seragam</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Pakaian Seragam" name="pakaian" value="<?php echo $pakaian; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="kaos" class="col-sm-2 control-label">Kaos Olahraga</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Kaos Olahraga" name="kaos" value="<?php echo $kaos; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="jilbab" class="col-sm-2 control-label">Jilbab</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Jilbab" name="jilbab" value="<?php echo $jilbab; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="atribut" class="col-sm-2 control-label">Atribut</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Atribut" name="atribut" value="<?php echo $atribut; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="dp" class="col-sm-2 control-label">Dana Pembangunan Sekolah</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Dana Pembangunan Sekolah" name="dp" value="<?php echo $dp; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="kartu" class="col-sm-2 control-label">Kartu Perpustakan</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Kartu Perpustakaan" name="kartu" value="<?php echo $kartu; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="bantuan" class="col-sm-2 control-label">Bantuan Modal Koperasi</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Bantuan Modal Koperasi" name="bantuan" value="<?php echo $bantuan; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="titipan" class="col-sm-2 control-label">Titipan Studi Wisata</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Titipan Studi Wisata" name="titipan" value="<?php echo $titipan; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="titipan" class="col-sm-2 control-label">Kegiatan HUT SMA, Kegiatan PHBI, dan PHBN</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Kegiatan HUT SMA, Kegiatan PHBI, dan PHBN" name="hut" value="<?php echo $hut; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="komite" class="col-sm-2 control-label">Komite Bulan Juli <?php echo$tahun?></label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Komite Bulan Juli <?php echo $tahun;?>" name="komite" value="<?php echo $komite; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="qurban" class="col-sm-2 control-label">Qurban</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Qurban" name="qurban" value="<?php echo $qurban; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="dansos" class="col-sm-2 control-label">Asuransi</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran Asuransi" name="dansos" value="<?php echo $dansos; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="ppta" class="col-sm-2 control-label">PPTA</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Pembayaran PPTA" name="ppta" value="<?php echo $ppta; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="ppta" class="col-sm-2 control-label">Kartu OSIS</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Kartu OSIS" name="osis" value="<?php echo $osis; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="ppta" class="col-sm-2 control-label">KTA</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="KTA" name="kta" value="<?php echo $kta; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="ppta" class="col-sm-2 control-label">Jumlah Terbayar</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Jumlah Terbayar" name="jumlah_terbayar" value="<?php echo $jumlah_terbayar; ?>" disabled>
									</div>
								</div>
								<div class="form-group">
									<label for="ppta" class="col-sm-2 control-label">Jumlah Tunggakan PPDB</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Jumlah Tunggakan PPDB" name="jumlah_tunggakan_ppdb" value="<?php echo $jumlah_tunggakan_ppdb; ?>" disabled>
									</div>
								</div>
								
								<hr>
								<div class="pull-right">
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>
