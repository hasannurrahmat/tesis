<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title">Bukti Pembayaran</h3>
						</div>
						<div class="panel-body">
							<center><h3>Bukti Pembayaran SMAN 1 Larangan</h3></center>
							<hr>
							<div class="row">
								<div class="col-md-9">
									<table width="100%" cellpadding="5">
										<tr>
											<td width="10%">Nomor Pendaftaran</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo $no_pendaftaran?></td>
										</tr>
										<tr>
											<td width="10%">Nama</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo $nama?></td>
										</tr>
										<tr>
											<td width="10%">Tanggal</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo date('d/m/Y'); ?></td>
										</tr>
									</table>
								</div>
								<div class="col-md-1"></div>
								<div class="col-md-2">
									<img src="<?php echo base_url();?>uploads/sma.png" width="100px" height="110px" style="border:1px solid black" class="pull-center">
								</div>
							</div>
							<br>
							<h4><b>Pembayaran PPDB</b></h4>
							<div class="table-responsive">
								<table class="table table-bordered table-striped">
									<thead class="info">
										<th>Jenis Pembayaran</th>
										<th>Uang Sebesar</th>
									</thead>
									<tbody>
										<?php $jumlah=0; if($list){ foreach($list as $l=>$val){ ?>
										<tr>
											<td><?php echo $l;?></td>
											<td><?php echo $val;?></td>
										</tr>
										<?php $jumlah += $val;} } ?>
									</tbody>
								</table>
							</div>
							<div class="row">
								<div class="col-md-4"><h4>Jumlah Pembayaran: <b><?php echo $jumlah;?></b></h4></div>
								<div class="col-md-5"></div>
								<div class="col-md-3">
									<center><h4>Petugas</h4></center>
									<br>
									<br>
									<br>
									<center><h4><?php echo $this->session->userdata("username");?></h4></center>
								</div>
							</div>
							<hr>
							<a href="<?php echo base_url();?>ppdb/print_pdf"><button type="button" class="btn btn-success pull-left">Cetak</button></a>
							<br>
						</div>
					</div>
				</div>
			</div>
			
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>