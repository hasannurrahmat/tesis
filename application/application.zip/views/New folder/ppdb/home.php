<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
						<br>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform">
								<div class="form-group">
									<label for="no" class="col-md-2 control-label">Nomor Pendaftaran</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="no_pendaftaran" value="<?php echo $no_pendaftaran?>">
									</div>									
									<label for="kelas" class="col-md-1 control-label">Nama</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nama" value="<?php echo $nama?>">
									</div>
									<label for="kelas" class="col-md-1 control-label">Tahun</label>
									<div class="col-md-2">
										<select class="form-control" id="tahun" name="tahun">
										<?php foreach($tahun_ajaran as $p): ?>
											<option value="<?php echo $p->tahun_ajaran; ?>" <?php if($tahun==$p->tahun_ajaran){echo 'selected';} ?>><?php echo $p->tahun_ajaran; ?></option>
										<?php endforeach; ?>
									</select>
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tabel Peserta PPDB <?php echo $tahun;?></h3>
							</div>

							<a href="<?php echo base_url();?>ppdb/tambah"><button type="button" class="btn btn-primary">Tambah PPDB Peserta</button></a>
							<?php if($this->session->userdata('jenis_admin')!=1){ ?>
							<a href="#import" data-toggle="modal"><button type="button" class="btn btn-primary">Import PPDB Peserta</button></a>
							<?php } ?>
							<br>
							<br>
							<?PHP if($listsiswa){ ?>
							<div class="tablescroll">
							<div class="table-responsive">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">AKSI</th>
									<th width="150px" class="text-center">NOMOR PENDAFTARAN</th>
									<th width="300px" class="text-center">NAMA</th>
									<th width="200px" class="text-center">JENIS KELAMIN</th>
									<th width="150px" class="text-center">JUMLAH YANG HARUS DIBAYAR</th>
									<th width="150px" class="text-center">ADMINISTRASI</th>
									<th width="150px" class="text-center">PAKAIAN SERAGAM</th>
									<th width="150px" class="text-center">KAOS OLAHRAGA</th>
									<th width="150px" class="text-center">JILBAB</th>
									<th width="150px" class="text-center">ATRIBUT</th>
									<th width="150px" class="text-center">DANA PENGEMBANGAN SEKOLAH</th>
									<th width="150px" class="text-center">KARTU PERPUSTAKAAN</th>
									<th width="150px" class="text-center">BANTUAN MODAL KOPERASI</th>
									<th width="150px" class="text-center">TITIPAN TABUNGAN WISATA</th>
									<th width="150px" class="text-center">KEGIATAN HUT SMA, KEGIATAN PHBI, DAN PHBN</th>
									<th width="150px" class="text-center">KOMITE PEMBAYARAN BULAN JULI <?php echo date('Y');?></th>
									<th width="150px" class="text-center">QURBAN</th>
									<th width="150px" class="text-center">ASURANSI</th>
									<th width="150px" class="text-center">PPTA</th>
									<th width="150px" class="text-center">KARTU OSIS</th>
									<th width="150px" class="text-center">KTA</th>
									<th width="150px" class="text-center">JUMLAH TERBAYAR</th>
									<th width="150px" class="text-center">JUMLAH TUNGGAKAN PPDB</th>
									
								</thead>
								<tbody>
									<?php $no=1; foreach($listsiswa as $l){ ?>
									<tr>
										<td><?php echo $no?></td>
										<td class="text-center"><a href="<?php echo base_url();?>ppdb/ubah/<?php echo $l->id_ppdb;?>">Update</a>
											<?php if($this->session->userdata('jenis_admin')!=1){ ?>
											&nbsp;|&nbsp;
											<a href="<?php echo base_url();?>ppdb/hapus/<?php echo $l->id_ppdb;?>" onclick="return confirm('Apakah Anda yakin akan menghapus data ini?.')">Hapus</a>
											<?php }?>
										</td>
										<?php $terbayar = ($l->administrasi+$l->pakaian+$l->kaos+$l->jilbab+$l->atribut+$l->dp+$l->kartu+$l->bantuan+$l->titipan+$l->hut+$l->komite+$l->qurban+$l->dansos+$l->osis+$l->ppta+$l->kta); ?>
										<td><?php echo $l->no_pendaftaran?></td>
										<td><?php echo $l->nama?></td>
										<td><?php if($l->jenis_kelamin=='L'){echo 'Laki-Laki';}else{echo 'Perempuan';} ?></td>
										<td><?php echo "Rp. ".number_format($l->jumlah_dibayar);?></td>
										<td><?php echo "Rp. ".number_format($l->administrasi);?></td>
										<td><?php echo "Rp. ".number_format($l->pakaian);?></td>
										<td><?php echo "Rp. ".number_format($l->kaos);?></td>
										<td><?php echo "Rp. ".number_format($l->jilbab);?></td>
										<td><?php echo "Rp. ".number_format($l->atribut);?></td>
										<td><?php echo "Rp. ".number_format($l->dp);?></td>
										<td><?php echo "Rp. ".number_format($l->kartu);?></td>
										<td><?php echo "Rp. ".number_format($l->bantuan);?></td>
										<td><?php echo "Rp. ".number_format($l->titipan);?></td>
										<td><?php echo "Rp. ".number_format($l->hut);?></td>
										<td><?php echo "Rp. ".number_format($l->komite);?></td>
										<td><?php echo "Rp. ".number_format($l->qurban);?></td>
										<td><?php echo "Rp. ".number_format($l->dansos);?></td>
										<td><?php echo "Rp. ".number_format($l->ppta);?></td>
										<td><?php echo "Rp. ".number_format($l->osis);?></td>
										<td><?php echo "Rp. ".number_format($l->kta);?></td>
										<td><?php echo "Rp. ".number_format($terbayar);?></td>
										<td><?php echo "Rp. ".number_format($l->jumlah_dibayar - $terbayar);?></td>
									</tr>
									<?php $no++;} ?>
								</tbody>
							  </table>
							</div>
							</div>
							<br>
							
							<!-- print excel -->
							<div style="display:none;" id="sma1larangan" summary="Data PPDB">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">NOMOR PENDAFTARAN</th>
									<th width="300px" class="text-center">NAMA</th>
									<th width="200px" class="text-center">JENIS KELAMIN</th>
									<th width="150px" class="text-center">JUMLAH YANG HARUS DIBAYAR</th>
									<th width="150px" class="text-center">ADMINISTRASI</th>
									<th width="150px" class="text-center">PAKAIAN SERAGAM</th>
									<th width="150px" class="text-center">KAOS OLAHRAGA</th>
									<th width="150px" class="text-center">JILBAB</th>
									<th width="150px" class="text-center">ATRIBUT</th>
									<th width="150px" class="text-center">DANA PENGEMBANGAN SEKOLAH</th>
									<th width="150px" class="text-center">KARTU PERPUSTAKAAN</th>
									<th width="150px" class="text-center">BANTUAN MODAL KOPERASI</th>
									<th width="150px" class="text-center">TITIPAN TABUNGAN WISATA</th>
									<th width="150px" class="text-center">KEGIATAN HUT SMA, KEGIATAN PHBI, DAN PHBN</th>
									<th width="150px" class="text-center">KOMITE PEMBAYARAN BULAN JULI <?php echo date('Y');?></th>
									<th width="150px" class="text-center">QURBAN</th>
									<th width="150px" class="text-center">ASURANSI</th>
									<th width="150px" class="text-center">PPTA</th>
									<th width="150px" class="text-center">KARTU OSIS</th>
									<th width="150px" class="text-center">KTA</th>
									<th width="150px" class="text-center">JUMLAH TERBAYAR</th>
									<th width="150px" class="text-center">JUMLAH TUNGGAKAN PPDB</th>
									
								</thead>
								<tbody>
									<?php $no=1; foreach($listsiswa as $l){ ?>
									<tr>
										<td><?php echo $no?></td>
										<?php $terbayar = ($l->administrasi+$l->pakaian+$l->kaos+$l->jilbab+$l->atribut+$l->dp+$l->kartu+$l->bantuan+$l->titipan+$l->hut+$l->komite+$l->qurban+$l->dansos+$l->osis+$l->ppta+$l->kta); ?>
										<td><?php echo $l->no_pendaftaran?></td>
										<td><?php echo $l->nama?></td>
										<td><?php if($l->jenis_kelamin=='L'){echo 'Laki-Laki';}else{echo 'Perempuan';} ?></td>
										<td><?php echo ($l->jumlah_dibayar);?></td>
										<td><?php echo ($l->administrasi);?></td>
										<td><?php echo ($l->pakaian);?></td>
										<td><?php echo ($l->kaos);?></td>
										<td><?php echo ($l->jilbab);?></td>
										<td><?php echo ($l->atribut);?></td>
										<td><?php echo ($l->dp);?></td>
										<td><?php echo ($l->kartu);?></td>
										<td><?php echo ($l->bantuan);?></td>
										<td><?php echo ($l->titipan);?></td>
										<td><?php echo ($l->hut);?></td>
										<td><?php echo ($l->komite);?></td>
										<td><?php echo ($l->qurban);?></td>
										<td><?php echo ($l->dansos);?></td>
										<td><?php echo ($l->ppta);?></td>
										<td><?php echo ($l->osis);?></td>
										<td><?php echo ($l->kta);?></td>
										<td><?php echo $terbayar;?></td>
										<td><?php echo ($l->jumlah_dibayar - $terbayar);?></td>
									</tr>
									<?php $no++;} ?>
								</tbody>
							  </table>
							</div>
							<input type="button" onclick="tableToExcel('sma1larangan', 'Tabel Data PPDB' , 'data_ppdb.xls', 'Excel')" value="Print to Excel" class="btn btn-success">
								<?php }else{ ?>
								<div class="alert alert-warning alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Data peserta Tidak Ditemukan.
								</div>
								<?php } ?>
						
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<form class="form-horizontal" role="form" action="<?php echo base_url('ppdb/import_ppdb'); ?>" method="post" enctype="multipart/form-data">
						<div class="modal-header">
							<h4>Import Peserta PPDB</h4>
						</div>
						<div class="modal-body">
							
							<div class="form-group">
								<label for="tahun" class="col-sm-2 control-label">Tahun</label>
								<div class="col-sm-10">
									<select class="form-control" id="tahun" name="tahun">
										<?php foreach($tahun_ajaran as $p): ?>
											<option value="<?php echo $p->tahun_ajaran; ?>"><?php echo $p->tahun_ajaran; ?></option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>
							
							<div class="form-group">
								<label for="file" class="col-sm-2 control-label">Pilih File</label>
								<div class="col-sm-10">
									<input type="file" name="file" size="20" />
								</div>
							</div>
							<div class="form-group">
							</div>
						</div>
						<div class="modal-footer">
								<a href="<?php echo base_url(); ?>ppdb/download" class="pull-left">Download Template File</a>
							<a class="btn btn-default" data-dismiss="modal">Cancel</a>
							<button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin akan mengimport data dari file tersebut? Data yang ada di tahun yang dipilih akan dihapus dan diganti dengan data dari file ini.')">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>
		
		<?php $this->load->view('template/footer'); ?>

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>