<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<style>
		.borderless tbody tr td, .borderless tbody tr th, .borderless thead tr th {
			border: none;
		}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<hr>
							<div class="page-header">
								<center><h3>BIODATA PNS</h3></center>
							</div>
							<h4><b>A : Lokasi Kerja</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Unit Kerja</td><td width="5%">:</td><td width="70%"><?php echo $unit_kerja;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">Sub Unit Kerja</td><td width="5%">:</td><td width="70%"><?php echo $sub_unit_kerja;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>B : Identitas Pegawai</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">NIP</td><td width="5%">:</td><td width="70%"><?php echo $nip;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">Nama</td><td width="5%">:</td><td width="70%"><?php echo $nama;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tempat Lahir</td><td width="5%">:</td><td width="70%"><?php echo $tempat_lahir;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Tanggal Lahir</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_lahir;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">Jenis Kelamin</td><td width="5%">:</td><td width="70%"><?php echo $jenis_kelamin;?></td></tr>
										<tr><td width="5%">06.</td><td width="20%">Agama</td><td width="5%">:</td><td width="70%"><?php echo $agama;?></td></tr>
										<tr><td width="5%">07.</td><td width="20%">Status Pegawai</td><td width="5%">:</td><td width="70%"><?php echo $status_pegawai;?></td></tr>
										<tr><td width="5%">08.</td><td width="20%">Status Perkawinan</td><td width="5%">:</td><td width="70%"><?php echo $status_perkawinan;?></td></tr>
										<tr><td width="5%">09.</td><td width="20%">Alamat</td><td width="5%">:</td><td width="70%"><?php echo $alamat;?></td></tr>
										<tr><td width="5%">10.</td><td width="20%">Nomor Telpon</td><td width="5%">:</td><td width="70%"><?php echo $no_telpon;?></td></tr>
										<tr><td width="5%">11.</td><td width="20%">Nomor KARPEG</td><td width="5%">:</td><td width="70%"><?php echo $no_karpeg;?></td></tr>
										<tr><td width="5%">12.</td><td width="20%">Nomor ASKES</td><td width="5%">:</td><td width="70%"><?php echo $no_askes;?></td></tr>
										<tr><td width="5%">13.</td><td width="20%">TASPEN</td><td width="5%">:</td><td width="70%"><?php echo $taspen;?></td></tr>
										<tr><td width="5%">14.</td><td width="20%">Nomor NPWP</td><td width="5%">:</td><td width="70%"><?php echo $no_npwp;?></td></tr>
										<tr><td width="5%">15.</td><td width="20%">Golongan Darah</td><td width="5%">:</td><td width="70%"><?php echo $gol_darah;?></td></tr>
										<tr><td width="5%">16.</td><td width="20%">Nomor KARIS/KARSU</td><td width="5%">:</td><td width="70%"><?php echo $no_karis;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>C : Pengangkatan Calon PNS</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Ditetapkan Oleh</td><td width="5%">:</td><td width="70%"><?php echo $ditetapkan_oleh_cpns;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">Tanggal SK CPNS</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_sk_cpns;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">No SK CPNS</td><td width="5%">:</td><td width="70%"><?php echo $no_sk_cpns;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Golongan Ruang</td><td width="5%">:</td><td width="70%"><?php echo $golongan_ruang_cpns;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">TMT SK CPNS</td><td width="5%">:</td><td width="70%"><?php echo $tmt_sk_cpns;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>D : Pengangkatan PNS</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Ditetapkan Oleh</td><td width="5%">:</td><td width="70%"><?php echo $ditetapkan_oleh_pns;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">No SK PNS</td><td width="5%">:</td><td width="70%"><?php echo $no_sk_pns;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tanggal SK PNS</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_sk_pns;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Golongan Ruang</td><td width="5%">:</td><td width="70%"><?php echo $golongan_ruang_pns;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">TMT SK PNS</td><td width="5%">:</td><td width="70%"><?php echo $tmt_sk_pns;?></td></tr>
										<tr><td width="5%">06.</td><td width="20%">Sumpah PNS</td><td width="5%">:</td><td width="70%"><?php echo $sumpah_pns;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>E : Pangkat / Golongan Terakhir</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Ditetapkan Oleh</td><td width="5%">:</td><td width="70%"><?php echo $ditetapkan_oleh_pangkat;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">No SK</td><td width="5%">:</td><td width="70%"><?php echo $no_sk_pangkat;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tanggal SK</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_sk_pangkat;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Golongan Ruang</td><td width="5%">:</td><td width="70%"><?php echo $golongan_ruang_pangkat;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">TMT GOL</td><td width="5%">:</td><td width="70%"><?php echo $tmt_gol;?></td></tr>
										<tr><td width="5%">06.</td><td width="20%">Masa Kerja</td><td width="5%">:</td><td width="70%"><?php echo $masa_kerja_pangkat;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>G : Jabatan Terakhir</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Ditetapkan Oleh</td><td width="5%">:</td><td width="70%"><?php echo $ditetapkan_oleh_jabatan;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">No SK</td><td width="5%">:</td><td width="70%"><?php echo $no_sk_jabatan;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tanggal SK</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_sk_jabatan;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Jabatan</td><td width="5%">:</td><td width="70%"><?php echo $jabatan;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">TMT Jabatan</td><td width="5%">:</td><td width="70%"><?php echo $tmt_jabatan;?></td></tr>
										<tr><td width="5%">06.</td><td width="20%">Eselon</td><td width="5%">:</td><td width="70%"><?php echo $eselon_jabatan;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>H : Pendidikan Umum Terakhir</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Tingkat</td><td width="5%">:</td><td width="70%"><?php echo $tingkat_umum;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">Jurusan</td><td width="5%">:</td><td width="70%"><?php echo $jurusan_umum;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tahun Lulus</td><td width="5%">:</td><td width="70%"><?php echo $tahun_lulus_umum;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>I : Pendidikan Struktural Terakhir</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Tingkat</td><td width="5%">:</td><td width="70%"><?php echo $tingkat_struktural;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">Tanggal Selesai</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_selesai_struktural;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Jumlah Jam</td><td width="5%">:</td><td width="70%"><?php echo $jumlah_jam_struktural;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>J : Orang Tua Kandung</b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Nama Ayah</td><td width="5%">:</td><td width="70%"><?php echo $nama_ayah;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">tempat / Tanggal Lahir</td><td width="5%">:</td><td width="70%"><?php echo $tempat_lahir_ayah.', '.$tanggal_lahir_ayah;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Alamat</td><td width="5%">:</td><td width="70%"><?php echo $alamat_ayah;?></td></tr>
										<tr><td colspan=4>&nbsp;</td></tr>
										<tr><td width="5%">01.</td><td width="20%">Nama Ibu</td><td width="5%">:</td><td width="70%"><?php echo $nama_ibu;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">tempat / Tanggal Lahir</td><td width="5%">:</td><td width="70%"><?php echo $tempat_lahir_ibu.', '.$tanggal_lahir_ibu;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Alamat</td><td width="5%">:</td><td width="70%"><?php echo $alamat_ibu;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>K : <?php if($jenis_kelamin=='l'){echo 'Istri';}else{echo 'Suami';}?></b></h4><hr>
							<div class="table-responsive">
								<table class='table borderless'>
									<tbody>
										<tr><td width="5%">01.</td><td width="20%">Nama</td><td width="5%">:</td><td width="70%"><?php echo $tingkat_struktural;?></td></tr>
										<tr><td width="5%">02.</td><td width="20%">tempat / Tanggal Lahir</td><td width="5%">:</td><td width="70%"><?php echo $tempat_lahir_istri.', '.$tanggal_lahir_istri;?></td></tr>
										<tr><td width="5%">03.</td><td width="20%">Tanggal Menikah</td><td width="5%">:</td><td width="70%"><?php echo $tanggal_menikah_istri;?></td></tr>
										<tr><td width="5%">04.</td><td width="20%">Pekerjaan</td><td width="5%">:</td><td width="70%"><?php echo $pekerjaan_istri;?></td></tr>
										<tr><td width="5%">05.</td><td width="20%">Tunjangan</td><td width="5%">:</td><td width="70%"><?php echo $tunjangan_istri;?></td></tr>
										<tr><td width="5%">06.</td><td width="20%">NIP</td><td width="5%">:</td><td width="70%"><?php echo $nip_istri;?></td></tr>
									</tbody>
								</table>
							</div>
							<h4><b>L : Data Anak</b></h4><hr>
							<div class="table-responsive">
								<table class='table table-bordered'>
									<thead>
										<th>No</th>
										<th>Nama</th>
										<th>Tempat Lahir</th>
										<th>Tanggal Lahir</th>
										<th>Jenis Kelamin</th>
										<th>Tunjangan</th>
										<th>Status</th>
									</thead>
									<tbody>
										<?php if($anak){$no=1; foreach($anak as $a){ ?>
										<tr>
											<td><?php echo $no++;?></td>
											<td><?php echo $a->nama_anak;?></td>
											<td><?php echo $a->tempat_lahir_anak;?></td>
											<td><?php echo $a->tanggal_lahir_anak;?></td>
											<td><?php echo $a->jenis_kelamin_anak;?></td>
											<td><?php echo $a->tunjangan_anak;?></td>
											<td><?php echo $a->status_anak;?></td>
										</tr>
										<?php }}else{ ?>
											<tr><td colspan=7>&nbsp;</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<h4><b>M : Riwayat Pangkat</b></h4><hr>
							<div class="table-responsive">
								<table class='table table-bordered'>
									<thead>
										<th>No</th>
										<th>Pangkat (Gol/Ruang)</th>
										<th>Nomor SK</th>
										<th>Tanggal SK</th>
										<th>TMT Pangkat</th>
									</thead>
									<tbody>
										<?php if($riwayat_pangkat){$no=1; foreach($riwayat_pangkat as $rp){ ?>
										<tr>
											<td><?php echo $no++;?></td>
											<td><?php echo $rp->pangkat_riwayat;?></td>
											<td><?php echo $rp->no_sk_riwayat;?></td>
											<td><?php echo $rp->tanggal_sk_riwayat;?></td>
											<td><?php echo $rp->tmt_pangkat_riwayat;?></td>
										</tr>
										<?php }}else{ ?>
											<tr><td colspan=7>&nbsp;</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<h4><b>N : Riwayat Jabatan</b></h4><hr>
							<div class="table-responsive">
								<table class='table table-bordered'>
									<thead>
										<th>No</th>
										<th>Nama Jabatan / Unit Kerja</th>
										<th>Eselon</th>
										<th>Nomor SK Jabatan</th>
										<th>Tanggal SK</th>
										<th>TMT Jabatan</th>
									</thead>
									<tbody>
										<?php if($riwayat_jabatan){$no=1; foreach($riwayat_jabatan as $rj){ ?>
										<tr>
											<td><?php echo $no++;?></td>
											<td><?php echo $rj->nama_riwayat_jabatan.'<br>'.$rj->unit_kerja_riwayat_jabatan;?></td>
											<td><?php echo $rj->eselon_riwayat_jabatan;?></td>
											<td><?php echo $rj->no_sk_riwayat_jabatan;?></td>
											<td><?php echo $rj->tanggal_sk_riwayat_jabatan;?></td>
											<td><?php echo $rj->tmt_riwayat_jabatan;?></td>
										</tr>
										<?php }}else{ ?>
											<tr><td colspan=7>&nbsp;</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							<h4><b>O : Riwayat Pendidikan</b></h4><hr>
							<div class="table-responsive">
								<table class='table table-bordered'>
									<thead>
										<th>No</th>
										<th>Tingkat / Jurusan</th>
										<th>Nama Sekolah / Tempat / Nama Kepala Sekolah</th>
										<th>No STTB / Tanggal STTB</th>
									</thead>
									<tbody>
										<?php if($riwayat_pendidikan){$no=1; foreach($riwayat_pendidikan as $rd){ ?>
										<tr>
											<td><?php echo $no++;?></td>
											<td><?php echo $rd->tingkat_pendidikan.'<br>'.$rd->jurusan_pendidikan;?></td>
											<td><?php echo $rd->nama_sekolah_pendidikan.'<br>'.$rd->tempat_pendidikan.'<br>'.$rd->kepsek_pendidikan;?></td>
											<td><?php echo $rd->no_sttb_pendidikan.'<br>'.$rd->tanggal_sttb_pendidikan;?></td>
										</tr>
										<?php }}else{ ?>
											<tr><td colspan=7>&nbsp;</td></tr>
										<?php } ?>
									</tbody>
								</table>
							</div>
							
							<a href="<?php echo base_url();?>pegawai/home"><button type="button" class="btn btn-success pull-left">Print</button></a>
							<a href="<?php echo base_url();?>pegawai/home"><button type="button" class="btn btn-primary pull-right">Kembali</button></a>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>