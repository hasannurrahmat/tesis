<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-primary" style="height:400px !important;">
						<div class="panel-heading">
							<h3 class="panel-title">Data Laporan Per Siswa</h3>
						</div>
						<div class="panel-body">
							<div class="page-header">
								<h3>Dana Mohamad Hasan<a href="<?php echo base_url();?>siswa/tambah"><button type="button" class="btn btn-primary pull-right">Update Dana</button></a>
								</h3>
							</div>
							
							<div class="table-responsive">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="5%" class="text-center">No</th>
									<th width="15%" class="text-center">Tunggakan Pembangunan</th>
									<th width="15%" class="text-center">Tunggakan Komite Kelas</th>
									<th width="15%" class="text-center">Komite Bulan Juli</th>
									<th width="15%" class="text-center">Tab. Wisata</th>
									<th width="15%" class="text-center">Qurban</th>
									<th width="15%" class="text-center">Dana Sosial</th>
									<th width="15%" class="text-center">Perpisahan</th>
									<th width="15%" class="text-center">Jumlah</th>
									<th width="15%" class="text-center">Keterangan</th>
									<th width="15%" class="text-center">Raport</th>
									<th width="17%" class="text-center">Aksi</th>
								</thead>
								<!--
								<tbody>
									<?php $no=1+$page; if($listsiswa){ foreach($listsiswa as $p){ ?>
									<tr>
										<td class="text-center"><?php echo $no++; ?></td>
										<td><?php echo $p->nama.'<br>'.$p->tempat_lahir.', '.$p->tanggal_lahir; ?></td>
										<td><?php echo $p->nip; ?></td>
										<td><?php echo $p->golongan_ruang_pangkat.' / '.$p->tmt_gol; ?></td>
										<td><?php echo $p->jabatan.' / '.$p->eselon_jabatan.' / '.$p->tmt_jabatan; ?></td>
										<td><?php echo $p->tingkat_umum.' - '.$p->jurusan_umum.' / '.$p->tahun_lulus_umum.' Tahun'; ?></td>
										<td class="text-center">
											<a href="<?php echo base_url();?>siswa/detail/<?php echo $p->id_siswa;?>">Detail</a> | 
											<a href="<?php echo base_url();?>siswa/ubah/<?php echo $p->id_siswa;?>">Ubah</a> | 
											<a href="<?php echo base_url();?>siswa/hapus/<?php echo $p->id_siswa;?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a>
										</td>
									</tr>
									<?php } ?>
									<?php }else{ ?>
									<tr><td colspan=7>Tidak ada data siswa</td></tr>
									<?php } ?>
								</tbody>
								-->
							  </table>
							</div>
							<a href="<?php echo base_url();?>siswa/tambah"><button type="button" class="btn btn-success pull-left">Print to Excel</button></a>
						</div>
					</div>
				</div>
			</div>
			
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>