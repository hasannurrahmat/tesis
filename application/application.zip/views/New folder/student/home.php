<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<br>
							<form class="form-horizontal" role="form" action ="" method="POST">
								<div class="form-group">
									<label for="tahun" class="col-md-2 control-label">NIS</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nis" value="<?php echo $nis; ?>">
									</div>									
									<label for="kelas" class="col-md-1 control-label">Nama</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nama" value="<?php echo $nama; ?>">
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
						</div>
					</div>
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>List Siswa <small>Keseluruhan</small>
							</h3>
							</div>
							<a href="<?php echo base_url();?>student/tambah"><button class="btn btn-success">Tambah</button></a>
							<?php if($this->session->userdata('jenis_admin')!=1){ ?>
								<a href="#import" data-toggle="modal"><button type="button" class="btn btn-success">Import Siswa</button></a>
							<?php } ?>
							<br>
							<br>
							<table class="table table-condensed table-responsive table-bordered">
							<tr class="active">
								<th class="text-center">No</th>
								<th class="text-center">NIS</th>
								<th class="text-center">NISN</th>
								<th class="text-center">Nama</th>
								<th class="text-center">Jenis Kelamin</th>
								<th class="text-center">Aksi</th>
							</tr>
							<?php $no=$page+1; if($listsiswa){ foreach($listsiswa as $l): ?>
							<tr>
								<td width="10%" class="text-center"><?php echo $no; ?></td>
								<td width="15%"><?php echo $l->nis; ?></td>
								<td width="15%"><?php echo $l->nisn; ?></td>
								<td width="30%"><?php echo $l->nama; ?></td>
								<td width="15%"><?php if($l->jenis_kelamin=='L'){echo "Laki-Laki";}else{echo "Perempuan";} ?></td>
								<td width="15%" class="text-center">
								<a href="<?php echo base_url();?>student/ubah/<?php echo $l->id_siswa; ?>">Ubah</a> | 
								<a href="<?php echo base_url();?>student/hapus/<?php echo $l->id_siswa; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
							</tr>
							<?php $no++; endforeach; }else{ ?>
							<tr><td colspan=3>Tidak ada data, silahkan tambah data</td></tr>
							<?php } ?>
								
							</table>
							<p><?php echo $links; ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<form class="form-horizontal" role="form" action="<?php echo base_url('student/import_siswa'); ?>" method="post" enctype="multipart/form-data">
						<div class="modal-header">
							<h4>Import Siswa</h4>
						</div>
						<div class="modal-body">
							<div class="form-group">
								<label for="file" class="col-sm-2 control-label">Pilih File</label>
								<div class="col-sm-10">
									<input type="file" name="file" size="20" />
								</div>
							</div>
							<div class="form-group">
							</div>
						</div>
						<div class="modal-footer">
								<a href="<?php echo base_url(); ?>student/download" class="pull-left">Download Template File</a>
							<a class="btn btn-default" data-dismiss="modal">Cancel</a>
							<button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin akan mengimport data dari file tersebut?')">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>