<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 50% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
						<br>
							<form class="form-horizontal" role="form" action ="" method="POST">
								<div class="form-group">
									<label for="tahun" class="col-md-2 control-label">NIS</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nis" value="<?php echo $nis; ?>">
									</div>									
									<label for="kelas" class="col-md-1 control-label">Nama</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nama" value="<?php echo $nama; ?>">
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tabungan Wisata Siswa</h3>
							</div>
							<?PHP if($nis=="" && $nama==""){ ?>
							<div class="alert alert-warning alert-dismissible" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Data Siswa Tidak Ditemukan.
							</div>
							<?php }else{ ?>
							<div class="table-responsive">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">NIS</th>
									<th width="300px" class="text-center">NAMA</th>
									<th width="150px" class="text-center">AKSI</th>
								</thead>
								<tbody>
									<?php if($listsiswa){ $no=1; ?>
									<?php foreach($listsiswa as $l){ ?>
									<tr>
										<td class="text-center"><?php echo $no; ?></td>
										<td class="text-center"><?php echo $l->nis; ?></td>
										<td class="text-center"><?php echo $l->nama; ?></td>
										<td class="text-center"><a href="<?php echo base_url();?>tabungan_wisata/detail_dana_tabungan/<?php echo $l->id_siswa;?>">Detail</a></td>
										
									</tr>
									<?php $no++; } }else{ ?>
									<td colspan=5>Daftar Siswa Tidak Ditemukan</td>
									<?php } ?>
								</tbody>
							  </table>
							</div>

							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>


		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>