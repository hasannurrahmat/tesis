<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
		<script language="javascript">
		timerID = setTimeout("exPDF.print();", 1000);
		</script>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h3 class="panel-title">Bukti Pembayaran</h3>
						</div>
						<div class="panel-body" id="exPDF" type="application/pdf" data="111.pdf">
							<center><h3>Bukti Pembayaran SMAN 1 Larangan</h3></center>
							<hr>
							<div class="row">
								<div class="col-md-9">
									<table width="100%" cellpadding="5">
										<tr>
											<td width="10%">NIS</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo $nis?></td>
										</tr>
										<tr>
											<td width="10%">Nama</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo $nama?></td>
										</tr>
										<tr>
											<td width="10%">Kelas</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo $kelas; ?></td>
										</tr>
										<tr>
											<td width="10%">Tanggal</td>
											<td width="3%">:</td>
											<td width="40%"><?php echo date('d/m/Y'); ?></td>
										</tr>
									</table>
								</div>
								<div class="col-md-1"></div>
								<div class="col-md-2">
									<img src="<?php echo base_url();?>uploads/sma.png" width="100px" height="110px" style="border:1px solid black" class="pull-center">
								</div>
							</div>
							<br>
							<h4><b>Pembayaran Tabungan Wisata</b></h4>
							<div class="table-responsive">
								<table class="table table-bordered table-striped">
									<thead class="info">
										<th>Jenis Pembayaran</th>
										<th>Uang Sebesar</th>
									</thead>
									<tbody>
										<?php $jum=0; if($list){ foreach($list as $l=>$val){ ?>
										<tr>
											<td><?php $id=$this->modeltabungan->getjenisdanabyid($l); 
												if($tingkat==2 && $id->id_jenis_tabungan_wisata==51){
													echo 'PEMBAYARAN STUDI WISATA';
												}else{
													echo $id->nama_jenis;
												}
											?></td>
											<td><?php echo $val; $jum += $val; ?></td>
										</tr>
										<?php } } ?>
										<tr>
											<td>Saldo Akhir</td>
											<td><?php echo $saldo; ?></td>
										</tr>
									</tbody>
								</table>
								<h4>Total Pembayaran : <?php echo $jum; ?></h4>
							</div>
							<div class="row">
								<div class="col-md-4"></div>
								<div class="col-md-5"></div>
								<div class="col-md-3">
									<center><h4>Petugas</h4></center>
									<br>
									<br>
									<br>
									<center><h4><?php echo $this->session->userdata("username");?></h4></center>
								</div>
							</div>
							<hr>
							<a href="<?php echo base_url();?>tabungan_wisata/print_pdf"><button type="button" class="btn btn-success pull-left">Cetak</button></a>
							<br>
						</div>
					</div>
				</div>
			</div>
			
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>