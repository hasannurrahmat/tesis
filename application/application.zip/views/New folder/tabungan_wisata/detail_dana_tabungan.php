<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 50% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Pembayaran Tabungan Wisata</h3>
							</div>
							<h4>Nama : <?php echo $nama;?>&nbsp;/&nbsp;NIS : <?php echo $nis;?></h4>
							
							<div>
							
							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							  	<?php foreach ($kelas as $i=>$k) { ?>
							    	<li role="presentation" <?php if($i==0){ echo "class='active'";} ?>><a href="#<?php echo $k->id_kelas; ?>" aria-controls="<?php echo $k->id_kelas; ?>" role="tab" data-toggle="tab"><?php echo $k->kelas; ?></a></li>
							  	<?php } ?>
							  </ul>

							  <!-- Tab panes -->
							  <div class="tab-content">
							  	<?php foreach ($kelas as $i=>$k) { ?>
							    	<div role="tabpanel" class="tab-pane <?php if($i==0){ echo "active";} ?>" id="<?php echo $k->id_kelas; ?>">
							    		<br>
							    		<table class="table table-bordered">
							    		<?php $jumlah=0; foreach ($list as $l => $v) {
							    			if($l==$k->kelas){
							    				foreach ($v['dana'] as $key => $value) {
							    					foreach ($jenis_dana as $j) {
														if($j->id_jenis_tabungan_wisata==$key){
															if($k->id_tingkat == 2 && $j->id_jenis_tabungan_wisata == 51){
																$j->nama_jenis = 'PEMBAYARAN STUDI WISATA';
															}
															echo '<tr>';
															echo "<td class='active'>".$j->nama_jenis.'</td><td>'.number_format($value).'</td>';
															echo '</tr>';
															$jumlah += $value;
														}
													}
												}
							    			}
							    		} ?>
							    		<tr>
							    			<td class='active'>TOTAL TABUNGAN</td><td><?php echo "Rp. ".number_format($jumlah); ?></td>
							    		</tr>
							    		</table>
							    		<a href="<?php echo base_url();?>tabungan_wisata/tambah/<?php echo $id_siswa?>/<?php echo $k->id_kelas ?>"><button type="button" class="btn btn-primary">Update Tabungan Wisata</button></a>
							    	</div>
							    <?php } ?>

							  </div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
	

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>