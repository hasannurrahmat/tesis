<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
		<style>
			.tablescroll {  
				height: 100% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th, table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
						<br>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform">
								<div class="form-group">
									<label for="tahun" class="col-md-2 control-label">Tahun Ajaran</label>
									<div class="col-md-2">
									<select class="form-control" name="tahun_ajaran" id="tahun_ajaran" onchange="submitform();">
										<option value="">-- Pilih Tahun Ajaran --</option>
										<?php foreach($tahun_ajaran as $j){ ?>
										<?php if($j->id_tahun_ajaran == $id_tahun_ajaran){ ?>
										  <option selected value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php }else{ ?>
										  <option value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php } } ?>
									</select>
									</div>									
							</form>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform1">
									<input type="hidden" name="tahun_ajaran" value="<?php echo $id_tahun_ajaran; ?>">
									<label for="kelas" class="col-md-1 control-label">Kelas</label>
									<div class="col-md-2">
										<select class="form-control" name="kelas" id="kelas">
											<option value="">-- Pilih Kelas --</option>
											<?php foreach($kelas as $j){ ?>
											<?php if($j->id_kelas == $id_kelas){ ?>
											  <option selected value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php }else{ ?>
											  <option value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php } } ?>
										</select>
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tabel Tabungan Wisata per Kelas</h3>
								
							</div>

							<a href="<?php echo base_url();?>tabungan_wisata/tambah_dana_tabungan"><button type="button" class="btn btn-primary">Tambah Tabungan per Siswa</button></a>
							<?php if($this->session->userdata('jenis_admin')!=1){ ?><a href="<?php echo base_url();?>tabungan_wisata/tambah_dana"><button type="button" class="btn btn-primary">Tambah Tabungan per Kelas</button></a><?php } ?>
							<?php if($this->session->userdata('jenis_admin')!=1){ ?>
								<a href="#import" data-toggle="modal"><button type="button" class="btn btn-primary">Import Tabungan Wisata</button></a>
							<?php } ?>
							<br>
							<br>
							<?PHP if($jenis_dana){ ?>
							<div class="tablescroll">
							<div class="table-responsive">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">NIS</th>
									<th width="150px" class="text-center">NISN</th>
									<th width="300px" class="text-center">NAMA</th>
									<?php foreach($jenis_dana as $j){ ?>
										<th width="150px" class="text-center"><?php echo $j->nama_jenis; ?></th>
									<?php } ?>
									<th width="200px" class="text-center">TOTAL TABUNGAN</th>
								</thead>
								<tbody>
									<?php if($listsiswa){ $no=1; foreach($listsiswa as $l){ $jumlah=0; ?>
									<tr>
										<td class="text-center"><?php echo $no; ?></td>
										<td class="text-center"><?php echo $l->nis; ?></td>
										<td class="text-center"><?php echo $l->nisn; ?></td>
										<td><?php echo $l->nama; ?></td>
										<?php foreach($jenis_dana as $j){ ?>
											<td><?php echo "Rp. ".number_format($dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]); ?></td>
										<?php $jumlah += $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; } ?>
										<td class="text-center"><?php echo "Rp. ".number_format($jumlah); ?></td>
									</tr>
									<?php $no++;} }else{ ?>
									<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
									<?php } ?>
								</tbody>
							  </table>
								</div>
							</div>
							<br>

							<!-- print excel -->
							<div style="display:none;" id="sma1larangan" summary="Data Tabungan Wisata">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">NIS</th>
									<th width="150px" class="text-center">NISN</th>
									<th width="300px" class="text-center">NAMA</th>
									<?php foreach($jenis_dana as $j){ ?>
										<th width="150px" class="text-center"><?php echo $j->nama_jenis; ?></th>
									<?php } ?>
									<th width="200px" class="text-center">TOTAL TABUNGAN</th>
								</thead>
								<tbody>
									<?php if($listsiswa){ $no=1; foreach($listsiswa as $l){ $jumlah=0; ?>
									<tr>
										<td class="text-center"><?php echo $no; ?></td>
										<td class="text-center"><?php echo $l->nis; ?></td>
										<td class="text-center"><?php echo $l->nisn; ?></td>
										<td><?php echo $l->nama; ?></td>
										<?php foreach($jenis_dana as $j){ ?>
											<td><?php echo $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; ?></td>
										<?php $jumlah += $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; } ?>
										<td class="text-center"><?php echo $jumlah; ?></td>
									</tr>
									<?php $no++;} }else{ ?>
									<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
									<?php } ?>
								</tbody>
							  </table>
							</div>

							<input type="button" onclick="tableToExcel('sma1larangan', 'Tabel Data Tabungan Wisata' , 'data_tabungan_wisata.xls', 'Excel')" value="Print to Excel" class="btn btn-success">
								<?php }else{ ?>
								<div class="alert alert-warning alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Data Siswa Tidak Ditemukan.
								</div>
								<?php } ?>
						
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Import Tabungan Wisata Kelas</h4>
					</div>
					<form class="form-horizontal" role="form" action="<?php echo base_url('tabungan_wisata/import_dana'); ?>" method="post" enctype="multipart/form-data">
					<div class="modal-body">
											
							<div class="form-group">
								<label for="kelas" class="col-sm-3 control-label">Kelas</label>
								<div class="col-sm-9">
									<select class="form-control" name="kelas" id="kelas">
										<option value="" selected>-- Pilih Kelas --</option>
										<?php foreach($kelasimport as $j){ ?>
										  <option value="<?php echo $j->id_kelas; ?>"><?php echo $j->tahun_ajaran.' - '.$j->kelas; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
							<div class="form-group">
								<label for="file" class="col-sm-3 control-label">Pilih File</label>
								<div class="col-sm-9">
									<input type="file" name="file" size="20" />
								</div>
							</div>
							<div class="form-group">
							</div>
					</div>

					<div class="modal-footer">
						<p class="pull-left">Download Template File: <a href="<?php echo base_url(); ?>tabungan_wisata/download_x">X</a> / <a href="<?php echo base_url(); ?>tabungan_wisata/download_xi">XI</a></p>
						<a class="btn btn-default" data-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-primary" onclick="return confirm('Apakah Anda yakin akan mengimport data dari file tersebut?')">Submit</button>
					</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		
	<script>
	
	
	function submitform()
	{
	  document.myform.submit();
	}
	
</script>

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>