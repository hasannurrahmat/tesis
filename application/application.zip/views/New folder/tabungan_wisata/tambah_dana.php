<html>
	<head>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		
		<style>
			.tablescroll {  
				height: 60% !important;
				width: 100% !important;
				overflow: scroll;
			}
			
			table { table-layout: fixed;}
			table th { overflow: hidden; word-wrap:break-word;}
			table td { overflow: hidden; word-wrap:break-word;}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
						<br>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform">
								<div class="form-group">
									<label for="tahun" class="col-md-2 control-label">Tahun Ajaran</label>
									<div class="col-md-2">
									<select class="form-control" name="tahun_ajaran" id="tahun_ajaran" onchange="submitform();">
										<option value="">-- Pilih Tahun Ajaran --</option>
										<?php foreach($tahun_ajaran as $j){ ?>
										<?php if($j->id_tahun_ajaran == $id_tahun_ajaran){ ?>
										  <option selected value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php }else{ ?>
										  <option value="<?php echo $j->id_tahun_ajaran; ?>"><?php echo $j->tahun_ajaran; ?></option>
										<?php } } ?>
									</select>
									</div>									
							</form>
							<form class="form-horizontal" role="form" action ="" method="POST" name="myform1">
									<input type="hidden" name="tahun_ajaran" value="<?php echo $id_tahun_ajaran; ?>">
									<label for="kelas" class="col-md-1 control-label">Kelas</label>
									<div class="col-md-2">
										<select class="form-control" name="kelas" id="kelas">
											<option value="">-- Pilih Kelas --</option>
											<?php foreach($kelas as $j){ ?>
											<?php if($j->id_kelas == $id_kelas){ ?>
											  <option selected value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php }else{ ?>
											  <option value="<?php echo $j->id_kelas; ?>"><?php echo $j->kelas; ?></option>
											<?php } } ?>
										</select>
									</div>
									<button type="submit" class="btn btn-default">Cari</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tabel Siswa per Kelas</h3>
								
							</div>
							
							<?php if($jenis_dana){ ?>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>tabungan_wisata/submit_dana_kelas" method="POST">
							
							<input type="hidden" name="id_kelas" value="<?php echo $id_kelas; ?>">
							<div class="tablescroll">
							<div class="table-responsive">
							  <table class="table table-bordered table-striped">
								<thead class="info" style="background-color:#66b3ff;">
									<th width="100px" class="text-center">NO</th>
									<th width="150px" class="text-center">NIS</th>
									<th width="150px" class="text-center">NISN</th>
									<th width="300px" class="text-center">NAMA</th>
									<?php foreach($jenis_dana as $j){ ?>
										<?php if($tingkat==1 && $j->id_jenis_tabungan_wisata!=19){ ?>
											<th width="150px" class="text-center"><?php echo $j->nama_jenis; ?></th>
										<?php }elseif($tingkat==2 || $tingkat==3){ ?>
											<?php if($tingkat==2 && $j->id_jenis_tabungan_wisata==51){ ?>
												<th width="150px" class="text-center"><?php echo 'PEMBAYARAN STUDI WISATA'; ?></th>
											<?php }else{ ?>
												<th width="150px" class="text-center"><?php echo $j->nama_jenis; ?></th>
											<?php } ?>
										<?php } ?>
									<?php } ?>
									<th width="200px" class="text-center">TOTAL TABUNGAN</th>
								</thead>
								<tbody>
									<?php if($listsiswa){ $no=1; foreach($listsiswa as $l){ $jumlah=0; ?>
									<tr>
										<td class="text-center"><?php echo $no; ?></td>
										<td class="text-center"><?php echo $l->nis; ?></td>
										<td class="text-center"><?php echo $l->nisn; ?></td>
										<td><?php echo $l->nama; ?></td>
										<?php foreach($jenis_dana as $j){ ?>
											<?php if($tingkat==1 && $j->id_jenis_tabungan_wisata!=19){ ?>
												<td><input class="form-control" type="text" name="jenis_dana[<?php echo $l->id_siswa; ?>][<?php echo $j->id_jenis_tabungan_wisata; ?>]" value="<?php echo $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; ?>"></td>
												<?php $jumlah += $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; ?>	
											<?php }elseif($tingkat==2 || $tingkat==3){ ?>
												<td><input class="form-control" type="text" name="jenis_dana[<?php echo $l->id_siswa; ?>][<?php echo $j->id_jenis_tabungan_wisata; ?>]" value="<?php echo $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; ?>"></td>
												<?php $jumlah += $dana[$l->id_siswa][$j->id_jenis_tabungan_wisata]; ?>
											<?php } ?>
										<?php } ?>
										<td class="text-center"><?php echo $jumlah; ?></td>
									</tr>
									<?php $no++;} }else{ ?>
									<td colspan=15>Daftar Siswa Tidak Ditemukan</td>
									<?php } ?>
								</tbody>
							  </table>
							</div>
							</div>
							<br>
							<button type="submit" class="btn btn-primary pull-left">Simpan</button>
							</form>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		
	<script>
	
	
	function submitform()
	{
	  document.myform.submit();
	}
	
</script>

		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>