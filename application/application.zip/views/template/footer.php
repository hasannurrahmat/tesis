<div class="navbar navbar-default navbar-fixed-bottom">
	<div class="container">
	<p class="navbar-text pull-right">Copyright CV. Lung Farm 2018</p>
	</div>
</div>
