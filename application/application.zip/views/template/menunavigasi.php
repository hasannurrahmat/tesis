<div class="navbar navbar-inverse navbar-static-top">
	<div class="container">
		<button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<div class="collapse navbar-collapse navHeaderCollapse">
			<ul class="nav navbar-nav navbar-left">
			 	
			 	<?php 
			 		$this->db->where('id_aplikasi', 1);
					$app = $this->db->get('aplikasi'); 
					$nama_aplikasi = $app->row()->nama_aplikasi;
			 	?>
					<li class="dropdown">
						<a href="<?php echo base_url();?>"><span class="glyphicon glyphicon-home"></span>&nbsp; <?php echo $nama_aplikasi; ?></a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Master <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>master/barang/">Barang</a></li>
						<li><a href="<?php echo base_url();?>master/konsumen/">Konsumen</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Laporan <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>laporan/pembelian/">Pembelian</a></li>
						<li><a href="<?php echo base_url();?>laporan/penjualan/">Penjualan</a></li>
						<li><a href="<?php echo base_url();?>laporan/pengeluaran/">Pengeluaran</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Aplikasi <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>aplikasi/pembelian/">Pembelian Barang</a></li>
						<li><a href="<?php echo base_url();?>aplikasi/penjualan/">Penjualan Barang</a></li>
						<li><a href="<?php echo base_url();?>aplikasi/pengeluaran/">Pengeluaran</a></li>
						</ul>
					</li>
					<?php if($this->session->userdata('id_usergroup')!=3 && $this->session->userdata('id_usergroup')!=5){ ?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Other <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>other/pembelian/">Edit Data Pembelian</a></li>
						<li><a href="<?php echo base_url();?>other/penjualan/">Edit Data Penjualan</a></li>
						<li><a href="<?php echo base_url();?>other/keuntungan/">Keuntungan</a></li>
						<li><a href="<?php echo base_url();?>other/karyawan/">Data Karyawan</a></li>
						<li><a href="<?php echo base_url();?>other/upah/">Upah Karyawan</a></li>
						</ul>
					</li>
					<?php } ?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Stock Opname <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>stock/stock/">Input</a></li>
						<li><a href="<?php echo base_url();?>stock/laporan/">Laporan</a></li>
						</ul>
					</li>
					<?php if($this->session->userdata('id_usergroup')==1){ ?>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" href="#">Admin <span class="caret"></span></a>
						<ul class="dropdown-menu">
						<li><a href="<?php echo base_url();?>admin/ganti/">Ganti Nama Toko</a></li>
						<li><a href="<?php echo base_url();?>admin/user/">User</a></li>
						</ul>
					</li>
					<?php } ?>
			</ul>
			
			<ul class="nav navbar-nav navbar-right">
				
			
				<li class="dropdown">
					<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>&nbsp; <?php echo $this->session->userdata('username'); ?> <span class="caret"></span></a>
					<ul class="dropdown-menu">
						<li ><a href="<?php echo base_url(); ?>auth/logout"><span class="glyphicon glyphicon-off"></span>&nbsp; Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>


<script>
	document.title = 'CV. Lung Farm';
</script>