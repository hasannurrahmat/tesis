
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
		<style>
			.borderless td, .borderless th {
    			border: none !important;
			}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">

							<div class="page-header">
							<?php $this->load->view('template/alert'); ?>
							<h3>Laporan Penjualan</h3>
							</div>
							
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>laporan/penjualan/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-1 control-label pull-left">Tanggal</label>
									<div class="col-md-2">
										<input type="date" class="form-control" name="tanggal_awal" value="<?php echo $tanggal_awal; ?>">
									</div>
									<label for="jenis" class="control-label pull-left">-</label>
									<div class="col-md-2">
										<input type="date" class="form-control" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>">
									</div>
									<label for="jenis" class="col-md-1 control-label pull-left">Toko</label>
									<div class="col-md-2">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Seluruh Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
									<button type="submit" class="btn btn-primary">Proses</button>
								</div>
							</form>
							<hr>
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation" class="active"><a href="#penjualan" aria-controls="penjualan" role="tab" data-toggle="tab">Data Seluruh Penjualan</a></li>
								<li role="presentation"><a href="#cash" aria-controls="cash" role="tab" data-toggle="tab">Penjualan Cash</a></li>
								<li role="presentation"><a href="#hutang" aria-controls="hutang" role="tab" data-toggle="tab">Penjualan Hutang</a></li>
							</ul>
							<br>
							<!-- Tab panes -->
							<div class="tab-content">

								<!-- view seluruh penjualan -->
								<div role="tabpanel" class="tab-pane active" id="penjualan">
									<?php if($tanggal_awal || $tanggal_akhir){ ?>
									<div id="penjualan" summary="Laporan penjualan">
										<div style="display:none;">
											<table><tr><td colspan=8><center><b>Laporan penjualan</b></center></td></tr></table>
											<table><tr><td></td></tr></table>
											<table class="table table-condensed table-responsive table-bordered">
												<tr>
													<td>Tanggal</td>
													<td><?php echo $tanggal_awal.' - '.$tanggal_akhir; ?></td>
												</tr>
											</table>
											<table><tr><td></td></tr></table>
										</div>
										<table class="table table-condensed table-responsive table-bordered">
											<tr class="active">
												<th class="text-center">No</th>
												<th class="text-center">Tanggal</th>
												<th class="text-center">Kasir</th>
												<th class="text-center">Nama Toko</th>
												<th class="text-center">Nama Barang</th>
												<th class="text-center">Qty/Pcs</th>
												<th class="text-center">Keterangan</th>
												<th class="text-center">Total</th>
											</tr>
											<?php $no=1; $cash=0; $hutang=0;if($listpenjualan){ foreach($listpenjualan as $l): ?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->tanggal; ?></td>
												<td><?php echo $l->nama_lengkap; ?></td>
												<td><?php echo $l->nama_toko; ?></td>
												<td><?php echo $l->nama_barang; ?></td>
												<td class="text-center"><?php echo $l->jumlah; ?></td>
												<td class="text-center"><?php echo $l->keterangan; ?></td>
												<td class="text-center"><?php echo "Rp. ".number_format($l->harga); ?></td>
											</tr>
											<?php 
												$no++;
												if($l->keterangan=="cash"){
													$cash += $l->harga;
												}elseif($l->keterangan=="hutang"){
													$hutang += $l->harga;
												}
												endforeach;
												$selisih = $cash - $hutang;
												$sum = $cash + $hutang;
											?>
											<tr>
												<td colspan=7>Total penjualan (Cash + Hutang)</td>
												<td class="text-center"><?php echo "Rp. ".number_format($sum); ?></td>
											</tr>
											<?php }else{ ?>
												<tr><td colspan=8>Tidak ada data, silahkan tambah data</td></tr>
											<?php } ?>
										</table>
									</div>
									<input type="button" onclick="tableToExcel('penjualan', 'Laporan penjualan' , 'penjualan.xls', 'Excel')" value="Cetak" class="btn btn-success">
									<?php } ?>
								</div>

								<!-- view penjualan cash -->
								<div role="tabpanel" class="tab-pane" id="cash">
									<?php if($tanggal_awal || $tanggal_akhir){ ?>
									<div id="penjualan_cash" summary="Laporan penjualan Cash">
										<div style="display:none;">
											<table><tr><td colspan=8><center><b>Laporan penjualan dengan Pembayaran Cash</b></center></td></tr></table>
											<table><tr><td></td></tr></table>
											<table class="table table-condensed table-responsive table-bordered">
												<tr>
													<td>Tanggal</td>
													<td><?php echo $tanggal_awal.' - '.$tanggal_akhir; ?></td>
												</tr>
											</table>
											<table><tr><td></td></tr></table>
										</div>
										<table class="table table-condensed table-responsive table-bordered">
											<tr class="active">
												<th class="text-center">No</th>
												<th class="text-center">Tanggal</th>
												<th class="text-center">Kasir</th>
												<th class="text-center">Nama Toko</th>
												<th class="text-center">Nama Barang</th>
												<th class="text-center">Qty/Pcs</th>
												<th class="text-center">Keterangan</th>
												<th class="text-center">Total</th>
											</tr>
											<?php $no=1; $cash=0; $hutang=0;if($listpenjualan){ foreach($listpenjualan as $l): 
												if($l->keterangan=="cash"){
											?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->tanggal; ?></td>
												<td><?php echo $l->nama_lengkap; ?></td>
												<td><?php echo $l->nama_toko; ?></td>
												<td><?php echo $l->nama_barang; ?></td>
												<td class="text-center"><?php echo $l->jumlah; ?></td>
												<td class="text-center"><?php echo $l->keterangan; ?></td>
												<td class="text-center"><?php echo "Rp. ".number_format($l->harga); ?></td>
											</tr>
											<?php 
												$no++;
													if($l->keterangan=="cash"){
														$cash += $l->harga;
													}elseif($l->keterangan=="hutang"){
														$hutang += $l->harga;
													}
												}endforeach;
												$sum = $cash + $hutang;
											?>
											<tr>
												<td colspan=7>Total penjualan (Cash + Hutang)</td>
												<td class="text-center"><?php echo "Rp. ".number_format($sum); ?></td>
											</tr>
											<?php }else{ ?>
												<tr><td colspan=8>Tidak ada data, silahkan tambah data</td></tr>
											<?php } ?>
										</table>
									</div>
									<input type="button" onclick="tableToExcel('penjualan_cash', 'Laporan penjualan Cash' , 'penjualan.xls', 'Excel')" value="Cetak" class="btn btn-success">
									<?php } ?>
								</div>
								<!-- view penjualan hutang -->
								<div role="tabpanel" class="tab-pane" id="hutang">
									<?php if($tanggal_awal || $tanggal_akhir){ ?>
									<div id="penjualan_hutang" summary="Laporan penjualan Hutang">
										<div style="display:none;">
											<table><tr><td colspan=8><center><b>Laporan penjualan dengan Pembayaran Hutang</b></center></td></tr></table>
											<table><tr><td></td></tr></table>
											<table class="table table-condensed table-responsive table-bordered">
												<tr>
													<td>Tanggal</td>
													<td><?php echo $tanggal_awal.' - '.$tanggal_akhir; ?></td>
												</tr>
											</table>
											<table><tr><td></td></tr></table>
										</div>
										<table class="table table-condensed table-responsive table-bordered">
											<tr class="active">
												<th class="text-center">No</th>
												<th class="text-center">Tanggal</th>
												<th class="text-center">Kasir</th>
												<th class="text-center">Nama Toko</th>
												<th class="text-center">Nama Barang</th>
												<th class="text-center">Qty/Pcs</th>
												<th class="text-center">Keterangan</th>
												<th class="text-center">Total</th>
											</tr>
											<?php $no=1; $cash=0; $hutang=0;if($listpenjualan){ foreach($listpenjualan as $l): 
												if($l->keterangan=="hutang"){
											?>
											<tr>
												<td class="text-center"><?php echo $no; ?></td>
												<td><?php echo $l->tanggal; ?></td>
												<td><?php echo $l->nama_lengkap; ?></td>
												<td><?php echo $l->nama_toko; ?></td>
												<td><?php echo $l->nama_barang; ?></td>
												<td class="text-center"><?php echo $l->jumlah; ?></td>
												<td class="text-center"><?php echo $l->keterangan; ?></td>
												<td class="text-center"><?php echo "Rp. ".number_format($l->harga); ?></td>
											</tr>
											<?php 
												$no++;
													if($l->keterangan=="cash"){
														$cash += $l->harga;
													}elseif($l->keterangan=="hutang"){
														$hutang += $l->harga;
													}
												}endforeach;
												$sum = $cash + $hutang;
											?>
											<tr>
												<td colspan=7>Total penjualan (Cash + Hutang)</td>
												<td class="text-center"><?php echo "Rp. ".number_format($sum); ?></td>
											</tr>
											<?php }else{ ?>
												<tr><td colspan=8>Tidak ada data, silahkan tambah data</td></tr>
											<?php } ?>
										</table>
									</div>
									<input type="button" onclick="tableToExcel('penjualan_hutang', 'Laporan penjualan Hutang' , 'penjualan.xls', 'Excel')" value="Cetak" class="btn btn-success">
									<?php } ?>
								</div>
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>