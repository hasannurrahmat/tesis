
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
	
		<div class="container">
			
			<div class="row">
				<div class="col-lg-4">
					<!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Menu Utama</div>
                        <div class="panel-body">
                        	<br>
                            <a href="<?php echo base_url();?>aplikasi/pembelian" class="btn btn-primary btn-block">Pembelian</a>
                            <a href="<?php echo base_url();?>aplikasi/penjualan" class="btn btn-primary btn-block">Penjualan</a>
                            <a href="<?php echo base_url();?>aplikasi/pengeluaran" class="btn btn-success btn-block">Pengeluaran</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                     <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Profile User</div>
                        <div class="panel-body">
                        	<br>
                        	<center><img src="<?php echo base_url();?>uploads/profile_picture/<?php if($user->file_photo){echo $user->file_photo;}else{echo 'profile.png';} ?>" width="150px" height="150px"></center>
                        	<br>
                        	<p class="text-center"><?php echo $this->session->userdata('username'); ?></p>
                        	<p class="text-center"><?php echo $this->session->userdata('usergroup'); ?></p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

				<div class="col-lg-8">
					<div class="panel panel-default">
						<div class="panel-body">

							<?php $this->load->view('template/alert'); ?>
							
							<div class="page-header">
							<h3>List Keperluan<a href="#import" data-toggle="modal"><button class="btn btn-success pull-right">Tambah Keperluan</button></a></h3>
							</div>
							<form class="form-horizontal" role="form" action ="" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-2 control-label pull-left">Keperluan</label>
									<div class="col-md-3">
										<input type="text" class="form-control" name="keperluan" value="<?php echo $keperluan; ?>">
									</div>
									<button type="submit" class="btn btn-primary">Cari</button>
								</div>

							</form>
							
							<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">Keperluan</th>
									<th class="text-center">Aksi</th>
								</tr>
								<?php $no=1; if($listkeperluan){ foreach($listkeperluan as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="30%"><?php echo $l->keperluan; ?></td>
									<td width="15%" class="text-center">
									<a href="<?php echo base_url();?>aplikasi/pengeluaran/hapus_keperluan/<?php echo $l->id_keperluan; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=3>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
							</table>
							<a href="<?php echo base_url();?>aplikasi/pengeluaran/"><button class="btn btn-primary">Kembali</button></a>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Tambah Keperluan</h4>
					</div>
					<form class="form-horizontal" role="form" action="<?php echo base_url('aplikasi/pengeluaran/tambah_keperluan'); ?>" method="post" enctype="multipart/form-data">
					<div class="modal-body">
						<div class="form-group">
							<label for="nama" class="col-sm-2 control-label required">Keperluan</label>
							<div class="col-sm-10">
							<input type="text" class="form-control" id="kelas" placeholder="Isi dengan nama keperluan" name="keperluan" required>
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<a class="btn btn-default" data-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>