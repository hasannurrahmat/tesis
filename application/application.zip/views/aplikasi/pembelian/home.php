
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">
		<script src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript">

			$(function(){
				$.ajaxSetup({
					type:"POST",
					url: "<?php echo base_url('aplikasi/pembelian/get_barang'); ?>",
					cache: false,
				});

				$("#barang").change(function(){

					var value=$(this).val();
					if(value>0){
						$.ajax({
							data:{modul:'pembelian',id:value},
							success: function(respond){
								$("#harga_satuan").val(respond);
							}
						})
					}
				});

				$("#jumlah").change(function(){

					var value=$(this).val();
					
					if(value>0){
						var satuan = parseInt(document.getElementById("harga_satuan").value)
						var total = satuan * value;
						$("#harga").val(total);
					}
				});
			})

		</script>
		<style>
			.borderless td, .borderless th {
    			border: none !important;
			}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-4">
					<!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Menu Utama</div>
                        <div class="panel-body">
                        	<br>
                            <a href="<?php echo base_url();?>aplikasi/pembelian" class="btn btn-success btn-block">Pembelian</a>
                            <a href="<?php echo base_url();?>aplikasi/penjualan" class="btn btn-primary btn-block">Penjualan</a>
                            <a href="<?php echo base_url();?>aplikasi/pengeluaran" class="btn btn-primary btn-block">Pengeluaran</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                     <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Rekap Pembelian</div>
                        <div class="panel-body">
                        	<br>
                        	<form class="form-horizontal" role="form" action ="<?php echo base_url();?>aplikasi/pembelian/print_pdf_rekap" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Tanggal Awal</label>
									<div class="col-md-7">
										<input type="date" class="form-control" name="tanggal_awal" value="<?php echo $tanggal_awal; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Tanggal Akhir</label>
									<div class="col-md-7">
										<input type="date" class="form-control" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Nama Toko</label>
									<div class="col-md-7">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Pilih Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
								</div>
									<button type="submit" class="btn btn-primary btn-block">Cetak Rekap</button>
							</form>
                        </div>
                        <!-- /.panel-body -->
                    </div>

                     <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Profile User</div>
                        <div class="panel-body">
                        	<br>
                        	<center><img src="<?php echo base_url();?>uploads/profile_picture/<?php if($user->file_photo){echo $user->file_photo;}else{echo 'profile.png';} ?>" width="150px" height="150px"></center>
                        	<br>
                        	<p class="text-center"><?php echo $this->session->userdata('nama_lengkap'); ?></p>
                        	<p class="text-center"><?php echo $this->session->userdata('usergroup'); ?></p>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

				<div class="col-lg-8">
					<div class="panel panel-default">
						<div class="panel-body">

							<div class="page-header">
							<?php $this->load->view('template/alert'); ?>
							<h3>Aplikasi Pembelian</h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>aplikasi/pembelian/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-1 control-label pull-left">Tanggal</label>
									<div class="col-md-3">
										<input type="date" class="form-control" name="tanggal" value="<?php echo $tanggal; ?>">
									</div>
									<label for="jenis" class="col-md-2 control-label pull-left">Nama Toko</label>
									<div class="col-md-4">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Pilih Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
									<button type="submit" class="btn btn-primary">Proses</button>
								</div>
							</form>

							<?php if($id_konsumen && $tanggal){ ?>
							<hr>
							<table class="table borderless">
								<tr>
									<td class = 'text-center col-md-3 success'>Nama Toko</td>
									<td><?php echo $nama_toko; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Owner</td>
									<td><?php echo $owner; ?></td>
								</tr>
								<tr>
									<td class = 'text-center col-md-3 success'>Alamat</td>
									<td><?php echo $alamat; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Tanggal</td>
									<td><?php echo $tanggal; ?></td>
								</tr>
							</table>
							<hr>
							<a href="#import" data-toggle="modal"><button class="btn btn-primary">Tambah Pembelian</button></a>
							<a href="<?php echo base_url();?>aplikasi/pembelian/print_pdf/<?php echo $tanggal.'/'.$id_konsumen;?>"><button class="btn btn-primary">Cetak</button></a>
							
							<br>
							<br>
							<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">barang</th>
									<th class="text-center">Jumlah</th>
									<th class="text-center">Keterangan</th>
									<th class="text-center">Total</th>
								</tr>
								<?php $no=1; if($listpembelian){ foreach($listpembelian as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="20%"><?php echo $l->nama_barang; ?></td>
									<td width="20%"><?php echo $l->jumlah; ?></td>
									<td width="30%"><?php echo $l->keterangan; ?></td>
									<td width="20%"><?php echo "Rp. ".number_format($l->harga); ?></td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
							</table>
							<?php } ?>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Tambah pembelian</h4>
					</div>
					<form class="form-horizontal" role="form" action="<?php echo base_url('aplikasi/pembelian/submit'); ?>" method="post" enctype="multipart/form-data">
						<input type="hidden" name="tanggal" value="<?php echo $tanggal; ?>">
						<input type="hidden" name="id_konsumen" value="<?php echo $id_konsumen; ?>">
						<input type="hidden" name="id_user" value="<?php echo $this->session->userdata('id_user'); ?>">

					<div class="modal-body">
						<div class="form-group">
							<label for="nama" class="col-sm-4 control-label required">barang</label>
							<div class="col-sm-8">
								<select class="form-control" id="barang" name="id_barang">
									<option value=0>-- Pilih barang --</option>
									<?php foreach($barang as $j): ?>
									<?php if($j->id_barang == $id_barang){ ?>
										<option selected value="<?php echo $j->id_barang; ?>"><?php echo $j->nama_barang; ?></option>
									<?php }else{ ?>
										<option value="<?php echo $j->id_barang; ?>"><?php echo $j->nama_barang; ?></option>
									<?php } endforeach; ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-4 control-label required">Jumlah Barang</label>
							<div class="col-sm-8">
							<input type="text" class="form-control" placeholder="Isi dengan Jumlah Barang yang Dibeli" name="jumlah" id='jumlah' required>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-4 control-label required">Harga Satuan</label>
							<div class="col-sm-8">
							<input type="text" class="form-control" placeholder="Harga Satuan Barang" id='harga_satuan' readonly>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-4 control-label required">Harga Total</label>
							<div class="col-sm-8">
							<input type="text" class="form-control" placeholder="Harga Total Pembelian" name="harga" id='harga' readonly>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-4 control-label required">Keterangan</label>
							<div class="col-sm-8">
								<select class="form-control" name="keterangan">
									<option value="0">-- Pilih Jenis Pembayaran --</option>
									<option value="cash">Cash</option>
									<option value="hutang">Hutang</option>
								</select>
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<a class="btn btn-default" data-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>