<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<link class="include" rel="stylesheet" type="text/css" href="<?php echo base_url();?>js/jquery.jqplot.min.css" />
		
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-4">
					<?php if($this->session->userdata('id_usergroup')==3){ ?>
                   	 <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Menu Utama</div>
                        <div class="panel-body">
                        	<br>
                            <a href="<?php echo base_url();?>siswa" class="btn btn-primary btn-block">Pembelian</a>
                            <a href="<?php echo base_url();?>ppdb" class="btn btn-primary btn-block">Penjualan</a>
                            <a href="<?php echo base_url();?>tabungan_wisata" class="btn btn-primary btn-block">Pengeluaran</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
					<?php } ?>
                     <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Profile User</div>
                        <div class="panel-body">
                        	<br>
                        	<center><img src="<?php echo base_url();?>uploads/profile_picture/<?php if($user->file_photo){echo $user->file_photo;}else{echo 'profile.png';} ?>" width="150px" height="150px"></center>
                        	<br>
                        	<p class="text-center"><?php echo $this->session->userdata('username'); ?></p>
                        	<p class="text-center"><?php echo $this->session->userdata('usergroup'); ?></p>
                        	<a href="#import" data-toggle="modal" class="btn btn-default btn-block">Change Picture</a>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                </div>

				<div class="col-lg-8">
					
                     <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Laporan Harian</div>
                        <div class="panel-body">
                        	<br>
                        	<div id="chart1" style="width:100%; height:300px;"></div>
                        	<script>
	                        	$(document).ready(function(){
								    var line1 = [['Pembelian', <?php echo $totalpembelian; ?>],['Penjualan', <?php echo $totalpenjualan; ?>],['Pengeluaran', <?php echo $totalpembelian; ?>]];
								 
								    $('#chart1').jqplot([line1], {
								        title:'Laporan Harian Hari Ini',
								        seriesDefaults:{
								            renderer:$.jqplot.BarRenderer,
								            pointLabels: { show: true, formatString: "Rp. %'.0f"},
								            rendererOptions: {
								                // Set the varyBarColor option to true to use different colors for each bar.
								                // The default series colors are used.
								                varyBarColor: true
								            }
								        },
								        axes:{
								            xaxis:{
								                renderer: $.jqplot.CategoryAxisRenderer
								            }
								        }
								    });
								});
							</script>
                        </div>
                        <!-- /.panel-body -->
                    </div>						
				</div>
				
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Change Profile Picture</h4>
					</div>
					<form class="form-horizontal" role="form" action="<?php echo base_url('auth/ganti'); ?>" method="post" enctype="multipart/form-data">
					<div class="modal-body">
						<div class="form-group">
							<label for="file" class="col-sm-2 control-label">Pilih File</label>
							<div class="col-sm-10">
								<input type="file" name="userfile" size="20" />
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<a class="btn btn-default" data-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>

		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
		<script class="include" type="text/javascript" src="<?php echo base_url();?>js/jquery.jqplot.min.js"></script>

		<!-- Additional plugins go here -->

		    <script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.barRenderer.min.js"></script>
		    <script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.categoryAxisRenderer.min.js"></script>
		    <script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.pointLabels.min.js"></script>
			<script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.dateAxisRenderer.min.js"></script>
			<script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.canvasTextRenderer.min.js"></script>
			<script class="include" language="javascript" type="text/javascript" src="<?php echo base_url();?>js/plugins/jqplot.canvasAxisTickRenderer.min.js"></script>
			
		<!-- End additional plugins -->
	</body>
</html>