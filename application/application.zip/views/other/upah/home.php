
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">
		<style>
			.borderless td, .borderless th {
    			border: none !important;
			}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
				<div class="col-lg-4">
					 <!-- /.panel -->
                    <div class="panel panel-default">
                        <div class="panel-heading">Rekap Upah</div>
                        <div class="panel-body">
                        	<br>
                        	<form class="form-horizontal" role="form" action ="<?php echo base_url();?>other/upah/print_pdf_rekap" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Tanggal Awal</label>
									<div class="col-md-7">
										<input type="date" class="form-control" name="tanggal_awal" value="<?php echo $tanggal_awal; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Tanggal Akhir</label>
									<div class="col-md-7">
										<input type="date" class="form-control" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="jenis" class="col-md-5 control-label pull-left">Nama Toko</label>
									<div class="col-md-7">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Pilih Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
								</div>
									<button type="submit" class="btn btn-primary btn-block">Cetak Rekap</button>
							</form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
				</div>
				<div class="col-lg-8">
					<div class="panel panel-default">
						<div class="panel-body">

							<div class="page-header">
							<?php $this->load->view('template/alert'); ?>
							<h3>Upah Karyawan</h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>other/upah/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-1 control-label pull-left">Tanggal</label>
									<div class="col-md-3">
										<input type="date" class="form-control" name="tanggal" value="<?php echo $tanggal; ?>">
									</div>
									<label for="jenis" class="col-md-2 control-label pull-left">Nama Toko</label>
									<div class="col-md-4">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Pilih Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
									<button type="submit" class="btn btn-primary">Proses</button>
								</div>
							</form>

							<?php if($id_konsumen && $tanggal){ ?>
							<hr>
							<table class="table borderless">
								<tr>
									<td class = 'text-center col-md-3 success'>Nama Toko</td>
									<td><?php echo $nama_toko; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Owner</td>
									<td><?php echo $owner; ?></td>
								</tr>
								<tr>
									<td class = 'text-center col-md-3 success'>Alamat</td>
									<td><?php echo $alamat; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Tanggal</td>
									<td><?php echo $tanggal; ?></td>
								</tr>
							</table>
							<hr>
							<a href="#import" data-toggle="modal"><button class="btn btn-primary">Tambah Upah Karyawan</button></a>
							<a href="<?php echo base_url();?>other/upah/print_pdf/<?php echo $tanggal.'/'.$id_konsumen;?>"><button class="btn btn-primary">Cetak</button></a>
							
							<br>
							<br>
							<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">Karyawan</th>
									<th class="text-center">Jabatan</th>
									<th class="text-center">Ket</th>
									<th class="text-center">Upah</th>
								</tr>
								<?php $no=1; if($listupah){ foreach($listupah as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="20%"><?php echo $l->nama_lengkap; ?></td>
									<td width="20%" class="text-center"><?php echo $l->usergroup; ?></td>
									<td width="30%" class="text-center"><?php if($l->keterangan==""){echo "-";}else{echo $l->keterangan;} ?></td>
									<td width="20%" class="text-center"><?php echo number_format($l->upah); ?></td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=5>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
							</table>
							<?php } ?>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="modal fade" id="import" role="dialog">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<h4>Tambah Upah</h4>
					</div>
					<form class="form-horizontal" role="form" action="<?php echo base_url('other/upah/submit'); ?>" method="post" enctype="multipart/form-data">
						<input type="hidden" name="tanggal" value="<?php echo $tanggal; ?>">
						<input type="hidden" name="id_konsumen" value="<?php echo $id_konsumen; ?>">
						<input type="hidden" name="id_user" value="<?php echo $this->session->userdata('id_user'); ?>">

					<div class="modal-body">
						<div class="form-group">
							<label for="nama" class="col-sm-2 control-label required">Karyawan</label>
							<div class="col-sm-10">
								<select class="form-control" id="sel1" name="id_karyawan">
											<option value=0>-- Pilih Karyawan --</option>
											<?php foreach($karyawan as $j): ?>
												<option value="<?php echo $j->id_user; ?>"><?php echo $j->nama_lengkap; ?></option>
											<?php endforeach; ?>
										</select>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-2 control-label required">Upah</label>
							<div class="col-sm-10">
							<input type="text" class="form-control" id="kelas" placeholder="Isi dengan Upah" name="upah" required>
							</div>
						</div>
						<div class="form-group">
							<label for="nama" class="col-sm-2 control-label required">Keterangan</label>
							<div class="col-sm-10">
							<input type="text" class="form-control" id="kelas" placeholder="Isi dengan Keterangan" name="keterangan">
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<a class="btn btn-default" data-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
					</form>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>