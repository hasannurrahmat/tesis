<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/styles.css">
		<script src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript">

			$(function(){
				$.ajaxSetup({
					type:"POST",
					url: "<?php echo base_url('other/pembelian/get_pembelian'); ?>",
					cache: false,
				});

				$("#barang").change(function(){

					var value=$(this).val();
					if(value>0){
						$.ajax({
							data:{modul:'pembelian',id:value},
							success: function(respond){
								$("#harga_satuan").val(respond);
								var satuan = parseInt(document.getElementById("harga_satuan").value);
								var jumlah = parseInt(document.getElementById("jumlah").value);
								var total = satuan * jumlah;
								$("#harga").val(total);
							}
						})
					}
				});

				$("#jumlah").change(function(){

					var value=$(this).val();
					
					if(value>0){
						var satuan = parseInt(document.getElementById("harga_satuan").value);
						var total = satuan * value;
						$("#harga").val(total);
					}
				});
			})

		</script>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Edit Data Pembelian</h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url(); ?>other/pembelian/submit" method="POST" enctype="multipart/form-data">
								<input type="hidden" name="id_pembelian" value="<?php echo $id_pembelian; ?>">
								<input type="hidden" name="id_konsumen" value="<?php echo $id_konsumen; ?>">
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Tanggal</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" value="<?php echo $tanggal; ?>" name="tanggal" readonly>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Nama Toko</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" value="<?php echo $nama_toko; ?>" readonly>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">barang</label>
									<div class="col-sm-10">
										<select class="form-control" id="barang" name="id_barang">
											<option value=0>-- Pilih Barang --</option>
											<?php foreach($barang as $j): ?>
											<?php if($j->id_barang == $id_barang){ ?>
												<option selected value="<?php echo $j->id_barang; ?>"><?php echo $j->nama_barang; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_barang; ?>"><?php echo $j->nama_barang; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Jumlah Barang</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" placeholder="Isi dengan Jumlah Barang yang Dibeli" name="jumlah" id='jumlah' value="<?php echo $jumlah?>" required>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Harga Satuan</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id='harga_satuan' value=<?php echo $harga_satuan; ?> readonly>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Harga Total</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" name="harga" id='harga' value=<?php echo $harga; ?> readonly>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Keterangan</label>
									<div class="col-sm-10">
										<select class="form-control" name="keterangan">
											<option value="0">-- Pilih Jenis Pembayaran --</option>
											<option value="cash" <?php if($keterangan=="cash"){echo "selected";} ?>>Cash</option>
											<option value="hutang" <?php if($keterangan=="hutang"){echo "selected";} ?>>Hutang</option>
										</select>
									</div>
								</div>
								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Kasir</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" value="<?php echo $kasir; ?>" readonly>
									</div>
								</div>
								<hr>
								<div class="pull-right">
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>
