
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script src="<?php echo base_url();?>js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript">

			$(function(){
				$.ajaxSetup({
					type:"POST",
					url: "<?php echo base_url('other/pembelian/get_barang'); ?>",
					cache: false,
				});

				$("#barang").change(function(){

					var value=$(this).val();
					if(value>0){
						$.ajax({
							data:{modul:'pembelian',id:value},
							success: function(respond){
								$("#harga_satuan").val(respond);
							}
						})
					}
				});

				$("#jumlah").change(function(){

					var value=$(this).val();
					
					if(value>0){
						var satuan = parseInt(document.getElementById("harga_satuan").value);
						var total = satuan * value;
						$("#harga").val(total);
					}
				});
			})

		</script>
		<style>
			.borderless td, .borderless th {
    			border: none !important;
			}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<?php $this->load->view('template/alert'); ?>
								<h3>Edit Data Pembelian</h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>other/pembelian/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-1 control-label pull-left">Tanggal</label>
									<div class="col-md-3">
										<input type="date" class="form-control" name="tanggal" value="<?php echo $tanggal; ?>">
									</div>
									<label for="jenis" class="col-md-2 control-label pull-left">Nama Toko</label>
									<div class="col-md-4">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Pilih Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
									<button type="submit" class="btn btn-primary">Proses</button>
								</div>
							</form>

							<?php if($id_konsumen && $tanggal){ ?>
							<hr>
							<table class="table borderless">
								<tr>
									<td class = 'text-center col-md-3 success'>Nama Toko</td>
									<td><?php echo $nama_toko; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Owner</td>
									<td><?php echo $owner; ?></td>
								</tr>
								<tr>
									<td class = 'text-center col-md-3 success'>Alamat</td>
									<td><?php echo $alamat; ?></td>
									<td>&nbsp;</td>
									<td class = 'text-center col-md-3 success'>Tanggal</td>
									<td><?php echo $tanggal; ?></td>
								</tr>
							</table>
							<hr>
							<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">barang</th>
									<th class="text-center">Jumlah</th>
									<th class="text-center">Keterangan</th>
									<th class="text-center">Total</th>
									<th class="text-center">Aksi</th>
								</tr>
								<?php $no=1; if($listpembelian){ foreach($listpembelian as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="20%"><?php echo $l->nama_barang; ?></td>
									<td width="10%" class="text-center"><?php echo $l->jumlah; ?></td>
									<td width="20%" class="text-center"><?php echo $l->keterangan; ?></td>
									<td width="20%" class="text-center"><?php echo "Rp. ".number_format($l->harga); ?></td>
									<td width="20%" class="text-center">
										<a href="<?php echo base_url('other/pembelian/edit/'.$l->id_pembelian); ?>">Ubah</a>&nbsp;|&nbsp;
										<a href="<?php echo base_url('other/pembelian/hapus/'.$l->id_pembelian); ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a>
									</td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=6>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
							</table>
							<?php } ?>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>