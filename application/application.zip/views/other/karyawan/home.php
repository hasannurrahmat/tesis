
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
							<h3>List Karyawan<a href="<?php echo base_url();?>other/karyawan/tambah/"><button class="btn btn-success pull-right">Tambah Karyawan</button></a></h3>
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>other/karyawan/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-2 control-label pull-left">Nama Karyawan</label>
									<div class="col-md-2">
										<input type="text" class="form-control" name="nama_lengkap" value="<?php echo $nama_lengkap; ?>">
									</div>
									<button type="submit" class="btn btn-primary">Cari</button>
								</div>

							</form>
							
							<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">Nama Karyawan</th>
									<th class="text-center">Jabatan</th>
									<th class="text-center">Aksi</th>
								</tr>
								<?php $no=$page+1; if($listuser){ foreach($listuser as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="40%"><?php echo $l->nama_lengkap; ?></td>
									<td width="30%"><?php echo $l->usergroup; ?></td>
									<td width="20%" class="text-center">
									<a href="<?php echo base_url();?>other/karyawan/ubah/<?php echo $l->id_user; ?>">Ubah</a> | 
									<a href="<?php echo base_url();?>other/karyawan/hapus/<?php echo $l->id_user; ?>" onClick="return confirm('Apakah Anda yakin akan menghapus data ini?')">Hapus</a></td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=4>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
							</table>

							<div style="display:none;" id="user" summary="Data User">
								<table class="table table-condensed table-responsive table-bordered">
								<tr class="active">
									<th class="text-center">No</th>
									<th class="text-center">Nama</th>
									<th class="text-center">Jabatan</th>
								</tr>
								<?php $no=$page+1; if($listuser){ foreach($listuser as $l): ?>
								<tr>
									<td width="10%" class="text-center"><?php echo $no; ?></td>
									<td width="50%"><?php echo $l->nama_lengkap; ?></td>
									<td width="40%"><?php echo $l->usergroup; ?></td>
								</tr>
								<?php $no++; endforeach; }else{ ?>
									<tr><td colspan=3>Tidak ada data, silahkan tambah data</td></tr>
								<?php } ?>
									
								</table>
							</div>
							<p><?php echo $links; ?></p>
							<input type="button" onclick="tableToExcel('user', 'Tabel Data Karyawan' , 'user.xls', 'Excel')" value="Cetak" class="btn btn-success">
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>