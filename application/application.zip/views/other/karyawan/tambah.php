<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo base_url();?>css/styles.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		<?php $this->load->view('template/alert'); ?>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">
							<div class="page-header">
								<h3>Tambah Karyawan</h3>
							
							</div>
							<form class="form-horizontal" role="form" action ="<?php echo base_url(); ?>other/karyawan/submit" method="POST" enctype="multipart/form-data">
								<input type="hidden" name="jenis" value="<?php echo $jenis; ?>">
								<input type="hidden" name="id_user" value="<?php echo $id_user; ?>">
								<input type="hidden" name="id_usergroup" value="<?php echo $id_usergroup; ?>">

								<div class="form-group">
									<label for="nama" class="col-sm-2 control-label required">Nama Lengkap</label>
									<div class="col-sm-10">
									<input type="text" class="form-control" id="kelas" placeholder="Isi dengan nama lengkap" name="nama_lengkap" value="<?php echo $nama_lengkap; ?>" required>
									</div>
								</div>
								<hr>
								<div class="pull-right">
								<button type="reset" class="btn btn-warning">Reset</button>
								<button type="submit" class="btn btn-primary">Submit</button>
								</div>
							
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>
