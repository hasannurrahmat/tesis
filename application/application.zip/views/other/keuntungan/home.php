
	
<html>
	<head>
		<title></title>
		<meta name="viewport" content="width=device-widtth, initial-scale=1.0">
		<link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/background.css">
		<script type="text/javascript">
			var tableToExcel = (function () {
				var uri = 'data:application/vnd.ms-excel;base64,'
					, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table border=1>{table}</table></body></html>'
					, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
					, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
				return function (table, name) {
					if (!table.nodeType) table = document.getElementById(table)
					var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }
					window.location.href = uri + base64(format(template, ctx))
				}
			})()
		</script>
		<style>
			.borderless td, .borderless th {
    			border: none !important;
			}
		</style>
	</head>
	<body>

		<?php $this->load->view('template/menunavigasi'); ?>
		
		<div class="container">
			
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default">
						<div class="panel-body">

							<div class="page-header">
							<?php $this->load->view('template/alert'); ?>
							<h3>Laporan Keuntungan</h3>
							</div>
							
							<form class="form-horizontal" role="form" action ="<?php echo base_url();?>other/keuntungan/home" method="POST">
								<div class="form-group">
									<label for="jenis" class="col-md-1 control-label pull-left">Tanggal</label>
									<div class="col-md-2">
										<input type="date" class="form-control" name="tanggal_awal" value="<?php echo $tanggal_awal; ?>">
									</div>
									<label for="jenis" class="control-label pull-left">-</label>
									<div class="col-md-2">
										<input type="date" class="form-control" name="tanggal_akhir" value="<?php echo $tanggal_akhir; ?>">
									</div>
									<label for="jenis" class="col-md-1 control-label pull-left">Toko</label>
									<div class="col-md-2">
										<select class="form-control" id="sel1" name="id_konsumen">
											<option value=0>-- Seluruh Toko --</option>
											<?php foreach($konsumen as $j): ?>
											<?php if($j->id_konsumen == $id_konsumen){ ?>
												<option selected value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php }else{ ?>
												<option value="<?php echo $j->id_konsumen; ?>"><?php echo $j->nama_toko; ?></option>
											<?php } endforeach; ?>
										</select>
									</div>
									<button type="submit" class="btn btn-primary">Proses</button>
								</div>
							</form>
							<hr>
							<?php if($tanggal_awal || $tanggal_akhir){ ?>
							<!-- Nav tabs -->
							<ul class="nav nav-tabs" role="tablist">
								<?php $counter=0; foreach($konsumen as $j): ?>
									<?php if($j->id_konsumen==$id_konsumen || $id_konsumen==0){ ?>
										<li role="presentation" <?php if($counter==0){ ?>class="active"<?php } ?>><a href="#<?php echo $j->id_konsumen; ?>" aria-controls="<?php echo $j->id_konsumen; ?>" role="tab" data-toggle="tab"><?php echo $j->nama_toko; ?></a></li>
									<?php $counter++; } ?>
								<?php endforeach; ?>
							</ul>
							<?php } ?>
							<br>
							<!-- Tab panes -->
							<div class="tab-content">
								<?php $counter=0; foreach($konsumen as $j): ?>
									<?php if($j->id_konsumen==$id_konsumen || $id_konsumen==0 && ($tanggal_awal || $tanggal_akhir)){ ?>
										<!-- view seluruh keuntungan -->
										<div role="tabpanel" class="tab-pane <?php if($counter==0){ echo "active";}?>" id="<?php echo $j->id_konsumen; ?>">
											<div id="keuntungan" summary="laporan keuntungan">
												<div style="display:none;">
													<table><tr><td colspan=7><center><b>Laporan Keuntungan</b></center></td></tr></table>
													<table><tr><td colspan=7><center><b><?php echo "Toko: ".$j->nama_toko; ?></b></center></td></tr></table>
													<table><tr><td></td></tr></table>
													<table class="table table-condensed table-responsive table-bordered">
														<tr>
															<td>Tanggal</td>
															<td><?php echo $tanggal_awal.' - '.$tanggal_akhir; ?></td>
														</tr>
													</table>
													<table><tr><td></td></tr></table>
												</div>
												<table class="table table-condensed table-responsive table-bordered">
													<tr class="active">
														<th class="text-center">No</th>
														<th class="text-center">Barang</th>
														<th class="text-center">Harga Barang</th>
														<th class="text-center">Jumlah Pembelian (Qty/Pcs)</th>
														<th class="text-center">Jumlah Penjualan (Qty/Pcs)</th>
														<th class="text-center">Netto</th>
														<th class="text-center">Bruto</th>
													</tr>
													<?php $no=1; $cash=0; $hutang=0;if($listkeuntungan){ foreach($listkeuntungan as $l => $val): ?>
														<?php if($l == $j->id_konsumen){ ?>
															<?php foreach($val as $v){ ?>
																<tr>
																	<td class="text-center"><?php echo $no; ?></td>
																	<td><?php echo $v["nama_barang"]; ?></td>
																	<td class="text-center"><?php echo "Rp. ".number_format($v["harga_satuan"]); ?></td>
																	<td class="text-center"><?php echo $v["pembelian"]; ?></td>
																	<td class="text-center"><?php echo $v["penjualan"]; ?></td>
																	<td class="text-center"><?php echo "Rp. ".number_format($v["netto"]); ?></td>
																	<td class="text-center"><?php echo "Rp. ".number_format($v["bruto"]); ?></td>
																</tr>
															<?php $no++; } ?>
														<?php } ?>
													<?php endforeach; ?>
													
													<?php }else{ ?>
														<tr><td colspan=8>Tidak ada data, silahkan tambah data</td></tr>
													<?php } ?>
												</table>
											</div>
											<input type="button" onclick="tableToExcel('keuntungan', 'laporan keuntungan' , 'keuntungan.xls', 'Excel')" value="Cetak" class="btn btn-success">
										</div>
									<?php $counter++; } ?>
								<?php endforeach; ?>
								<?php if($counter==0){ ?>
									<div class="alert alert-warning alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										Isi rentang tanggal dan nama toko yang ingin dilihat laporan keuntungannya.
									</div>
								<?php } ?>
							</div>						
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php $this->load->view('template/footer'); ?>
		<script src="<?php echo base_url();?>js/jquery-1.10.2.min.js"></script>
		<script src="<?php echo base_url();?>js/bootstrap.js"></script>
	</body>
</html>