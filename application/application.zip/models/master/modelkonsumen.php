<?php

class Modelkonsumen extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countkonsumen($nama_toko, $owner){
		if($owner){
			$this->db->like("u.nama_lengkap", $owner);
		}
		if($nama_toko){
			$this->db->like("k.nama_toko", $nama_toko);
		}
		$this->db->join("user u", 'u.id_user=k.id_user');
		$query = $this->db->get("konsumen k");
		return $query->num_rows();
	}
	
	public function getAllkonsumen($limit, $start, $nama_toko, $owner){
		$this->db->limit($limit, $start);
		if($owner){
			$this->db->like("u.nama_lengkap", $owner);
		}
		if($nama_toko){
			$this->db->like("k.nama_toko", $nama_toko);
		}
		$this->db->join("user u", 'u.id_user=k.id_user');
		$query = $this->db->get("konsumen k");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkonsumen($id){
		$this->db->join("user u", "u.id_user=k.id_user");
		$this->db->where("k.id_konsumen", $id);
		$query = $this->db->get("konsumen k");
		
		return $query->row();
	}
	
	public function tambah_user($data){
		$this->db->insert('user', $data);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}

	public function tambah($data){
		$this->db->insert('konsumen', $data);
	}
	
	public function ubah_user($data){
		$this->db->where('id_user', $data['id_user']);
		$this->db->update('user', $data); 
	}

	public function ubah($data){
		$this->db->where('id_konsumen', $data['id_konsumen']);
		$this->db->update('konsumen', $data); 
	}
	
	public function hapus($id){
		$row=$this->modelkonsumen->getkonsumen($id);

		$this->db->where('id_user', $row->id_user);
		$this->db->delete('user'); 

		$this->db->where('id_konsumen', $id);
		$this->db->delete('konsumen'); 
	}
}