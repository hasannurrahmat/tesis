<?php

class Modelbarang extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getAllitem(){
		
		$query = $this->db->get("barang b");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllbarang($nama_barang, $sumber_barang, $tujuan_barang){
		if($nama_barang){
			$this->db->like("b.nama_barang", $nama_barang);
		}
		if($tujuan_barang){
			$this->db->like("b.tujuan_barang", $tujuan_barang);
		}
		if($sumber_barang){
			$this->db->like("b.sumber_barang", $sumber_barang);
		}
		$query = $this->db->get("barang b");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getbarang($id){
		$this->db->where("k.id_barang", $id);
		$query = $this->db->get("barang k");
		
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('barang', $data);
	}

	public function ubah($data){
		$this->db->where('id_barang', $data['id_barang']);
		$this->db->update('barang', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_barang', $id);
		$this->db->delete('barang'); 
	}

	public function getAllpembelian(){
		$this->db->select("u.*, sum(u.jumlah) as total_jumlah, sum(u.harga) as total_harga");
		$this->db->group_by("u.id_barang", "asc");
		$query = $this->db->get("pembelian u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpenjualan(){
		$this->db->select("u.*, sum(u.jumlah) as total_jumlah, sum(u.harga) as total_harga");
		$this->db->group_by("u.id_barang", "asc");
		$query = $this->db->get("penjualan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
}