<?php

class Modelganti extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("id_aplikasi", $id);
		$query = $this->db->get("aplikasi");
		
		return $query->row();
	}
	
	public function ubah($data){
		$this->db->where('id_aplikasi', $data['id_aplikasi']);
		$this->db->update('aplikasi', $data); 
	}
}