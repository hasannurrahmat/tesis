<?php

class Modeluser extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countuser($nama_lengkap, $id_usergroup){
		if($id_usergroup){
			$this->db->where("id_usergroup", $id_usergroup);
		}
		if($nama_lengkap){
			$this->db->like("nama_lengkap", $nama_lengkap);
		}
		$this->db->where("id_usergroup !=", 5);
		$query = $this->db->get("user");
		return $query->num_rows();
	}
	
	public function getAlluser($limit, $start, $nama_lengkap, $id_usergroup){
		$this->db->limit($limit, $start);
		if($id_usergroup){
			$this->db->where("u.id_usergroup", $id_usergroup);
		}
		if($nama_lengkap){
			$this->db->like("u.nama_lengkap", $nama_lengkap);
		}
		$this->db->order_by("u.id_usergroup", "asc");
		$this->db->where("u.id_usergroup !=", 5);
		$this->db->join("usergroup ug", "ug.id_usergroup=u.id_usergroup");
        $query = $this->db->get("user u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAlljabatan(){
		$this->db->where("id_usergroup !=", 5);
		$query = $this->db->get("usergroup");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getuser($id){
		$this->db->join("usergroup ug", "u.id_usergroup=ug.id_usergroup");
		$this->db->where("u.id_user", $id);
		$query = $this->db->get("user u");
		
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('user', $data);
	}
	
	public function ubah($data){
		$this->db->where('id_user', $data['id_user']);
		$this->db->update('user', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_user', $id);
		$this->db->delete('user'); 
	}
}