<?php

class Modelsiswa extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getAlltahun(){
		// $this->db->group_by("jabatan");
		$query = $this->db->get("tahun_ajaran");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getAllsiswa($id_kelas){
		$this->db->where('ks.id_kelas', $id_kelas);
		$this->db->join('siswa s', 's.id_siswa=ks.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=ks.id_kelas');
		$query = $this->db->get("kelas_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getAlldana($id_kelas){
		$this->db->where('ks.id_kelas', $id_kelas);
		$query = $this->db->get("dana_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllkelasimport(){
		// $this->db->group_by("jabatan");
		$this->db->join('tahun_ajaran t', 't.id_tahun_ajaran=k.id_tahun_ajaran');
		$this->db->order_by('t.tahun_ajaran', 'asc');
		$this->db->order_by('k.kelas', 'asc');
		$query = $this->db->get("kelas k");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkelas($id_tahun_ajaran){
		// $this->db->group_by("jabatan");
		$this->db->where('id_tahun_ajaran', $id_tahun_ajaran);
		$query = $this->db->get("kelas");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getjenisdana($tingkat){
		// $this->db->group_by("jabatan");
		$this->db->where('id_tingkat', $tingkat);
		$this->db->order_by("level", "asc");
		$query = $this->db->get("jenis_dana");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getjenisdanabyid($id){
		$this->db->where("id_jenis_dana", $id);
		$query = $this->db->get("jenis_dana");
		
		return $query->row();
	}
	
	public function getkelas($id_kelas){
		$this->db->where("id_kelas", $id_kelas);
		$query = $this->db->get("kelas");
		
		return $query->row();
	}
	
	public function getsiswa($nis, $nama){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		if($nis){
		$this->db->where("s.nis", $nis);
		}
		if($nama){
		$this->db->like("s.nama", $nama);
		}
		$this->db->order_by("s.nis", "asc");
		$this->db->group_by("s.id_siswa");
		$query = $this->db->get("kelas_siswa ks");
		
		// return $query->row();
		if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function carijenisdana($kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_dana j", "j.id_jenis_dana=ds.id_jenis_dana");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_kelas', $kelas);
		$query = $this->db->get("dana_siswa ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function carijenisdanabysiswa($siswa, $kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_dana j", "j.id_jenis_dana=ds.id_jenis_dana");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_siswa', $siswa);
		$this->db->where('ds.id_kelas', $kelas);
		$query = $this->db->get("dana_siswa ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function tambah_dana_kelas($data){
		$this->db->insert('dana_siswa', $data);
	}
	
	public function update_dana_kelas($data){
		$this->db->where('id_siswa', $data['id_siswa']);
		$this->db->where('id_kelas', $data['id_kelas']);
		$this->db->where('id_jenis_dana', $data['id_jenis_dana']);
		$this->db->update('dana_siswa', $data);

		return $this->db->affected_rows();
	}
	
	public function tambah_rekap($data){
		$this->db->insert('rekap_harian', $data);
	}
	
	public function getdana_siswa($id_siswa, $id_jenis_dana, $id_kelas){
		$this->db->where("id_siswa", $id_siswa);
		$this->db->where("id_jenis_dana", $id_jenis_dana);
		$this->db->where("id_kelas", $id_kelas);
		$query = $this->db->get("dana_siswa");
		
		return $query->row();
	}
	
	function getrekap($tanggal){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		$this->db->where('r.tanggal', $tanggal);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_siswa d', 'd.id_dana_siswa=r.id_dana_siswa');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_dana j", "j.id_jenis_dana=d.id_jenis_dana");
		$query = $this->db->get("rekap_harian r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getrekap_tabungan($tanggal){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		$this->db->where('r.tanggal', $tanggal);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_wisata d', 'd.id_dana_wisata=r.id_dana_wisata');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=d.id_jenis_tabungan_wisata");
		$query = $this->db->get("rekap_harian_wisata r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	function getrekap_seluruhtabungan(){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		$this->db->select('s.id_siswa, sum(d.nilai) as jumlah');
		$this->db->group_by('s.id_siswa');
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_wisata d', 'd.id_dana_wisata=r.id_dana_wisata');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=d.id_jenis_tabungan_wisata");
		$query = $this->db->get("rekap_harian_wisata r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	function getrekap_ppdb($tanggal){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		$this->db->where('r.tanggal', $tanggal);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('jenis_ppdb j', 'j.id_jenis_ppdb=r.id_jenis_ppdb');
		$this->db->join("ppdb p", "p.id_ppdb=r.id_ppdb");
		$query = $this->db->get("rekap_harian_ppdb r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkasir(){
		// $this->db->where('id_usergroup', 1);
		$query = $this->db->get("user");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getCountkasir(){
		// $this->db->where('id_usergroup', 1);
		$query = $this->db->get("user");
 
        return $query->num_rows();
	}

	public function getkelassiswabyidsiswa($id){
		$this->db->where('ks.id_siswa', $id);
		$this->db->join('kelas k', 'k.id_kelas=ks.id_kelas');

		$query = $this->db->get("kelas_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function caridanasiswa($siswa, $kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_dana j", "j.id_jenis_dana=ds.id_jenis_dana");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_kelas', $kelas);
		$this->db->where('ds.id_siswa', $siswa);
		$this->db->order_by("j.level", "asc");
		$query = $this->db->get("dana_siswa ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getsiswabyid($id){
		
		$this->db->where("s.id_siswa", $id);
		$query = $this->db->get("siswa s");
		
		return $query->row_array();
	}

	public function getsiswabynis($nis){
		
		$this->db->where("s.nis", $nis);
		// $this->db->where("s.nama", $nama);
		$query = $this->db->get("siswa s");
		
		return $query->row_array();
	}

	public function getAlljenisdana(){
		$this->db->order_by("level", "asc");
		$query = $this->db->get("jenis_dana");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getsiswadana($id, $kelas){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		$this->db->where("s.id_siswa", $id);
		$this->db->where("k.id_kelas", $kelas);
		// $this->db->order_by("s.nis", "asc");
		// $this->db->group_by("s.id_siswa");
		$query = $this->db->get("kelas_siswa ks");
		
		return $query->row();
	}

	public function hapus_rekap_pembayaran($id){
		$this->db->where('id_rekap_harian', $id);
		$this->db->delete('rekap_harian'); 
	}

	public function hapus_rekap_ppdb($id){
		$this->db->where('id_rekap_harian_ppdb', $id);
		$this->db->delete('rekap_harian_ppdb'); 
	}

	public function hapus_rekap_wisata($id){
		$this->db->where('id_rekap_harian_wisata', $id);
		$this->db->delete('rekap_harian_wisata'); 
	}
}