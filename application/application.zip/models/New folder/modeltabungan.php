<?php

class Modeltabungan extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getAlltahun(){
		// $this->db->group_by("jabatan");
		$query = $this->db->get("tahun_ajaran");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getAllsiswa($id_kelas){
		$this->db->where('ks.id_kelas', $id_kelas);
		$this->db->join('siswa s', 's.id_siswa=ks.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=ks.id_kelas');
		$query = $this->db->get("kelas_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getAlldana($id_kelas){
		$this->db->where('ks.id_kelas', $id_kelas);
		$query = $this->db->get("dana_wisata ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllkelasimport(){
		// $this->db->group_by("jabatan");
		$this->db->join('tahun_ajaran t', 't.id_tahun_ajaran=k.id_tahun_ajaran');
		$this->db->order_by('t.tahun_ajaran', 'asc');
		$this->db->order_by('k.kelas', 'asc');
		$query = $this->db->get("kelas k");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkelas($id_tahun_ajaran){
		// $this->db->group_by("jabatan");
		$this->db->where('id_tahun_ajaran', $id_tahun_ajaran);
		$query = $this->db->get("kelas");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getjenisdana(){
		// $this->db->group_by("jabatan");
		$query = $this->db->get("jenis_tabungan_wisata");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getjenisdanabyid($id){
		$this->db->where("id_jenis_tabungan_wisata", $id);
		$query = $this->db->get("jenis_tabungan_wisata");
		
		return $query->row();
	}
	
	public function getkelas($id_kelas){
		$this->db->where("id_kelas", $id_kelas);
		$query = $this->db->get("kelas");
		
		return $query->row();
	}
	
	public function getsiswa($nis, $nama){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		if($nis){
		$this->db->where("s.nis", $nis);
		}
		if($nama){
		$this->db->like("s.nama", $nama);
		}
		$this->db->order_by("s.nis", "asc");
		$this->db->group_by("s.id_siswa");
		$query = $this->db->get("kelas_siswa ks");
		
		// return $query->row();
		if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function carijenisdana($kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=ds.id_jenis_tabungan_wisata");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_kelas', $kelas);
		$query = $this->db->get("dana_wisata ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function carijenisdanabysiswa($siswa, $kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=ds.id_jenis_tabungan_wisata");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_siswa', $siswa);
		$this->db->where('ds.id_kelas', $kelas);
		$query = $this->db->get("dana_wisata ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function tambah_dana_kelas($data){
		$this->db->insert('dana_wisata', $data);
	}
	
	public function update_dana_kelas($data){
		$this->db->where('id_siswa', $data['id_siswa']);
		$this->db->where('id_kelas', $data['id_kelas']);
		$this->db->where('id_jenis_tabungan_wisata', $data['id_jenis_tabungan_wisata']);
		$this->db->update('dana_wisata', $data); 
	}
	
	public function tambah_rekap($data){
		$this->db->insert('rekap_harian_wisata', $data);
	}
	
	public function getdana_siswa($id_siswa, $id_jenis_dana, $id_kelas){
		$this->db->where("id_siswa", $id_siswa);
		$this->db->where("id_jenis_tabungan_wisata", $id_jenis_dana);
		$this->db->where("id_kelas", $id_kelas);
		$query = $this->db->get("dana_wisata");
		
		return $query->row();
	}
	
	public function getkelassiswabyidsiswa($id){
		$this->db->where('ks.id_siswa', $id);
		$this->db->join('kelas k', 'k.id_kelas=ks.id_kelas');

		$query = $this->db->get("kelas_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function caridanasiswa($siswa, $kelas){
		// $this->db->group_by("jabatan");
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=ds.id_jenis_tabungan_wisata");
		$this->db->join("kelas k", "k.id_kelas=ds.id_kelas");
		$this->db->where('ds.id_kelas', $kelas);
		$this->db->where('ds.id_siswa', $siswa);
		$query = $this->db->get("dana_wisata ds");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getsiswabyid($id){
		
		$this->db->where("s.id_siswa", $id);
		$query = $this->db->get("siswa s");
		
		return $query->row_array();
	}

	public function getsiswabynis($nis){
		
		$this->db->where("s.nis", $nis);
		// $this->db->where("s.nama", $nama);
		$query = $this->db->get("siswa s");
		
		return $query->row_array();
	}

	public function getAlljenisdana(){
		$query = $this->db->get("jenis_tabungan_wisata");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getsiswadana($id, $kelas){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		$this->db->where("s.id_siswa", $id);
		$this->db->where("k.id_kelas", $kelas);
		// $this->db->order_by("s.nis", "asc");
		// $this->db->group_by("s.id_siswa");
		$query = $this->db->get("kelas_siswa ks");
		
		return $query->row();
		// // return $query->row();
		// if ($query->num_rows() > 0) {
 	}

 	public function getsaldo($siswa, $kelas){
 		$this->db->select("sum(nilai) as saldo");
 		$this->db->where("id_siswa", $siswa);
 		$this->db->where("id_kelas", $kelas);
		$query = $this->db->get("dana_wisata");
		
		return $query->row_array();
 	}
}