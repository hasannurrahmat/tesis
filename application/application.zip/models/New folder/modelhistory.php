<?php

class Modelhistory extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countsiswa($nis, $nama){
		if($nis){
			$this->db->where("nis", $nis);
		}
		if($nama){
			$this->db->like("nama", $nama);
		}
		$query = $this->db->get("siswa");
		return $query->num_rows();
	}
	
	public function getAllsiswa($limit, $start, $nis, $nama){
		$this->db->limit($limit, $start);
		if($nis){
			$this->db->where("nis", $nis);
		}
		if($nama){
			$this->db->like("nama", $nama);
		}
        $query = $this->db->get("siswa");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getsiswa($id){
		$query = $this->db->query("SELECT * FROM siswa WHERE id_siswa = '$id' ");
		return $query->row();
	}
	
	function getrekap($tanggal, $siswa){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		if($tanggal!=""){
			$this->db->where('r.tanggal', $tanggal);
		}
		$this->db->where('d.id_siswa', $siswa);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_siswa d', 'd.id_dana_siswa=r.id_dana_siswa');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_dana j", "j.id_jenis_dana=d.id_jenis_dana");
		$query = $this->db->get("rekap_harian r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	function getrekap_tabungan($tanggal, $siswa){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		if($tanggal!=""){
			$this->db->where('r.tanggal', $tanggal);
		}
		$this->db->where('d.id_siswa', $siswa);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_wisata d', 'd.id_dana_wisata=r.id_dana_wisata');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_tabungan_wisata j", "j.id_jenis_tabungan_wisata=d.id_jenis_tabungan_wisata");
		$query = $this->db->get("rekap_harian_wisata r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	function getrekap_ppdb($tanggal, $nama){
		// $this->db->where('r.id_user', $this->session->userdata('id_user'));
		if($tanggal!=""){
			$this->db->where('r.tanggal', $tanggal);
		}
		$this->db->like('p.nama', $nama);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('jenis_ppdb j', 'j.id_jenis_ppdb=r.id_jenis_ppdb');
		$this->db->join("ppdb p", "p.id_ppdb=r.id_ppdb");
		$query = $this->db->get("rekap_harian_ppdb r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
}