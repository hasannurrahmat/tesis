<?php

class Modelkelas_siswa extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countkelas_siswa(){
		// $this->db->join('jenis_penilaian j', 'k.id_jenis_penilaian=j.id_jenis_penilaian');
        $query = $this->db->get("kelas_siswa");
		return $query->num_rows();
	}
	
	public function getAllkelas_siswa(){
		$this->db->join('siswa j', 'jd.id_siswa=j.id_siswa');
		$this->db->join('kelas t', 'jd.id_kelas=t.id_kelas');
        $query = $this->db->get("kelas_siswa jd");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getskelas_siswa($id=0){
		$this->db->join('siswa j', 'jd.id_siswa=j.id_siswa');
		$this->db->join('kelas t', 'jd.id_kelas=t.id_kelas');
		$this->db->where('jd.id_kelas', $id);
        $query = $this->db->get("kelas_siswa jd");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllsiswa(){
		$query = $this->db->get("siswa");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlltahun_ajaran(){
		$query = $this->db->get("tahun_ajaran");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllkelas($id=0){
		$this->db->where("id_tahun_ajaran", $id);
		$query = $this->db->get("kelas");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkelas_siswa($id){
		$this->db->join('siswa j', 'jd.id_siswa=j.id_siswa');
		$this->db->join('kelas t', 'jd.id_kelas=t.id_kelas');
		$this->db->where('jd.id_kelas_siswa', $id);
        $query = $this->db->get("kelas_siswa jd");
		return $query->row();
	}
	
	public function getcari_siswa($id, $kelas){
		$this->db->where('jd.id_siswa', $id);
		$this->db->where('jd.id_kelas', $kelas);
        $query = $this->db->get("kelas_siswa jd");
		return $query->row();
	}
	
	public function tambah($data){
		foreach($data['siswa'] as $s){
			$cari = $this->modelkelas_siswa->getcari_siswa($s, $data['id_kelas']);
			if(!$cari){
				$d['id_siswa'] = $s;
				$d['id_kelas'] = $data['id_kelas'];
				$this->db->insert('kelas_siswa', $d);
			}
		}
	}
	
	public function tambah_kelas($data){
		$this->db->insert('kelas_siswa', $data);
	}

	public function ubah($data){
		$this->db->where('id_kelas_siswa', $data['id_kelas_siswa']);
		$this->db->update('kelas_siswa', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_kelas_siswa', $id);
		$this->db->delete('kelas_siswa'); 
	}

	public function hapus_dana_siswa($siswa, $kelas){
		$this->db->where('id_siswa', $siswa);
		$this->db->where('id_kelas', $kelas);
		$this->db->delete('dana_siswa');

		$this->db->where('id_siswa', $siswa);
		$this->db->where('id_kelas', $kelas);
		$this->db->delete('dana_wisata');

		$this->db->where('id_siswa', $siswa);
		$this->db->where('id_kelas', $kelas);
		$this->db->delete('kelas_siswa');
	}

	public function getsiswa($nis, $nama){
		$this->db->where('nis', $nis);
		$this->db->where('nama', $nama);
        $query = $this->db->get("siswa");
		return $query->row();
	}


	public function getsiswakelas($nis, $nama){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		if($nis){
		$this->db->where("s.nis", $nis);
		}
		if($nama){
		$this->db->like("s.nama", $nama);
		}
		$this->db->order_by("s.nis", "asc");
		$this->db->group_by("s.id_siswa");
		$query = $this->db->get("kelas_siswa ks");
		
		// return $query->row();
		if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getkelas($kelas, $tingkat, $tahun){
		$this->db->join('tingkat t', 't.id_tingkat=k.id_tingkat');
		$this->db->join('tahun_ajaran ta', 'ta.id_tahun_ajaran=k.id_tahun_ajaran');
		$this->db->where('k.kelas', $kelas);
		$this->db->where('t.nama_tingkat', $tingkat);
		$this->db->where('ta.tahun_ajaran', $tahun);
        $query = $this->db->get("kelas k");
		return $query->row();
	}
	
	public function getkelassiswabyidsiswa($id){
		$this->db->where('ks.id_siswa', $id);
		$this->db->join('kelas k', 'k.id_kelas=ks.id_kelas');
		$this->db->join('tingkat t', 'k.id_tingkat=t.id_tingkat');
		$this->db->join('tahun_ajaran ta', 'ta.id_tahun_ajaran=k.id_tahun_ajaran');

		$query = $this->db->get("kelas_siswa ks");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
}