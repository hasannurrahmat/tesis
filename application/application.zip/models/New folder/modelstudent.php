<?php

class Modelstudent extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countsiswa($nis, $nama){
		if($nis){
			$this->db->where("nis", $nis);
		}
		if($nama){
			$this->db->like("nama", $nama);
		}
		$query = $this->db->get("siswa");
		return $query->num_rows();
	}
	
	public function getAllsiswa($limit, $start, $nis, $nama){
		$this->db->limit($limit, $start);
		if($nis){
			$this->db->where("nis", $nis);
		}
		if($nama){
			$this->db->like("nama", $nama);
		}
        $query = $this->db->get("siswa");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getsiswa($id){
		$query = $this->db->query("SELECT * FROM siswa WHERE id_siswa = '$id' ");
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('siswa', $data);
	}
	
	public function ubah($data){
		$this->db->where('id_siswa', $data['id_siswa']);
		$this->db->update('siswa', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_siswa', $id);
		$this->db->delete('siswa'); 
	}
}