<?php

class Modelppdb extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	function getAllsiswa($tahun, $no="", $nama=""){
		if($no!=""){ $this->db->like("no_pendaftaran", $no);}
		if($nama!=""){ $this->db->like("nama", $nama);}
		
		$this->db->where("tahun", $tahun);
		$query = $this->db->get("ppdb");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
		
        return false;
	}
	
	function getsiswabyid($id){
		$this->db->where("id_ppdb", $id);
		$query = $this->db->get("ppdb");
 		
		return $query->row();
	}

	public function getppdbbyid($id){
		$this->db->where("id_ppdb", $id);
		$query = $this->db->get("ppdb");
		
		return $query->row_array();
	}
	
	public function getjenisppdb(){
		$query = $this->db->get("jenis_ppdb");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getsiswa($nis, $nama){
		$this->db->join("siswa s", "s.id_siswa=ks.id_siswa");
		$this->db->join("kelas k", "k.id_kelas=ks.id_kelas");
		if($nis){
		$this->db->like("s.nis", $nis);
		}
		if($nama){
		$this->db->like("s.nama", $nama);
		}
		$query = $this->db->get("kelas_siswa ks");
		
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('ppdb', $data);
	}
	
	public function ubah($data){
		$this->db->where('id_ppdb', $data['id_ppdb']);
		$this->db->update('ppdb', $data); 
	}

	public function update($data){
		$this->db->where('id_siswa', $data['id_siswa']);
		$this->db->where('id_kelas', $data['id_kelas']);
		$this->db->where('id_jenis_dana', $data['id_jenis_dana']);
		$this->db->update('dana_siswa', $data); 
	}
	
	public function tambah_rekap($data){
		$this->db->insert('rekap_harian_ppdb', $data);
	}
	
	public function getdana_siswa($id_siswa, $id_jenis_dana, $id_kelas){
		$this->db->where("id_siswa", $id_siswa);
		$this->db->where("id_jenis_dana", $id_jenis_dana);
		$this->db->where("id_kelas", $id_kelas);
		$query = $this->db->get("dana_siswa");
		
		return $query->row();
	}
	
	function getrekap($tanggal){
		$this->db->where('r.id_user', $this->session->userdata('id_user'));
		$this->db->where('r.tanggal', $tanggal);
		$this->db->join('user u', 'u.id_user=r.id_user');
		$this->db->join('dana_siswa d', 'd.id_dana_siswa=r.id_dana_siswa');
		$this->db->join('siswa s', 's.id_siswa=d.id_siswa');
		$this->db->join('kelas k', 'k.id_kelas=d.id_kelas');
		$this->db->join("jenis_dana j", "j.id_jenis_dana=d.id_jenis_dana");
		$query = $this->db->get("rekap_harian r");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlltahunajaran(){
		$query = $this->db->get("tahun_ajaran");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllkasir(){
		$this->db->where('id_usergroup', 1);
		$query = $this->db->get("user");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getCountkasir(){
		$this->db->where('id_usergroup', 1);
		$query = $this->db->get("user");
 
        return $query->num_rows();
	}

	public function hapusbyid($id){
		$this->db->where('id_ppdb', $id);
		$this->db->delete('ppdb');
	}

	public function hapusbytahun($tahun){
		$this->db->where('tahun', $tahun);
		$this->db->delete('ppdb');
	}
}