<?php

class Modelkelas extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countkelas(){
		// $this->db->join('jenis_penilaian j', 'k.id_jenis_penilaian=j.id_jenis_penilaian');
        $query = $this->db->get("kelas");
		return $query->num_rows();
	}
	
	public function getAllkelas(){
		$this->db->join('tahun_ajaran j', 'jd.id_tahun_ajaran=j.id_tahun_ajaran');
		$this->db->join('tingkat t', 'jd.id_tingkat=t.id_tingkat');
        $query = $this->db->get("kelas jd");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlltahun_ajaran(){
		$query = $this->db->get("tahun_ajaran");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlltingkat(){
		$query = $this->db->get("tingkat");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function gettingkat($tingkat){
		$this->db->where('nama_tingkat', $tingkat);
        $query = $this->db->get("tingkat");
		return $query->row();
	}

	public function gettahun($tahun){
		$this->db->where('tahun_ajaran', $tahun);
        $query = $this->db->get("tahun_ajaran");
		return $query->row();
	}

	public function getkelas($id){
		$this->db->join('tahun_ajaran j', 'jd.id_tahun_ajaran=j.id_tahun_ajaran');
		$this->db->join('tingkat t', 'jd.id_tingkat=t.id_tingkat');
		$this->db->where('jd.id_kelas', $id);
        $query = $this->db->get("kelas jd");
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('kelas', $data);
	}
	
	public function ubah($data){
		$this->db->where('id_kelas', $data['id_kelas']);
		$this->db->update('kelas', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_kelas', $id);
		$this->db->delete('kelas'); 
	}
}