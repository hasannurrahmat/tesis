<?php

class Modeldana extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function countdana(){
		// $this->db->join('jenis_penilaian j', 'k.id_jenis_penilaian=j.id_jenis_penilaian');
        $query = $this->db->get("jenis_dana");
		return $query->num_rows();
	}
	
	public function getAlldana(){
		$this->db->join('jenis j', 'jd.id_jenis=j.id_jenis');
		$this->db->join('tingkat t', 'jd.id_tingkat=t.id_tingkat');
        $query = $this->db->get("jenis_dana jd");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlljenis(){
		$query = $this->db->get("jenis");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAlltingkat(){
		$query = $this->db->get("tingkat");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getdana($id){
		$this->db->join('jenis j', 'jd.id_jenis=j.id_jenis');
		$this->db->join('tingkat t', 'jd.id_tingkat=t.id_tingkat');
		$this->db->where('jd.id_jenis_dana', $id);
        $query = $this->db->get("jenis_dana jd");
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('jenis_dana', $data);
	}
	
	public function ubah($data){
		$this->db->where('id_jenis_dana', $data['id_jenis_dana']);
		$this->db->update('jenis_dana', $data); 
	}
	
	public function hapus($id){
		$this->db->where('id_jenis_dana', $id);
		$this->db->delete('jenis_dana'); 
	}
}