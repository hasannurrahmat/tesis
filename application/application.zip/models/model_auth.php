<?php 

class Model_auth extends CI_Model{
	public function __construct(){
		parent::__construct();
	}
	
	public function getuser($username){
		$this->db->where('pe.username', $username);
        $query = $this->db->get("user pe");
		if($query->num_rows() == 1){
			return $query->row();
		}
	}

	public function validasi_login($username, $password){
		$this->db->where('pe.username', $username);
		$this->db->where('pe.password', $password);
		$this->db->join('usergroup ug', 'ug.id_usergroup=pe.id_usergroup');
        $query = $this->db->get("user pe");
		
		if($query->num_rows() == 1){
			return $query->row();
		}
	}

	public function getaplikasi($id){
		$this->db->where("id_aplikasi", $id);
		$query = $this->db->get("aplikasi");
		
		return $query->row();
	}

	public function getAllpembelian(){
		if($this->session->userdata('id_usergroup')==3){
			$this->db->where("u.id_user", $this->session->userdata('id_user'));
		}
		
		$this->db->where("u.tanggal", date("Y-m-d"));
		$this->db->select("sum(u.harga) as total_harga");
		$this->db->group_by("u.id_user");
		$query = $this->db->get("pembelian u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpenjualan(){
		if($this->session->userdata('id_usergroup')==3){
			$this->db->where("u.id_user", $this->session->userdata('id_user'));
		}
		
		$this->db->where("u.tanggal", date("Y-m-d"));
		$this->db->select("sum(u.harga) as total_harga");
		$this->db->group_by("u.id_user");
		$query = $this->db->get("penjualan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpengeluaran(){
		if($this->session->userdata('id_usergroup')==3){
			$this->db->where("u.id_user", $this->session->userdata('id_user'));
		}
		
		$this->db->where("u.tanggal", date("Y-m-d"));
		$this->db->select("sum(u.harga) as total_harga");
		$this->db->group_by("u.id_user");
		$query = $this->db->get("pengeluaran u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
}