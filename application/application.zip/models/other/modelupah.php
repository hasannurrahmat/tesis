<?php

class Modelupah extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("u.id_aplikasi", $id);
		$query = $this->db->get("aplikasi u");
		
		return $query->row();
	}

	public function getAllupah($tanggal, $id_konsumen){
		$this->db->where("u.tanggal", $tanggal);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("user ug", "ug.id_user=u.id_karyawan");
		$this->db->join("usergroup g", "g.id_usergroup=ug.id_usergroup");
        $query = $this->db->get("upah u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllupahrekap($awal, $akhir, $id_konsumen){
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("user ug", "ug.id_user=u.id_karyawan");
        $query = $this->db->get("upah u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkaryawan(){
		$this->db->where("(u.id_usergroup=3 OR u.id_usergroup=5)");
		$query = $this->db->get("user u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkonsumen(){
		$query = $this->db->get("konsumen");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkonsumen($id){
		$this->db->join("user ug", "u.id_user=ug.id_user");
		$this->db->where("u.id_konsumen", $id);
		$query = $this->db->get("konsumen u");
		
		return $query->row();
	}

	public function tambah($data){
		$this->db->insert('upah', $data);
	}
}