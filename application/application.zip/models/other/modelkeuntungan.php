<?php

class Modelkeuntungan extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("u.id_aplikasi", $id);
		$query = $this->db->get("aplikasi u");
		
		return $query->row();
	}

	public function getAllkonsumen($id_konsumen){
		if($id_konsumen!=0){
			$this->db->where("u.id_konsumen", $id_konsumen);
		}
		$query = $this->db->get("konsumen u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getAllbarang(){
		$query = $this->db->get("barang");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpembelian($awal, $akhir, $id_konsumen){
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->select("u.*, sum(u.jumlah) as total_jumlah, sum(u.harga) as total_harga");
		$this->db->group_by("u.id_barang", "asc");
		$query = $this->db->get("pembelian u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpenjualan($awal, $akhir, $id_konsumen){
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->select("u.*, sum(u.jumlah) as total_jumlah, sum(u.harga) as total_harga");
		$this->db->group_by("u.id_barang", "asc");
		$query = $this->db->get("penjualan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getkonsumen($id){
		$this->db->join("user ug", "u.id_user=ug.id_user");
		$this->db->where("u.id_konsumen", $id);
		$query = $this->db->get("konsumen u");
		
		return $query->row();
	}
}