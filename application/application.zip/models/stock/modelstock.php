<?php

class Modelstock extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("u.id_aplikasi", $id);
		$query = $this->db->get("aplikasi u");
		
		return $query->row();
	}

	public function getAllstock($tanggal, $id_konsumen){
		$this->db->where("u.tanggal", $tanggal);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("barang b", "b.id_barang=u.id_barang");
        $query = $this->db->get("stock u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllstockrekap($awal, $akhir, $id_konsumen){
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("user ug", "ug.id_user=u.id_karyawan");
        $query = $this->db->get("stock u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllbarang(){
		$query = $this->db->get("barang");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkonsumen(){
		$query = $this->db->get("konsumen");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkonsumen($id){
		$this->db->join("user ug", "u.id_user=ug.id_user");
		$this->db->where("u.id_konsumen", $id);
		$query = $this->db->get("konsumen u");
		
		return $query->row();
	}

	public function tambah($data){
		$this->db->insert('stock', $data);
	}
}