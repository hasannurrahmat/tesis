<?php

class Modelpenjualan extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("u.id_aplikasi", $id);
		$query = $this->db->get("aplikasi u");
		
		return $query->row();
	}
	
	public function getAllpenjualan($tanggal, $id_konsumen){
		if($this->session->userdata("id_usergroup")==3){
			$this->db->where("u.id_user", $this->session->userdata("usergroup"));
		}
		$this->db->where("u.tanggal", $tanggal);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("barang ug", "ug.id_barang=u.id_barang");
        $query = $this->db->get("penjualan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpenjualanrekap($awal, $akhir, $id_konsumen){
		if($this->session->userdata("id_usergroup")==3){
			$this->db->where("u.id_user", $this->session->userdata("usergroup"));
		}
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("barang ug", "ug.id_barang=u.id_barang");
        $query = $this->db->get("penjualan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllbarang($barang){
		if($barang){
			$this->db->like("u.barang", $barang);
		}
		
        $query = $this->db->get("barang u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkonsumen(){
		$query = $this->db->get("konsumen");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkonsumen($id){
		$this->db->join("user ug", "u.id_user=ug.id_user");
		$this->db->where("u.id_konsumen", $id);
		$query = $this->db->get("konsumen u");
		
		return $query->row();
	}
	
	public function getpenjualan($id){
		$this->db->join("penjualangroup ug", "u.id_penjualangroup=ug.id_penjualangroup");
		$this->db->where("u.id_penjualan", $id);
		$query = $this->db->get("penjualan u");
		
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('penjualan', $data);
	}

	function getbarang($id){

	$harga_satuan="";

	$query= $this->db->get_where('barang',array('id_barang'=>$id));

	foreach ($query->result_array() as $data ){
		$harga_satuan= $data['harga_satuan'];
	}

	return $harga_satuan;

	}
}