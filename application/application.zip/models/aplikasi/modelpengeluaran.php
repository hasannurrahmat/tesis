<?php

class Modelpengeluaran extends CI_Model{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function getaplikasi($id){
		$this->db->where("u.id_aplikasi", $id);
		$query = $this->db->get("aplikasi u");
		
		return $query->row();
	}
	
	public function getAllpengeluaran($tanggal, $id_konsumen){
		if($this->session->userdata("id_usergroup")==3){
			$this->db->where("u.id_user", $this->session->userdata("usergroup"));
		}
		$this->db->where("u.tanggal", $tanggal);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("keperluan ug", "ug.id_keperluan=u.id_keperluan");
        $query = $this->db->get("pengeluaran u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllpengeluaranrekap($awal, $akhir, $id_konsumen){
		if($this->session->userdata("id_usergroup")==3){
			$this->db->where("u.id_user", $this->session->userdata("usergroup"));
		}
		$this->db->where("u.tanggal >=", $awal);
		$this->db->where("u.tanggal <=", $akhir);
		$this->db->where("u.id_konsumen", $id_konsumen);
		$this->db->join("keperluan ug", "ug.id_keperluan=u.id_keperluan");
        $query = $this->db->get("pengeluaran u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkeperluan($keperluan){
		if($keperluan){
			$this->db->like("u.keperluan", $keperluan);
		}
		
        $query = $this->db->get("keperluan u");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}

	public function getAllkonsumen(){
		$query = $this->db->get("konsumen");
 
        if ($query->num_rows() > 0) {
            foreach ($query->result() as $row) {
                $data[] = $row;
            }
            return $data;
        }
        return false;
	}
	
	public function getkonsumen($id){
		$this->db->join("user ug", "u.id_user=ug.id_user");
		$this->db->where("u.id_konsumen", $id);
		$query = $this->db->get("konsumen u");
		
		return $query->row();
	}
	
	public function getpengeluaran($id){
		$this->db->join("pengeluarangroup ug", "u.id_pengeluarangroup=ug.id_pengeluarangroup");
		$this->db->where("u.id_pengeluaran", $id);
		$query = $this->db->get("pengeluaran u");
		
		return $query->row();
	}
	
	public function tambah($data){
		$this->db->insert('pengeluaran', $data);
	}
	
	public function tambah_keperluan($data){
		$this->db->insert('keperluan', $data);
	}
	
	public function hapus_keperluan($id){
		$this->db->where('id_keperluan', $id);
		$this->db->delete('keperluan'); 
	}
}